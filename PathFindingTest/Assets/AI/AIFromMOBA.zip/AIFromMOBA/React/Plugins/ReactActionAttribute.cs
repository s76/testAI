﻿
namespace React
{
    [System.AttributeUsage(System.AttributeTargets.Method)]
    public class ReactActionAttribute : System.Attribute
    {

    }
}