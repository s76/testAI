using UnityEngine;
using System.Collections;

public class ComponentMethod {
	public Component component;
	public System.Reflection.MethodInfo methodInfo;
}
