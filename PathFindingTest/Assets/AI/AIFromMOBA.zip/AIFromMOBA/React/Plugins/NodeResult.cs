
using System;

namespace React
{
    public enum NodeResult
    {
        Continue,
        Failure,
        Success
    }

}