using System;
using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using Assets._Controllable.BasicEntity;

#if UNITY_EDITOR
using UnityEditor;
#endif

namespace React
{
    [ReactNode]
    public class DebugResults : DecoratorNode
    {
        [ReactVar]
        public string debugText;
        Entity entity;

        public override void Init(Reactor r)
        {
            base.Init(r);
#if !UNITY_4_3
            entity = r.GetComponent<Entity>() ?? r.GetComponentInParent<Entity>();
#else
			entity = r.GetComponent<Entity>();
#endif
        }

        public override IEnumerator<NodeResult> NodeTask()
        {
            if (Child == null)
            {
                yield return NodeResult.Failure;
                yield break;
            }

            var task = Child.GetNodeTask();
            while (task.MoveNext())
            {
                var t = task.Current;
                Debug.Log(string.Concat(debugText, " ", entity ? entity.name : "??", " ", t), entity);
                yield return t;
            }
        }

        public override string ToString()
        {
            return "DebugResult - " + debugText;
        }
#if UNITY_EDITOR
        public new static string GetHelpText()
        {
            return "Run the child N times, restarting the loop if any child succeeds or fails.";
        }
#endif
    }



}







