﻿using System;
using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System.Linq;

#if UNITY_EDITOR
using UnityEditor;
#endif

namespace React
{
    [ReactNode]
    public class DifficultyDelay : DecoratorNode
    {
        [ReactVar]
        public float maxSeconds;
        float lastRunTime = -1;
        BotDifficulty difficulty = null;
        float Delay { get { return maxSeconds * ( 1 - difficulty.Difficulty); } }

        public override void Init(Reactor r)
        {
            base.Init(r);
            try
            {
                difficulty = r.GetComponent<HeroAI>().Difficulty;
            }
            catch (Exception e)
            {
                Debug.LogError("[React] " + ToString() + "can't get difficulty\n" + e.ToString());
            }
        }

        public override IEnumerator<NodeResult> NodeTask()
        {
            if (lastRunTime < 0)
                lastRunTime = Time.time;
            if (Child == null)
            {
                yield return NodeResult.Failure;
                yield break;
            }
            var T = Time.time - lastRunTime;
            if (T > Delay)
            {
                //lastRunTime = Time.time;
                var task = Child.GetNodeTask();
                while (task.MoveNext())
                {
                    var t = task.Current;
                    if (t == NodeResult.Continue) { yield return NodeResult.Continue; }
                    else if (t == NodeResult.Success) { ResetLastRunTime(); yield return NodeResult.Success; break; }
                    else if (t == NodeResult.Failure) { yield return NodeResult.Failure; break; }
                }
            }
            else
            {
                yield return NodeResult.Failure;
            }
        }

        private void ResetLastRunTime()
        {
            lastRunTime = -1;
        }

        public override string ToString()
        {
            return string.Format("DifficultyDelay - {0} sec", maxSeconds);
        }

#if UNITY_EDITOR
        public new static string GetHelpText()
        {
            return "Will only run the child if N seconds have passed since the last time it was run.";
        }

#endif
    }



}







