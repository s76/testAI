﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Assets._AI.Shopping;

[Serializable]
public class BotShopList {
    public string botName;
    public ItemInShoptree[] items;
    public ItemPageChances itemPageChances;

    public enum ShopPage
    {
        Damage,
        Defense,
        Magic
    }
}

