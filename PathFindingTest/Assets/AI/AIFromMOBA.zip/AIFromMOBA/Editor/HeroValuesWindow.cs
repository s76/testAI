﻿using UnityEngine;
using System.Collections;
using UnityEditor;
using System.Collections.Generic;
using System.Linq;

public class HeroValuesWindow : EditorWindow
{
    Hero[] heroes;

    string myString = "Hello World";
    bool groupEnabled;
    bool myBool = true;
    float myFloat = 1.23f;
    private bool areHeroValueSlidersToggled;
    private bool areHeroValueAsTargetSlidersToggled;

    // Add menu named "My Window" to the Window menu
    [MenuItem("Window/AI/HeroValues")]
    static void Init()
    {
        // Get existing open window or if none, make a new one:
        var window = (HeroValuesWindow)EditorWindow.GetWindow(typeof(HeroValuesWindow));
        window.autoRepaintOnSceneChange = true;
    }

    void Update()
    {
        Repaint();
    }

    void OnGUI()
    {
        heroes = FindObjectsOfType<Hero>();
        if (heroes.IsEmptyOrNull() == false)
        {
            GUILayout.Label("Hero values", EditorStyles.boldLabel);
            float maxValue = heroes.Select(h => ActionsWithHeroes.HeroValue(h)).Max();

            foreach (var hero in heroes)
            {
                EditorGUI.ProgressBar(EditorGUILayout.GetControlRect(), ActionsWithHeroes.HeroValue(hero) / maxValue, hero.CodeName + " " + ActionsWithHeroes.HeroValue(hero));
            }

            if (areHeroValueSlidersToggled = EditorGUILayout.Foldout(areHeroValueSlidersToggled, "Hero value sliders"))
            {
                ActionsWithHeroes.HeroValue_DPS_Coeff = EditorGUILayout.Slider("DPS", ActionsWithHeroes.HeroValue_DPS_Coeff, 0, 5);
                ActionsWithHeroes.HeroValue_HP_Coeff = EditorGUILayout.Slider("HP", ActionsWithHeroes.HeroValue_HP_Coeff, 0, 5);
                ActionsWithHeroes.HeroValue_range_Coeff = EditorGUILayout.Slider("range", ActionsWithHeroes.HeroValue_range_Coeff, 0, 5);
            }

            float maxValueAsTarget = heroes.Select(h => ActionsWithHeroes.HeroValueAsTarget(h)).Max();
            GUILayout.Label("Hero values as targets", EditorStyles.boldLabel);
            foreach (var hero in heroes)
            {
                EditorGUI.ProgressBar(EditorGUILayout.GetControlRect(), ActionsWithHeroes.HeroValueAsTarget(hero) / maxValueAsTarget, hero.CodeName + " " + ActionsWithHeroes.HeroValueAsTarget(hero));
            }

            if (areHeroValueAsTargetSlidersToggled = EditorGUILayout.Foldout(areHeroValueAsTargetSlidersToggled, "Hero value as targets sliders"))
            {
                ActionsWithHeroes.HeroValueAsTarget_DPS_Coeff = EditorGUILayout.Slider("DPS", ActionsWithHeroes.HeroValueAsTarget_DPS_Coeff, 0, 5);
                ActionsWithHeroes.HeroValueAsTarget_HP_Coeff = EditorGUILayout.Slider("HP", ActionsWithHeroes.HeroValueAsTarget_HP_Coeff, -5, 0);
                ActionsWithHeroes.HeroValueAsTarget_range_Coeff = EditorGUILayout.Slider("range", ActionsWithHeroes.HeroValueAsTarget_range_Coeff, 0, 5);
            }
        }
        else
        {
            GUILayout.Label("No heroes found");

            if (true) { return; }
        }
    }
}