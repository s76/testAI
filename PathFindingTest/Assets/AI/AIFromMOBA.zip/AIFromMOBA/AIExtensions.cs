﻿using Assets._Controllable._EntityPreferences;
using Assets._Controllable.BasicEntity;
using Assets._Inventory.New;
using Assets._Shop;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using UnityEngine;

namespace Assets._AI
{

    public static class AIExtensions
    {

        public static bool IsCoveredBy(this IEntityControllable e, IAttackerControllable cover, IAttackerControllable threat, float safetyMargin = 0)
        {
            if (cover == null) return false;
            Vector3 coverToE = e.Position - cover.Position;
            float coverAttackRangeSqr = cover.AttackRange * cover.AttackRange;
            //if (coverToE.sqrMagnitude > coverAttackRangeSqr) return false; //PanDenat - does not work if e is not in range of cover (happens a lot)
            Vector3 eToThreatClampedWithBellys = Vector3.ClampMagnitude((threat.Position - e.Position), threat.AttackRange + threat.Radius + e.Radius);
            float coverAttackRangeWithBellysSqr = (cover.AttackRange + cover.Radius + threat.Radius + safetyMargin) * (cover.AttackRange + cover.Radius + threat.Radius + safetyMargin);
            if ((coverToE + eToThreatClampedWithBellys).sqrMagnitude < coverAttackRangeWithBellysSqr) return true;
            else return false;
        }

        public static bool IsCoveredBy(this IEntityControllable e, Vector3 cover, IAttackerControllable threat, float safetyMargin)
        {
            if (cover == null) return false;
            Vector3 coverToE = e.Position - cover;
            //float coverAttackRangeSqr = cover.AttackRange * cover.AttackRange;
            //if (coverToE.sqrMagnitude > coverAttackRangeSqr) return false; //PanDenat - does not work if e is not in range of cover (happens a lot)
            Vector3 eToThreatClampedWithBellys = Vector3.ClampMagnitude((threat.Position - e.Position), threat.AttackRange + threat.Radius + e.Radius);
            float coverAttackRangeWithBellysSqr = (threat.Radius + safetyMargin) * (threat.Radius + safetyMargin);
            if ((coverToE + eToThreatClampedWithBellys).sqrMagnitude < coverAttackRangeWithBellysSqr) return true;
            else return false;
        }

        /// <summary>
        /// Does not take into account bellies.
        /// </summary>
        /// <param name="v"></param>
        /// <param name="cover"></param>
        /// <param name="threat"></param>
        /// <returns></returns>
        public static bool IsCoveredBy(this Vector3 v, IAttackerControllable cover, IAttackerControllable threat, float safetyMargin = 0)
        {
            if (cover.IsAlive == false) return false;
            Vector3 coverToE = v - cover.Position;
            float coverAttackRangeSqrWithOwnBelly = (cover.AttackRange + cover.Radius + safetyMargin) * (cover.AttackRange + cover.Radius + safetyMargin);
            //if (coverToE.sqrMagnitude > coverAttackRangeSqr) return false;  //PanDenat - does not work if e is not in range of cover (happens a lot)
            Vector3 eToThreatClamped = Vector3.ClampMagnitude((threat.Position - v), threat.AttackRange);
            if ((coverToE + eToThreatClamped).sqrMagnitude < coverAttackRangeSqrWithOwnBelly) return true;
            else return false;
        }

        public static bool IsCoveredBy<T>(this IEntityControllable e, IEnumerable<T> covers, IAttackerControllable threat, float safetyMargin = 0) where T : IAttackerControllable
        {
            foreach (var cover in covers)
                if (e.IsCoveredBy(cover, threat, safetyMargin)) return true;
            return false;
        }

        public static bool IsCoveredBy<T>(this Vector3 e, IEnumerable<T> covers, IAttackerControllable threat, float safetyMargin = 0) where T : IAttackerControllable
        {
            foreach (var cover in covers)
                if (e.IsCoveredBy(cover, threat, safetyMargin)) return true;
            return false;
        }

        public static T ClosestTo<T>(this IEnumerable<T> enTities, IEntityControllable reference, Func<T, bool> Filter = null) where T : IEntityControllable
        {
            return enTities.ClosestTo(reference.Position, Filter);
        }

        public static T ClosestTo<T>(this IEnumerable<T> enTities, Vector3 point, Func<T, bool> Filter = null) where T : IEntityControllable
        {

            T closestEntity = default(T);
            float closestDistance = Mathf.Infinity; // all distances used are squared!
            //if (closestEntity != null) closestDistance = (reference.Position - closestEntity.Position).sqrMagnitude;
            foreach (var entity in enTities)
            {
                if (Filter != null && Filter(entity) == false) continue;
                float distanceFrom = (point - entity.Position).sqrMagnitude;
                if (distanceFrom < closestDistance)
                {
                    closestDistance = distanceFrom;
                    closestEntity = entity;
                }
            }
            return closestEntity;
        }

        public static Vector3? ClosestVecTo(this IEnumerable<Vector3> vector3s, IEntityControllable reference)
        {
            Vector3? closestVector3 = null;
            float closestDistance = Mathf.Infinity; // all distances used are squared!
            Vector3 refPos = reference.Position;
            //if (closestEntity != null) closestDistance = (reference.Position - closestEntity.Position).sqrMagnitude;
            foreach (var v in vector3s)
            {
                float distanceFrom = (refPos - v).sqrMagnitude;
                if (distanceFrom < closestDistance)
                {
                    closestDistance = distanceFrom;
                    closestVector3 = v;
                }
            }
            return closestVector3;
        }

        public static Vector3 AddRandomOffset(this Vector3 v, float maxOffset, float minOffset = 0)
        {
            return HeroActions.AddRandomOffset(v, maxOffset, minOffset);
        }

        public static Vector3 AddRandomOffsetWithoutLinecast(this Vector3 v, float maxOffset, float minOffet =0)
        {
            return HeroActions.AddRandomOffsetWithoutLinecast(v, maxOffset, minOffet);
        }

        public static Vector3 GetCenter<E>(this IEnumerable<E> entities) where E : IEntityControllable
        {
            return _GetCenter(entities);
        }

        public static Vector3 GetCenter(this IEnumerable<Transform> transforms)
        {
            return transforms.Select(t => t.position).GetCenter();
        }

        public static Vector3 GetCenter(this IEnumerable<Vector3> vecs)
        {
            Vector3 posSum = Vector3.zero;
            int count = 0;
            foreach (var v in vecs)
            {
                posSum += v;
                count++;
            }
            return posSum / count;
        }
		
        public static IHeroControllable GetWeakest<H>(this IEnumerable<H> heroes) where H : IHeroControllable
        {
            IHeroControllable weakest = null;
			float weakestVal = 10000000f;
			foreach(var h in heroes)
			{
				float value = ActionsWithHeroes.HeroValue(h);
				if(value < weakestVal)
				{
					weakest = h;
					weakestVal = value;
				}
			}
			return weakest;
        }
		
        public static Vector3 GetHitableCenter<E>(this List<E> entites, float acceptableRadius) where E : IEntityControllable
		{
			if(entites.Count == 0)
				return Vector3.zero;
			if(entites.Count == 1)
				return entites[0].Position;
			
			float sqrRadius = acceptableRadius * acceptableRadius;
			for(int i = 0; i < entites.Count; i++)
			{
				for(int j = i + 1; j < i + entites.Count; j++)
				{
					if( (entites[i].QuadTreePosition - entites[j%entites.Count].QuadTreePosition).sqrMagnitude <= sqrRadius )
						return (entites[i].Position + entites[j%entites.Count].Position) * 0.5f;
				}
			}

			return Vector3.zero;
		}

        private static Vector3 _GetCenter<E>(IEnumerable<E> entities) where E : IEntityControllable
        {
            return entities.Select(e => e.Position).GetCenter();
        }

        public static bool HasBeenHitRecently(this IEntityControllable e, float timeInterval = 1.0f)
        {
            return e.LastHitTime > Time.time - timeInterval;
        }

        public static bool HasInRange(this Vector3 pos, Vector3 targetPos, float range)
        {
            return (pos - targetPos).sqrMagnitude < range * range;
        }

        public static bool HasInRange<T>(this Vector3 pos, IEnumerable<T> others, float range) where T : IEntityControllable
        {
            bool othersIsEmpty = true;
            foreach (var other in others)
            {
                othersIsEmpty = false;
                if (pos.HasInRange(other, range) == false) { return false; }
            }
            return othersIsEmpty ? false : true;
        }

        public static bool HasInRange(this Vector3 pos, IEntityControllable other, float range)
        {
            return pos.HasInRange(other.Position, range);
        }

        public static void AddStat(this SimplePreference pref, float value)
        {
            var healthOrMana = pref as LifeManaPreference;
            if (healthOrMana != null) { healthOrMana.MaxBaseValue += value; }
            else { pref.BaseValue += value; }
        }

        static public bool IsSlotItemCategory(this ISlot<IBaseItem> slot, ShopCategory category)
        {
            var item = slot.Item as Item;
            if (item != null && item.ShopCategory == category) { return true; }
            return false;
        }

        static public T GetRandom<T>(this IEnumerable<T> self)
        {
            return self.ElementAtOrDefault(UnityEngine.Random.Range(0, self.Count()));
        }

        static public Vector3 PredictPosition(this IEntityControllable self, float predictionTime)
        {
            return self.Position + self.PredictDeltaPosition(predictionTime);
        }

        static public Vector3 PredictDeltaPosition(this IEntityControllable self, float predictionTime)
        {
            return self.State == EntityState.Run ? predictionTime * self.Trans.forward * ((IMoverControllable)self).MoveSpeed : Vector3.zero;
        }

        static public IEnumerable<List<T>> GetAllSubsets<T>(this IList<T> all)
        {
            int allCount = all.Count();
            int subsetCount = 1 << allCount;
            for (int i = subsetCount-1; i>=0; i--) //roughly getting answers starting from bigger sets then smaller sets
            {
                var subset = new List<T>();
                for (int bitIndex = 0; bitIndex < allCount; bitIndex++)
                {
                    if (GetBit(i, bitIndex) == 1)
                    {
                        subset.Add(all[bitIndex]);
                    }
                }
                yield return subset;
            }
        }

        private static int GetBit(int value, int bitIndex)
        {
            int bit = value & 1 << bitIndex;
            return bit > 0 ? 1 : 0;
        }
    }
}

public static class GlobalExtensions
{
    public static Boolean IsEmptyOrNull<T>(this IEnumerable<T> source)
    {
        if (source == null)
            return true;
        return !source.Any();
    }

    public static T[] RemoveNulls<T>(this T[] source) where T : class // PanDenat - to nie moje d:
    {
        int nulls = 0;
        foreach (var VARIABLE in source)
            if (VARIABLE == null)
                nulls++;
        if (nulls == 0) return source;
        return source.Where(t => t != null).ToArray();
    }
}