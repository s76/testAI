﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using UnityEditor;
using UnityEngine;

namespace Assets._AI.Shopping.Editor
{
    [CustomPropertyDrawer(typeof (ItemInShoptree))]
    public class ItemInShoptreeDrawer : PropertyDrawer
    {
        public override void OnGUI(Rect position, SerializedProperty property, GUIContent label)
        {
            //base.OnGUI(position, property, label);
            SerializedProperty tier = property.FindPropertyRelative("Tier");
            SerializedProperty row = property.FindPropertyRelative("Row");
            SerializedProperty page = property.FindPropertyRelative("Page");

            float offset = position.width/6;

            Rect rect = new Rect(position.x, position.y, offset, position.height);
            EditorGUI.LabelField(rect, page.name);
            rect = new Rect(rect.x + offset, rect.y, rect.width, rect.height);
            page.intValue = Convert.ToInt32(EditorGUI.EnumPopup(rect, (BotShopList.ShopPage)page.intValue));

            rect = new Rect(rect.x + offset, rect.y, rect.width, rect.height);
            EditorGUI.LabelField(rect, tier.name);
            rect = new Rect(rect.x + offset, rect.y, rect.width, rect.height);
            tier.intValue = EditorGUI.IntField(rect, tier.intValue);

            rect = new Rect(rect.x + offset, rect.y, rect.width, rect.height);
            EditorGUI.LabelField(rect, row.name);
            rect = new Rect(rect.x + offset, rect.y, rect.width, rect.height);
            row.intValue = EditorGUI.IntField(rect, row.intValue);
        }
    }
}

