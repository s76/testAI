﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Assets._Common;
using Assets._Shop;
using UnityEngine;

namespace Assets._AI.Shopping
{
    class ShopItemChooserAi : MonoBehaviour
    {
        private BotShopList shoppingList;
        private IHeroControllable hero;

        private List<BotShopList.ShopPage> availablePages = new List<BotShopList.ShopPage>()
        {
            BotShopList.ShopPage.Damage,
            BotShopList.ShopPage.Defense,
            BotShopList.ShopPage.Magic
        };


        public ShopItemChooserAi Initialize(BotShopList shoppingList, IHeroControllable hero)
        {
            this.shoppingList = shoppingList;
            this.hero = hero;
            return this;
        }

        public Id RollNewItemToBuy(BaseShop shop)
        {
            while (true)
            {
                if (availablePages.IsEmptyOrNull()) { return null; }
                var page = shoppingList.itemPageChances.GetRandomPage(availablePages);
                //var itemId = shoppingList.items.Where(i => i.Page == page).Select(i => i.GetId()).FirstOrDefault(id => shop.CanAddItem(id, hero.Wallet, hero.Inventory));
                Id itemId=null;
                var items = shoppingList.items;
                for (int i = 0; i < items.Length ; i++)
                {
                    if (items[i].Page == page)
                    {
                        itemId = items[i].GetId();
                        if (shop.CanAddItem(items[i].GetId(), hero.Wallet, hero.Inventory)) break;
                    }
                }

                if (itemId != null) { return itemId; }
                availablePages.Remove(page);
            }
        }
    }
}
