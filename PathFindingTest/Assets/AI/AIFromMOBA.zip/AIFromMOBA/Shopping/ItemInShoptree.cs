﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Assets._Common;

namespace Assets._AI.Shopping
{
    [Serializable]
    public struct ItemInShoptree
    {
        public int Row;
        public int Tier;
        public BotShopList.ShopPage Page;



        private Id _id;
        public Id GetId()
        {
            return _id ?? (_id = new Id(Page + "Item" + Row + "Tier" + Tier));
        }
    }
}
