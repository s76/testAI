﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Assets._Common;
using Assets._Shop;
using UnityEngine;

namespace Assets._AI.Shopping
{
    class ShoppingAI : MonoBehaviour
    {
        private IHeroControllable Hero;
        private Id nextItemToBuy;
        private ShopItemChooserAi itemChooser;

        public ShoppingAI Initialize(IHeroControllable hero)
        {
            Hero = hero;
            string codeName = ((Hero) hero.LocalEntity).CodeName;
            var botShoppingList = BotManager.instance.botsShopLists.FirstOrDefault(list => list.botName.Contains(codeName));
            if (botShoppingList == null)
            {
#if UNITY_EDITOR
                Debug.LogWarning("[" + codeName + " Ai] Couldn't find my shoplist. Using default.", this);
#endif
                botShoppingList = BotManager.instance.botsShopLists.FirstOrDefault(list => list.botName.Contains("Default"));
            }
            if (botShoppingList == null) { Debug.LogError("[Shopping Ai] No shoplist for " + codeName + ". Even default.", this); }

            itemChooser = gameObject.AddComponent<ShopItemChooserAi>().Initialize(botShoppingList, hero);
            return this;
        }
        
        public bool CanBuyItem()
        {
            if (nextItemToBuy == null) { nextItemToBuy = RollNewItemToBuy(); }
            return nextItemToBuy != null && GetShop().CanBuyItem(nextItemToBuy, Hero.Wallet, Hero.Inventory);
        }

        private Id RollNewItemToBuy()
        {
            var shop = GetShop();
            return itemChooser.RollNewItemToBuy(shop);
        }

        private BaseShop GetShop()
        {
            var vendor = GetVendor();
            return vendor.Shop as BaseShop;
        }

        private VendorEntity GetVendor()
        {
            return BotManager.instance.Cache.Vendors[Hero.EntityTeam].ClosestTo(Hero);
        }

        public bool BuyItem()
        {
            if (nextItemToBuy == null) { nextItemToBuy = RollNewItemToBuy(); }
            if (nextItemToBuy == null) return false;

            if (GetShop().Buy(nextItemToBuy, Hero.Wallet, Hero.Inventory) != null)
            {
                nextItemToBuy = null;
                return true;
            }
            return false;
        }
    }
}
