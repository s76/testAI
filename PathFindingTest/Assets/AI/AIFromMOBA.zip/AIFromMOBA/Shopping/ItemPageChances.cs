﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Random = UnityEngine.Random;

namespace Assets._AI.Shopping
{
    [Serializable]
    public struct ItemPageChances
    {
        public float Damage;
        public float Defense;
        public float Magic;

        public BotShopList.ShopPage GetRandomPage()
        {
            float r = Random.Range(0, Damage + Defense + Magic);
            if (r < Damage) { return BotShopList.ShopPage.Damage; }
            if (r < Damage + Defense) { return BotShopList.ShopPage.Defense; }
            return BotShopList.ShopPage.Magic;
        }

        public BotShopList.ShopPage GetRandomPage(IEnumerable<BotShopList.ShopPage> pages)
        {
            ItemPageChances tmpThis = this;
            float randomResult = Random.Range(0f, pages.Sum(p => tmpThis.GetChance(p)));
            float bar = 0;
            foreach (var page in pages)
            {
                bar += GetChance(page);
                if (randomResult < bar) { return page; }
            }
            throw new ArgumentException("Pages list empty or 0 chance for all pages.");
        }

        public float GetChance(BotShopList.ShopPage page)
        {
            switch (page)
            {
                case BotShopList.ShopPage.Damage:
                    return Damage;
                case BotShopList.ShopPage.Defense:
                    return Defense;
                case BotShopList.ShopPage.Magic:
                    return Magic;
                default:
                    throw new ArgumentOutOfRangeException("page");
            }
        }
    }
}
