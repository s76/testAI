/*using Assets._Controllable.BasicEntity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using UnityEngine;

public class WorkPlace : MonoBehaviour {
    public new Transform transform { get; set; }
    public Quaternion Rotation { get { return transform.rotation; } }
    public Vector3 Position { get { return transform.position; } }

    void Start() {
        transform = base.transform;
    }

    public Worker Worker {
        get { return worker; }
        private set {
            //if (value == null) Debug.LogException(new Exception(), this);
            if (value != null) value.onStateChanged += WorkerStateChanged;
            worker = value;
        }
    }

    void WorkerStateChanged(EntityState before, EntityState after, IEntityControllable entity) {
        if (Worker != entity) entity.LocalEntity.onStateChanged -= WorkerStateChanged;
        else
            if (after != EntityState.Repair
                && after != EntityState.Work) {
                Debug.Log("[WorkPlace] WorkerStateChanged(" + before + ", " + after + ")", this);
                Worker.onStateChanged -= WorkerStateChanged;
                Worker = null;
            }
    }

    public bool SetWorker(Worker newWorker) {
        bool workerAccepted = ValidateWorker(newWorker);
        if (workerAccepted) Worker = newWorker;
        return workerAccepted;
    }

    private bool ValidateWorker(Worker newWorker) {
        if (Worker != null && Worker.HasInRange(Position, 1f)) return false; //QQ
        else
            if (newWorker.HasInRange(Position, 1f) && newWorker.State == EntityState.Stay) return true; //QQ
            else return false;
    }

    private Worker worker;
}

*/