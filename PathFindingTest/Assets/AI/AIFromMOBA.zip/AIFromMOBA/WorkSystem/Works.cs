﻿/*sing System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using UnityEngine;


public abstract class Works : MonoBehaviour {

    public virtual WorkStation WorkStation {
        protected get { return workStation; }
        set { workStation = value;
        WorkStation.OnNewWorker += WorkStation_OnNewWorker;
        }
    }

    private WorkStation workStation;
    protected int noWorkers = 0;

    protected virtual void WorkStation_OnNewWorker() {
        noWorkers = WorkStation.NumberOfWorkers;
    }
}

*/