/*using UnityEngine;
using System.Collections;

public class WorkStation : MonoBehaviour {

    public delegate void OnNewWorkerHandler();
    public event OnNewWorkerHandler OnNewWorker;

    public WorkPlace[] workPlaces;
    public Works work;

    public new Transform transform { get; set; }
    public Quaternion Rotation { get { return transform.rotation; } }
    public Vector3 Position { get { return transform.position; } }

    void Awake() {
        transform = base.transform;
        if (work == null) Debug.LogError("No >>Work<< set in WorkPlace!");
        work.WorkStation = this;
    }
	
	// Update is called once per frame
	void Update () {
	}

    public void WorkerNull() {
        OnNewWorker();
    }

    public WorkPlace GetFreeWorkPlace() {
        foreach (WorkPlace w in workPlaces) {
            if (w.Worker == null) return w;
        } 
        return null;
    }

    public bool RegisterWorker(Worker worker, WorkPlace workPlace) {
        bool workerRegistered = workPlace.SetWorker(worker);
        if (workerRegistered) OnNewWorker();
        return workerRegistered;

    }

    public int NumberOfWorkers {
        get {
            int noWorkers = 0;
            foreach (WorkPlace w in workPlaces)
                if (w.Worker != null) noWorkers++;
            return noWorkers;
        }
    }
}
*/