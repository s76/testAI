/*using Assets._Controllable.BasicEntity;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using UnityEngine;

class TrebuchetWorks : Works {

    private Siege Trebuchet;

    void Start() {
        Trebuchet = WorkStation.gameObject.GetComponent<Siege>();
        Trebuchet.onStateChanged += Trebuchet_OnEntityStateChange;
        StartCoroutine(Repair());
    }

    void Trebuchet_OnEntityStateChange(EntityState before, EntityState after, IEntityControllable entity) {
        Debug.LogWarning("TrebuchetWorks catches new state of Trebuchet. From " + before + " to " + after, this);
        if (after == EntityState.Destroyed) SetAllWorkersStateTo(EntityState.Repair);
        else SetAllWorkersStateTo(EntityState.Work);
    }

    private void SetAllWorkersStateTo(EntityState entityState) {
        for (int i = 0; i < WorkStation.workPlaces.Length; ++i) {
            Worker worker = WorkStation.workPlaces[i].Worker;
            if (worker != null) {
                worker.State = entityState;
                worker.animationController.SetSlot(i);
            }
        }
    }

    private float repairTimeInterval = 1f;
    private float repairHealthPerSecondPerMinion = 10f;
    private IEnumerator Repair() {
        while (true) {
            yield return new WaitForSeconds(repairTimeInterval);
            if (Trebuchet.State == EntityState.Destroyed && noWorkers > 0) { //TODO: poprawic na noWorkers
                float repairAmount = repairHealthPerSecondPerMinion / repairTimeInterval * WorkStation.NumberOfWorkers;
                //Debug.Log(Trebuchet.ToString() + " is repaird by " + repairAmount + " hp.", Trebuchet);
                Trebuchet.Controller.HandleSupport(repairAmount, Trebuchet, null);
            }
        }
    }

    protected override void WorkStation_OnNewWorker() {
        base.WorkStation_OnNewWorker();
        if (Trebuchet.State == EntityState.Destroyed) SetAllWorkersStateTo(EntityState.Repair);
        else SetAllWorkersStateTo(EntityState.Work);
    }
}
*/