﻿using Assets._Controllable.BasicEntity;

namespace Assets._AI.Controller
{
    interface IHelpful
    {
        void AnswerHelpCall(IEntityControllable entity);
    }
}
