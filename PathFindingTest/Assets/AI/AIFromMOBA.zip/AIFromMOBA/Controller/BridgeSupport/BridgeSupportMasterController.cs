﻿using Assets._Controllable.BasicEntity;
using Assets._Network.Sender.BasicEntity;
using UnityEngine;

public class BridgeSupportMasterController : EntityMasterController
{
	public override IEntityControllable Entity { get { return bridgeSupport; } }
	protected BridgeSupport bridgeSupport { get; set; }

    protected Vector3 startPosition;

    public override void Initialize()
    {
        bridgeSupport = GetEntityComponent<BridgeSupport>();
	    if (NetworkManager.instance.isMultiplayer)
			bridgeSupport.Sender = new EntitySender(bridgeSupport);
        base.Initialize();
        startPosition = trans.position;
    }
}

