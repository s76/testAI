using Assets._Controllable.BasicEntity;
using Assets._Network.Sender.BasicEntity;

namespace Assets._AI.Controller.Base
{
	public class BaseMasterController : EntityMasterController
	{
		//private bool winnerMessageSend;

		public override IEntityControllable Entity
		{
			get { return Base; }
		}

		protected _Controllable.Base.Base Base { get; set; }

		public override void Initialize()
		{
			Base = GetEntityComponent<_Controllable.Base.Base>();
			if (NetworkManager.instance.isMultiplayer) Base.Sender = new EntitySender(Base);
			base.Initialize();
		}


		/*public override void HandleHit(float dmg, IAttackerControllable attacker, Skill skill, bool forceDmg = false)
		{
			if (Entity.IsAlive == false || attacker.CanTargetEnemy(Entity) == false) return;

			base.HandleHit(dmg, attacker, skill, forceDmg);

			if (Entity.State == EntityState.Dead && !winnerMessageSend)
			{
				winnerMessageSend = true;
				GameManager.instance.FinishGame(Entity.EntityTeam == Team.East ? Team.West : Team.East);
			}
		}*/
	}
}