﻿using Assets._Controllable.BasicEntity;
using Assets._Controller.Dispatcher;
using QTree;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using UnityEngine;

class EntityActivatorAI : MonoBehaviour {

    EntityActivatorMasterController controller;
    IEntityActivatorControllable activator;
    public float updateStepInterval = 0.1f;

    public EntityActivatorAI Initialize(EntityActivatorMasterController controller) {
        this.controller = controller;
        this.activator = controller.Entity as IEntityActivatorControllable;
        controller.onHandleHit += controller_onHandleHit;
        return this;
    }

	void OnEnable()
	{
		StartCoroutine(EnableCoroutines());
	}

	IEnumerator EnableCoroutines()
	{
		do
		{
			yield return new WaitForSeconds(1f);
		}while(activator == null || !activator.Inited);
		if (activator.SkillOnSee != null || activator.SkillOnSelectAndSee)
			StartCoroutine(DistanceCheckingCoroutine());
		if (activator.SkillOnLineColide != null)
			StartCoroutine(LineCheckingCoroutine());
	}

    void controller_onHandleHit(float dmg, IAttackerControllable attacker, Skill skill) 
	{
        try 
		{
            ActivateOnHit(attacker);
        } catch (Exception e) {
            Debug.LogWarning("[EntityActivator] Error, skipping action.\n " + e.ToString());
        }
    }

    private void ActivateOnHit(IAttackerControllable attacker) 
	{
		if(activator.SkillOnHit)
            activator.UseSkill(activator.SkillOnHit, new SkillParams() { targetEntity = attacker });
    }

    IEnumerator LineCheckingCoroutine() 
	{
        while(true) 
		{
			Vector2 position2D = new Vector2(activator.Position.x, activator.Position.z);
			Vector2 origin = ((EntityActivator) activator.LocalEntity).lineActivationBegin + position2D;
			Vector2 end = ((EntityActivator) activator.LocalEntity).lineActivationEnd + position2D;
			float lineWidth = ((EntityActivator) activator.LocalEntity).lineActivationWidth;
            var entities = QuadTreeFinder.FindInLine(origin, end, lineWidth);
			bool skillUsed = false;
            foreach (var e in entities) 
			{
				if(!e.IsTargetable)
					continue;
                try 
				{
                    ActivateSkillOnLineCollide(e);
					skillUsed = true;
                } 
				catch(Exception ex) 
				{
                    Debug.LogWarning("[EntityActivator] Error, skipping action. \n" + ex.ToString(), this);
                }
            }
			yield return new WaitForSeconds((skillUsed ? activator.SkillOnLineColide.CoolDown : 0f ) + updateStepInterval);
        }
    }

    private void ActivateSkillOnLineCollide(Entity e) 
	{
		if(activator.SkillOnLineColide)
			activator.UseSkill(activator.SkillOnLineColide, new SkillParams(){targetEntity = e.IEntity});
    }

    IEnumerator DistanceCheckingCoroutine() {
        while (true) 
		{
			bool skillUsed = false;
            var entities = QuadTreeSystem.instance.QuadTree.Query(new QTree.BoundingRect(activator.Position, activator.VisibilityRange > 1f ? activator.VisibilityRange : 1f));
            foreach (var e in entities) 
			{
                try 
				{
                    if(e.IsTargetable) 
					{
						if(activator.HasInVisibilityRange(e))
						{
	                        ActivateOnSee(e);
	                        IAttackerControllable a = e as IAttackerControllable;
	                        if (a != null && a.AttackTarget != null && a.AttackTarget == activator.LocalEntity)
								ActivateOnSelectOnSee(a);
							skillUsed = true;
						}
                    }
                } catch (Exception ex) {
                    Debug.LogWarning("[EntityActivator] Error, skipping action.\n" + ex.ToString());
                }
                yield return new WaitForSeconds(updateStepInterval);
			}

			if(!skillUsed)
				yield return new WaitForSeconds(updateStepInterval);
			else if(activator.SkillOnSee != null)
				yield return new WaitForSeconds(activator.SkillOnSee.CoolDown);
			else if(activator.SkillOnSelectAndSee != null)
				yield return new WaitForSeconds(activator.SkillOnSelectAndSee.CoolDown);
			else
				yield return new WaitForSeconds(updateStepInterval);
        }
    }

    private void ActivateOnSelectOnSee(IAttackerControllable a) 
	{
		if(activator.SkillOnSelectAndSee)
            activator.UseSkill(activator.SkillOnSelectAndSee, new SkillParams() { targetEntity = a });
    }

    private void ActivateOnSee(IEntityControllable entity) 
	{
		if(activator.SkillOnSee)
			activator.UseSkill(activator.SkillOnSee, new SkillParams(){targetEntity = entity});
    }
}
