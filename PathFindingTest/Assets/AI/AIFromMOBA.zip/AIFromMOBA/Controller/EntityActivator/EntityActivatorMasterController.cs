using Assets._Controllable.BasicEntity;
using Assets._Network.Sender.BasicEntity;
using UnityEngine;
using System;

[RequireComponent(typeof(EntityActivatorAI))]
public class EntityActivatorMasterController : AttackerMasterController
{
	protected EntityActivator Activator { get; set; }
	public override IEntityControllable Entity { get { return Activator; } }
	protected override IAttackerControllable Attacker { get { return Activator; } }

	
	public override void Initialize()
	{
		try
		{
			Activator=GetEntityComponent<EntityActivator>();
			if (NetworkManager.instance.isMultiplayer)
				Activator.Sender = new AttackerSender(Activator);

	        GetComponent<EntityActivatorAI>().Initialize(this);
		}
		catch(Exception e)
		{
			Debug.LogError("Error for " + name + "\n" + e);
		}
		base.Initialize();
	}
}
