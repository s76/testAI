using Assets._Controllable.BasicEntity;
using Assets._Controllable.Tower;
using Assets._Network.Sender.BasicEntity;

public class TowerMasterController : AttackerMasterController
{
	public override IEntityControllable Entity { get { return Tower; } }
	protected override IAttackerControllable Attacker { get { return Tower; } }
	protected Tower Tower { get; set; }
	
	public override void Initialize()
	{
		Tower = GetEntityComponent<Tower>();
		if (NetworkManager.instance.isMultiplayer)
			Tower.Sender = new AttackerSender(Tower);
		base.Initialize();
	}

    protected override void Update()
	{
		base.Update();
		
		if(Tower.Lvl < MinionManager.instance.RequestedMinionLvl)
		{
			Tower.Exp = Tower.NextLevelExp + 1;
		}
	}

    public override void AnswerHelpCall(IEntityControllable attacked)
    {
        IEntityControllable agresor = attacked.LastHitter;

        if (Attacker.AttackTarget != null
            && Attacker.AttackTarget.EntityType == EType.Hero) return;

        if (attacked.EntityType == EType.Hero
            && agresor.EntityType == EType.Hero
            && Attacker.CanTargetEnemy(agresor)) Attacker.AttackTarget = agresor;
    }
}
