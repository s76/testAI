using System.Collections.Generic;
using Assets._Client;
using Assets._Controllable.BasicEntity;
using Assets._Controllable.HealingTower;
using Assets._Network.Sender.BasicEntity;
using QTree;
using UnityEngine;

public class HealingTowerMasterController : AttackerMasterController
{
	public override IEntityControllable Entity { get { return HealingTower; } }
	protected override IAttackerControllable Attacker { get { return HealingTower; } }
	protected HealingTower HealingTower { get; set; }

	Vector2[] catchPoints = null;
	private static int eastHealsCounter;
	private static int westHealsCounter;
    //HashSet<Entity> entitiesSetToNotTargetable = null;

	public override void Initialize()
	{
		HealingTower = GetEntityComponent<HealingTower>();
		if (NetworkManager.instance.isMultiplayer)
			HealingTower.Sender = new AttackerSender(HealingTower);
		base.Initialize();
		eastHealsCounter = 0;
		westHealsCounter = 0;

		Transform[] transPoints = ((HealingTower)HealingTower.LocalEntity).targetsCatchPoints;
		if(transPoints.Length > 0)
		{
			catchPoints = new Vector2[transPoints.Length];
			for(int i = 0; i < transPoints.Length; i++)
			{
				catchPoints[i] = new Vector2(transPoints[i].position.x, transPoints[i].position.z);
			}
		}

        /*if(MapManager.instance.LastLoadedMap.gameMode == GameMode.DeathMatch)
        {
            if(entitiesSetToNotTargetable == null)
                entitiesSetToNotTargetable = new HashSet<Entity>();
        }*/
	}

	public override bool UpdateRegen()
	{
		if (base.UpdateRegen())
		{
			var healingTower = (HealingTower)HealingTower.LocalEntity;
			List<Entity> entities = null;

			if(catchPoints == null)
				entities = QuadTreeFinder.FindRect(healingTower.Position.x - healingTower.skillAura.ExplosionRange,
															healingTower.Position.z - healingTower.skillAura.ExplosionRange,
															healingTower.skillAura.ExplosionRange * 2f,
															healingTower.skillAura.ExplosionRange * 2f);
			else
				entities = QuadTreeFinder.FindInPoly(catchPoints);
            
            //if(MapManager.instance.LastLoadedMap.gameMode != GameMode.DeathMatch)
            {
			    foreach(Entity e in entities)
			    {
				    if(!e.IsTargetable)
					    continue;

			        if (e.EntityTeam != healingTower.EntityTeam && healingTower.EntityTeam != Team.None)
			        {
				        e.Controller.HandleHit(e.MaxLife * 0.3f + e.LifeRegen, HealingTower, null);
				        if(healingTower.enemyBoosts == null)
				        {
					        Debug.LogError("Null enemu boosts for healing tower");
				        }
				        else e.Controller.HandleEntityBoosts(healingTower.enemyBoosts);
			        }
			        else if (healingTower.EntityTeam == Team.None && e.State != EntityState.Attack
				         || e.EntityTeam == healingTower.EntityTeam)
			        {
						if(healingTower.boosts == null)
				        {
					        Debug.LogError("Null ally boosts for healing tower");
				        }
				        else
						{
					        e.Controller.HandleEntityBoosts(healingTower.boosts);
							if(e.IsHero)
							{
								Hero hero = (Hero)e;
								if(hero.LastDeathTime > hero.LastAttackTime && hero.LastDeathTime > hero.LastCastTime)
								{
									e.Controller.HandleEntityBoosts(healingTower.invulerabilityBoosts);
								}
								if(e.EntityTeam == Team.East)
									eastHealsCounter++;
								if(e.EntityTeam == Team.West)
									eastHealsCounter++;
							}
						}
			        }
                }
            }

			return true;
		}


		return false;
	}

    public bool HasInHealingRange(IEntityControllable e)
    {
        if (catchPoints == null)
        {
            var localHealingTower = (HealingTower)HealingTower.LocalEntity;
            return HealingTower.HasInRange(e, localHealingTower.skillAura.ExplosionRange);
        }
        else
        {
            return MathSupport.IsInPoly(catchPoints, e.QuadTreePosition);
        }
    }

	public static int EastHealsCounter {
		get {
			return eastHealsCounter;
		}
	}

	public static int WestHealsCounter {
		get {
			return westHealsCounter;
		}
	}
}