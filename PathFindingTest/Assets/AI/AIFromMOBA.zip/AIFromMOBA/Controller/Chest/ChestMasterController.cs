using Assets._Controllable.BasicEntity;
using Assets._Network.Sender.BasicEntity;
using UnityEngine;

public class ChestMasterController : EntityMasterController
{
	public override IEntityControllable Entity { get { return Chest; } }
	protected Chest Chest { get; set; }
	protected float? startFallAt = null;
	
	public override void Initialize()
	{
		Chest = GetEntityComponent<Chest>();
		if (NetworkManager.instance.isMultiplayer)
			Chest.Sender = new EntitySender(Chest);

		base.Initialize();
	}

	public override void UpdateController()
	{
		if (Entity.State == EntityState.Dead)
		{
			if (startFallAt == null) 
				startFallAt = Time.time + 1f;

			if (Entity.LocalEntity.DistributeBody((float) startFallAt))
			{
				Entity.Active = false;
				startFallAt = null;
			}
		}
	}
}
