using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using Assets._Inventory;
using Assets._Network;
using Assets.game;
using Assets._Controllable.BasicEntity;
using Assets._Debug;
using Assets._Manager;
using Assets._Shop;
using UnityEngine;
using Assets._Inventory.New;

public class ChestVendorMasterController : EntityMasterController
{
	public override IEntityControllable Entity { get { return Chest; } }
	public ChestVendor Chest { get; private set; }

	//private List<Hero> _heroes = new List<Hero>();
    //private List<ChestVendor> _chestVendors = new List<ChestVendor>();
    //private bool _isInited;

    public override void Initialize()
    {
        Chest = GetEntityComponent<ChestVendor>();
	    if (NetworkManager.instance.isMultiplayer)
		    Chest.Sender = new ChestVendorSender(Chest);

        GameManager.instance.onGameStartEvent+=OnGameStart;

		//PlayerManager.instance.onPlayerDestroy += RemoveHero;
		//PlayerManager.instance.onPlayerSpawn += AddHero;
		//BotManager.instance.onBotSpawn += AddHero;
		base.Initialize();
    }

    protected void OnDestroy()
    {
        if (GameManager.instance)
            GameManager.instance.onGameStartEvent -= OnGameStart;
		//if (PlayerManager.instance)
		//{
		//	PlayerManager.instance.onPlayerDestroy -= RemoveHero;
		//	PlayerManager.instance.onPlayerSpawn -= AddHero;
		//}
		//if (BotManager.instance)
		//BotManager.instance.onBotSpawn -= AddHero;
    }
	
    public void OnGameStart()
    {
        GameManager.instance.onGameStartEvent -= OnGameStart;
        //_isInited = true;
		//_chestVendors = EntityManager.instance.GetEntitiesOfType(EType.ChestVendor).Cast<ChestVendor>().ToList();

		foreach (var hero in EntityManager.instance.GetEntitiesOfType(EType.Hero))
	    {
		    TryAddItemToHero(hero);
	    }
	    
		//foreach (var hero in _heroes)
		//{
		//	AddConsumablesOnRespawn(hero);
		//}
		//try
		//{
		//	StartCoroutine(AddItemsToHeroesInventory());
		//}
		//catch (Exception ex)
		//{
		//	DebugManager.Log(ex.Message);
		//}
    }
	/*
    private void AddHero(Hero hero)
    {
        try { // PanDenat - try catch added so the PreInitialzer can end initializations even with error here. Error happened on default, Vergen, solo mode.
            _heroes.Add(hero);
            //AddConsumablesOnRespawn(hero);
            hero.onRespawn += AddConsumablesOnRespawn;
			hero.onItemRemoved += OnItemRemoved;
        } catch (NullReferenceException e) { Debug.LogError(e); }
    }

    void OnItemRemoved(Hero hero, Item arg2)
	{
		StartCoroutine(AddItemOnRespawn(hero));
    }

    private void AddConsumablesOnRespawn(IEntityControllable hero)
    {
        StartCoroutine(AddItemOnRespawn(hero));
    }

    private IEnumerator AddItemOnRespawn(IEntityControllable hero)
    {
        Hero localHero = (Hero)hero.LocalEntity;
        while (!localHero.gameObject.activeSelf)
        {
            yield return new WaitForEndOfFrame();
        }

        yield return new WaitForEndOfFrame();

		if(localHero.HeroItemPreferences.Keys.Count != 0)
		{
			TryAddItemToHero(hero);
		}
		else
		{
			Debug.LogError("No keys in hero item preferences");
		}
	}
	 */
	private void TryAddItemToHero(IEntityControllable heroControllable)
	{
		var hero = ((IHeroControllable)heroControllable);
		foreach (ShopCategory itemShopCategory in hero.HeroItemPreferences.Keys) {
			var itemId = hero.HeroItemPreferences.GetItemOrFirstPossible(itemShopCategory);
			if (Chest.ChestShop.Buy(itemId, hero.Wallet, hero.ConsumableInventory) != null) {
				//CloseAllChestsForEntity(hero as Hero);
			}
		}
		
	}
	/*
	private void RemoveHero(Hero hero)
    {
        hero.onRespawn -= AddConsumablesOnRespawn;
        _heroes.Remove(hero);
    }

	protected override void OnEnable() {
		base.OnEnable();
		if (_isInited)
			StartCoroutine(AddItemsToHeroesInventory());
	}

    private IEnumerator AddItemsToHeroesInventory()
    {      
        while (true)
        {
            foreach (var hero in _heroes)
            {
				var heroControllable = ((IHeroControllable)hero.Controller.Entity);

	            if (Chest.GetNextOpenTimeForEntity(heroControllable) < SyncTools.Time && hero.HasInRange(Chest, Chest.Range))
	            {
					TryAddItemToHero(hero);
	            }
            }
            yield return new WaitForSeconds(Chest.UpdateInterval);
        }
    }
	

    private void CloseAllChestsForEntity(Hero hero)
    {
        foreach (var chestVendor in _chestVendors)
        {
            var chestVendorControllable = (IChestVendorControllable)chestVendor.Controller.Entity;
	        chestVendorControllable.SetNextOpenTimeForEntity(hero, SyncTools.Time + InventorySettings.currentInstance.chestVendorItemAddCooldown*1000);
		    chestVendorControllable.SetIsOpenedForEntity(hero, false);
            
        }
    }
	 */

}
