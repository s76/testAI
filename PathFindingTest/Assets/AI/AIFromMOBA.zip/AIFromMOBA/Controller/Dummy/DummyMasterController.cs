﻿using Assets._AI.Controller.BasicEntity;
using Assets._Controllable.BasicEntity;
using Assets._Controllable.DummyEntity;
using Assets._Network.Sender.BasicEntity;
using System;
using System.Collections.Generic;
using UnityEngine;

namespace Assets._AI.Controller.Dummy {
    class DummyMasterController : MoverMasterController {
		DummyEntity _Mover;
        protected override IMoverControllable Mover { get { return _Mover; } }
        protected override IAttackerControllable Attacker { get { return _Mover; } }
        public override IEntityControllable Entity { get { return _Mover; } }

        public override void Initialize() {
            _Mover =GetEntityComponent<DummyEntity>();
	        if (NetworkManager.instance.isMultiplayer)
				_Mover.Sender = new MoverSender(_Mover);
            if (Mover == null) Debug.LogError("[DummyMasterController] Cannot obtain Entity.", this);
            base.Initialize();
        }
    }
}
