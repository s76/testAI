﻿using Assets._Controllable.BasicEntity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Assets._AI.Controller {
    public static class NoAITypes {
        public static EType[] types = new EType[] {
            EType.Base,
            EType.BridgeSupport,
            EType.HealingTower,
            EType.ConquestPoint,
            EType.Vendor,
            EType.Chest,
        };

        public static bool Contains(EType type)
        {
            for (int i = 0; i < types.Length; i++)
            {
                if (types[i] == type) return true;
            }
            return false;
        }
    }
}
