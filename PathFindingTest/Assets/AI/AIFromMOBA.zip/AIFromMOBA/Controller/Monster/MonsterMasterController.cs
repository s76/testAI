﻿using Assets._AI.Controller.BasicEntity;
using Assets._Controllable.BasicEntity;
using Assets._Debug;
using Assets._Network.Sender.BasicEntity;

class MonsterMasterController : MoverMasterController
{
	public override IEntityControllable Entity { get { return Monster; } }
    protected override IAttackerControllable Attacker { get { return Monster; } }
    protected override IMoverControllable Mover { get { return Monster; } }
	protected Monster Monster { get; set; }
    private bool initializeHasRun = false;

    public override void Initialize()
    {
        Monster= GetEntityComponent<Monster>();
	    if (NetworkManager.instance.isMultiplayer)
		    Monster.Sender = new MoverSender(Monster);

        base.Initialize();
        pathFinding.repathRate = 1f;
        initializeHasRun = true;
        GetComponent<Reactor>().Initialize();
        //pathFinding.TrySearchPath();
    }


    protected override void OnEnable()
    {
        if (initializeHasRun && DebugManager.options[DebugOption.react]) GetEntityComponent<Reactor>().enabled = true;
    }
}
