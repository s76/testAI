using Assets._Controllable.BasicEntity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using UnityEngine;

class ArachaMasterController : MonsterMasterController {
    public override void Initialize() {
        base.Initialize();
        onHandleHit += ArachaAIController_onHandleHit;
    }

    void ArachaAIController_onHandleHit(float dmg, IAttackerControllable attacker, Skill skill) {
        if (Mathf.Approximately(Entity.Life, 0f)) {
            Entity.LostLife = Entity.MaxLife - 1f;

            //Entity.State = EntityState.Dead;
            Entity.LastHitter = attacker;
            Entity.LastHitTime = Time.time;
			Entity.Killer = Entity.ComputeLastKiller();
            EntityManager.instance.NotifyEntitiesAboutDeath(Entity, Entity.Killer, Entity.EntityType == EType.Hero ? Entity.Cast<Hero>().HitList : Enumerable.Empty<HitInfo>());
            Entity.FireOnDeath();
        }
    }
}

