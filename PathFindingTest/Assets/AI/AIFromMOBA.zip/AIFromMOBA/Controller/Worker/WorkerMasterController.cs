﻿/*using Assets._AI.Controller.BasicEntity;
using Assets._Controllable.BasicEntity;
using Assets._Network.Sender.BasicEntity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

class WorkerMasterController : MoverMasterController {
    protected IMoverControllable Worker { get; set; }

    public override void Initialize() {
        Worker = NetworkManager.instance.isMultiplayer
            ? (IMoverControllable)new MoverSender(GetEntityComponent<Worker>())
            : GetEntityComponent<Worker>();

        base.Initialize();
    }

    protected override IMoverControllable Mover {
        get { return Worker; }
    }

    protected override IAttackerControllable Attacker {
        get { return Worker; }
    }

	public override IEntityControllable Entity {
        get { return Worker; }
    }
}
*/