﻿/*using Assets._AI.Actions;
using Assets._Controllable.BasicEntity;
using React;
using System.Collections;

class WorkerActions : MoverActions {

    protected IMoverControllable Worker { get; set; }
	private Worker workerLocal;

    public override void Initialize(IEntityControllable entity) {
        base.Initialize(entity);
	    Worker = (IMoverControllable) entity;
	    workerLocal = entity.Cast<Worker>();
    }

    public IEnumerable GoToWork() {
        Worker.MoveTargetPosition = Worker.Cast<Worker>().workStation.Position;
        while (!IsNearWork()) yield return NodeResult.Continue;
        yield return NodeResult.Success;
    }

    public float distanceNearFromWork = 5;

	private bool IsNearWork() {
		return Worker.HasInRange(workerLocal.workStation.Position, distanceNearFromWork);
    }

    public IEnumerable GoToEmptyWorkPlace() {
		workerLocal.targetedWorkPlace = workerLocal.workStation.GetFreeWorkPlace();
		if (workerLocal.targetedWorkPlace == null) yield return NodeResult.Failure;

		Worker.MoveTargetPosition = workerLocal.targetedWorkPlace.Position;
        if (IsAtWorkPlace()) {
            Worker.MoveTargetPosition = Worker.Position;
            yield return NodeResult.Success;
        } else yield return NodeResult.Failure;
    }

    private bool IsAtWorkPlace() {
		return workerLocal.workStation.RegisterWorker(workerLocal, workerLocal.targetedWorkPlace);
    }

    public IEnumerable Work() {
        //while (!workerLocal.workStation.RegisterWorker(workerLocal, workerLocal.targetedWorkPlace))
        //    yield return NodeResult.Continue;

        //Worker.MoveTargetPosition = Worker.Position;
        //Worker.State = EntityState.Stay;
        
		Worker.Rotation = workerLocal.targetedWorkPlace.Rotation;
        while (Worker.State == EntityState.Repair
            || Worker.State == EntityState.Work) yield return NodeResult.Continue;
        yield return NodeResult.Failure;
    }
}

*/