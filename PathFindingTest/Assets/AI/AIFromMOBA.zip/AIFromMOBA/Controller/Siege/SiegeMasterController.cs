/*
public class SiegeMasterController : AttackerMasterController
{
	public override IEntityControllable Entity { get { return Siege; } }
	protected override IAttackerControllable Attacker { get { return Siege; } }
	protected ISiegeControllable Siege { get; set; }
    private SiegeAnimationController _animation;
	
	public override void Initialize()
	{
		Siege = NetworkManager.instance.isMultiplayer
					? (ISiegeControllable) new SiegeSender(GetEntityComponent<Siege>())
					: GetEntityComponent<Siege>();

        _animation = GetComponentInChildren<SiegeAnimationController>();
        _animation.Initialize(Siege);

		base.Initialize();
	}

	protected override void Update()
	{
		base.Update();
		
		if(Siege.Lvl < MinionManager.instance.RequestedMinionLvl)
		{
			Siege.Exp = Siege.NextLevelExp + 1;
		}
	}

    // - co to za bezsens?
	//public override void AnswerHelpCall(IEntityControllable entity)
	//{
	//	if (Attacker.AttackTarget != null && Attacker.AttackTarget.EntityType == EType.Hero) 
	//		return;

	//	if (entity.EntityType == EType.Hero && entity.LastHitter.EntityType == EType.Hero)
	//	{
	//		if (Attacker.CanTargetEnemy(entity)) Attacker.AttackTarget = entity;
	//	}
	//}

    public override void HandleSupport(float heal, IAttackerControllable supporter, Skill skill) {
        base.HandleSupport(heal, supporter, skill);

        if (Entity.Life >= Entity.MaxLife && Entity.State == EntityState.Destroyed) {
            Siege.State = EntityState.Stay;
        }
    }

	public override void HandleHit(float dmg, IAttackerControllable attacker, Skill skill, bool forceDmg = false) 
	{
		if (Entity.IsAlive == false || attacker.CanTargetEnemy(Entity) == false) return;

        var hit = Entity.ReceiveHit(dmg, attacker, skill);

        if (Entity.Life <= 0f && Entity.State != EntityState.Destroyed)
            Siege.State = EntityState.Destroyed;
        
        EntityManager.instance.NotifyEntitiesAboutHit(Entity, attacker, hit);
    }
}
*/
