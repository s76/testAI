using Assets._Controllable.BasicEntity;

public class SimpleSpawnMasterController : EntityMasterController
{
	public override IEntityControllable Entity { get { return Spawn; } }
	protected SimpleSpawn Spawn { get; set; }
	
	public override void Initialize()
	{
		if (Spawn == null)
		{
			Spawn = GetEntityComponent<SimpleSpawn>();
			if (NetworkManager.instance.isMultiplayer)
				Spawn.Sender = new SimpleSpawnSender(Spawn);

		}
		else if (NetworkManager.instance.isMultiplayer)
		{
			Spawn.Sender.Reactivate();
		}
		base.Initialize();
	}

	public override void HandleSupport(float heal, IAttackerControllable supporter, Skill skill)
	{
		if(Spawn.SpecialistationOfSpawn != SpawnSpecialisation.Shield || supporter.Id == Spawn.SpawnOwner.Id)//block shield regen healing 
			base.HandleSupport(heal, supporter, skill);
	}

}
