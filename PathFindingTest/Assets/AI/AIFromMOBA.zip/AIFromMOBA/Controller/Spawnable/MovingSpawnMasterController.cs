using Assets._Controllable.BasicEntity;
using Assets._AI.Controller.BasicEntity;
using Assets._Network.Sender.BasicEntity;

public class MovingSpawnMasterController : MoverMasterController
{
	public override IEntityControllable Entity { get { return Spawn; } }
	protected override IAttackerControllable Attacker { get { return Spawn; } }
	protected override IMoverControllable Mover { get { return Spawn; } }
	protected MovingSpawn Spawn { get; set; }
	
	public override void Initialize()
	{
		if (Spawn == null)
		{
			Spawn = GetEntityComponent<MovingSpawn>();
			if (NetworkManager.instance.isMultiplayer)
				Spawn.Sender = new MovingSpawnSender(Spawn);
		}
		else if (NetworkManager.instance.isMultiplayer)
		{
			Spawn.Sender.Reactivate();
		}
		base.Initialize();
	}
}
