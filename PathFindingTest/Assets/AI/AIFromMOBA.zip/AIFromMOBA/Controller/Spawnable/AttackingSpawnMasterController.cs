using Assets._Controllable.BasicEntity;

public class AttackingSpawnMasterController : AttackerMasterController
{
	public override IEntityControllable Entity { get { return Spawn; } }
	protected override IAttackerControllable Attacker { get { return Spawn; } }
	protected AttackingSpawn Spawn { get; set; }

	public override void Initialize()
	{
		if (Spawn == null)
		{
			Spawn = GetEntityComponent<AttackingSpawn>();
			if (NetworkManager.instance.isMultiplayer)
				Spawn.Sender = new AttackingSpawnSender(Spawn);
		}
		else if (NetworkManager.instance.isMultiplayer)
		{
			Spawn.Sender.Reactivate();
		}
		base.Initialize();
	}
	
}
