using System;
using System.Collections.Generic;
using System.Linq;
using AbilityCalculator;
using Assets._Client;
using Assets._Controllable.BasicEntity;
using Assets._Controllable._EntityPreferences;
using Assets._Controller;
using Assets._Debug;
using Assets._Network.Sender.BasicEntity;
using UnityEngine;
using Assets._AI.Controller;

public abstract class EntityMasterController : IEntityController
{
	public override event OnEntityBoostRecieve onBoostRecieve;
	public override event OnEntityBoostRecieve onBoostRemove;
	public override event OnHandleHit onHandleHit = (dmg, attacker, skill) => {};
	public override event OnHandleSupport onHandleSupport = (heal, attacker, skill) => {};
	public override event OnHandleKill onHandleKill = (victim, killState) => {};
	
	OnControllerCommand onCommand;
	public override event OnControllerCommand onCommandEvent
	{
		add
		{
			onCommand += value;
		}
		
		remove
		{
			onCommand -= value;
		}
	}
	
	protected Transform trans;
	protected Boolean massKill = false;
    protected EntityActions actions;

	protected Boolean IsRotable
	{
		get { return Entity.EntityType != EType.Tower; }
	}

	public override bool IsEntityMaster
	{
		get { return true; }
	}

	/*** Last Time sth
        */
	protected float lastEnemySearchTime = 0;
	/*** ***/

	protected IEntityControllable closestEnemy = null;
	
	public override void Initialize()
	{
		trans = transform;

        InitActions();
	    StartReact();

		isInitialized = true;
		enabled = true;

		onBoostRecieve += Entity.OnBoostRecieve;
		onBoostRemove += Entity.OnBoostRemove;

		base.Initialize();
	}

    //override in HeroMasterController to switch off react
    protected virtual void StartReact()
    {
        if (DebugManager.options[DebugOption.react])
        {
            if (GetEntityComponent<Reactor>() != null)
            {
                if (Entity.Active)
                {
                    Reactor reactor = GetEntityComponent<Reactor>();
                    reactor.Initialize();
                    reactor.enabled = true;
                }
            }
            else if (NoAITypes.Contains(Entity.EntityType) == false)
			{
/*#if UNITY_EDITOR
                Debug.LogWarning("[AI] NO REACT - AI Error in " + "[" + Entity.EntityType + "]" + Entity.EntityName);
#endif*/
			}
        }
    }

    private void InitActions() {
        actions = GetEntityComponent<EntityActions>();
        if (actions != null)
            actions.Initialize(Entity);
        /*else if (NoAITypes.Contains(Entity.EntityType) == false) 
		{
#if UNITY_EDITOR
            Debug.LogWarning("[AI] no actions in " + "[" + Entity.EntityType + "]" + Entity.EntityName);
#endif
		}*/
    }

    protected virtual void Update()
	{
		if (isInitialized && Entity.Active)
		{
 			UpdateController();
 			if(Entity.State != EntityState.Dead) UpdateRegen();
 			Entity.UpdateEntity();
 		}
	}

	public override void UpdateInactive()
	{
		if (NetworkManager.IsMultiplayerGameMaster)
			Entity.LocalEntity.Sender.UpdateSender();
	}

	public override void UpdateController()
	{
		if(Entity.State == EntityState.Dead && Entity.LocalEntity.DistributeBody())
		{
			Entity.Active = false;
		}
	}

	/// <summary>
	/// Updates the regen.
	/// </summary>
	/// <returns>
	/// Returns if regen is done in this frame
	/// </returns>
	private float lastRegenUpTime;
	public virtual bool UpdateRegen()
	{
		const float updateRegenInterval = Assets._Controllable.BasicEntity.Entity.updateRegenInterval;
		if(lastRegenUpTime + updateRegenInterval < Time.time)
		{
			var lifeRegen = Entity.LocalEntity.lifeRegen;
			float regen = lifeRegen.BaseValue * updateRegenInterval
							* (Entity.State == EntityState.Attack || Entity.State == EntityState.Cast || Entity.LastHitTime + 1f > Time.time ? 0.5f : 1f);

            if (!Entity.IsHypothermic && options.LifeRegen)//if not hypotherm then get regeneration
				Entity.LostLife -= regen;

			lifeRegen.BoostCheck();

			for (int i = 0; i < lifeRegen.Boosts.Count; i++)
			{
				EntityBoost boost = lifeRegen.Boosts[i];
				if (boost.val > 0f && Math.Abs(Entity.Life - Entity.MaxLife) < 0.001f)
					continue;

				if (boost.val > 0f)
				{
					float val = boost.val * updateRegenInterval;
					if(Entity.IsMover)
					{
                        var mover = (IMoverControllable)Entity;
						if(mover.IsBleeding)
							val *= 0.33f;
						else if(mover.IsIncinerated)
							val *= 0.66f;
					}
					HandleSupport(val, boost.Owner, null);
				}
				else if(Entity.IsTargetable)
					HandleHit(-boost.val * updateRegenInterval, boost.Owner, null, true);
			}

			lastRegenUpTime = Time.time;
			return true;
		}

		return false;
	}

//	public void AddState(EntityState stateMask)
//	{
//		Entity.ExtendedState = (Entity.ExtendedState | stateMask);
//	}
//
//	public void RemoveState(EntityState stateMask)
//	{
//		Entity.ExtendedState = (Entity.ExtendedState & (ExtendedState.All ^ stateMask));
//	}

	/*
        * Czy bot żyje
        */
	public bool IsAliveAndActive()
	{
		return Entity.State != EntityState.Dead && Entity.Active;
	}

	/* Czy zabijac wszystkich jak leci
        */
	public bool isMassKiller()
	{
		return massKill;
	}
	
	public override void OnCommandEvent()
	{
		if(onCommand != null)
			onCommand();
	}

	public bool hasTargetFighter()
	{
		return false; // TargetFighter != null;
	}

	public override void HandleHit(float dmg, IAttackerControllable attacker, Skill skill, bool forceDmg = false)
	{
		if(Entity.IsAlive)
		{
			if (skill != null)
			{
				List<EntityBoost> eBoosts = skill.EnemyBoosts;
				HandleEntityBoosts(eBoosts);
			}

			if(forceDmg)
			{
				Entity.ReceiveHit(dmg, attacker, skill);
				Entity.LostLife += dmg;
			}
			else
			{
				float hitReceiveDmg = dmg;

				for(byte i = 0; i < Entity.DamageRedirectList.Count; i++)
				{
					DamageRedirectInfo info = Entity.DamageRedirectList[i];
					if(info.target == null || info.target.State == EntityState.Dead)
					{
						Entity.DamageRedirectList.RemoveAt(i--);
						continue;
					}

					bool targetableTmp = info.target.LocalEntity.isTargetable;
					info.target.LocalEntity.isTargetable = true;
					
					if(!info.target.IsTargetable)
						continue;

					float lifeTmp = info.target.Life;
					info.target.Controller.HandleHit(hitReceiveDmg * info.dmgFactor, attacker, skill);
					float lifeDiff = lifeTmp - info.target.Life;

					if(info.manaCost > 0f && Entity.EntityType == EType.Hero)
					{
						IHeroControllable hero = (IHeroControllable)Entity;
						float manaCost = lifeDiff * info.manaCost;
						float manaDmgFactor = hero.Mana / manaCost;
						if(manaDmgFactor < 1f)
							lifeDiff *= manaDmgFactor;
						hero.LostMana += manaCost;
					}

					info.target.LocalEntity.isTargetable = targetableTmp;

					hitReceiveDmg -= lifeDiff;
				}
				
				hitReceiveDmg = Entity.ReceiveHit(hitReceiveDmg, attacker, skill);
				Entity.LostLife += hitReceiveDmg;

				if(!Entity.IsBuilding && skill == null && attacker.Vampirism > 0f)
					attacker.Controller.HandleSupport(hitReceiveDmg * attacker.Vampirism, attacker, null);
			}
		}

		onHandleHit(dmg, attacker, skill);
		
		if(Entity.IsAlive && Entity.Life < 0.01f)
		{
			Entity.StateSync = EntityState.Dead;
			Entity.LastHitter = attacker;
			Entity.LastHitTime = Time.time;
			Entity.Killer = Entity.ComputeLastKiller();
			EntityManager.instance.NotifyEntitiesAboutDeath(Entity, Entity.Killer, Entity.EntityType == EType.Hero ? Entity.Cast<Hero>().HitList : Enumerable.Empty<HitInfo>());
		}
	}
	
	public override void HandleSupport(float heal, IAttackerControllable supporter, Skill skill)
	{
		if (skill != null)
		{
			List<EntityBoost> eBoosts = skill.AllyBoosts;
			HandleEntityBoosts(eBoosts);
		}

		Entity.LostLife -= Entity.ReceiveSupport(heal, supporter, skill);
		
		onHandleSupport(heal, supporter, skill);
		
		if(Entity.IsAlive && Entity.Life < 0.01f)
		{
			Entity.StateSync = EntityState.Dead;
			Entity.LastHitter = supporter;
			Entity.LastHitTime = Time.time;
			Entity.Killer = Entity.ComputeLastKiller();
			EntityManager.instance.NotifyEntitiesAboutDeath(Entity, Entity.Killer, Entity.EntityType == EType.Hero ? Entity.Cast<Hero>().HitList : Enumerable.Empty<HitInfo>());
		}
	}

	public override void HandleEntityBoosts(List<EntityBoost> boosts)
	{
		foreach( EntityBoost boost in boosts )
		{
			onBoostRecieve(new EntityBoost(boost));
		}
	}

	public override void HandleEntityBoost(EntityBoost boost)
	{
		if(onBoostRecieve != null)
			onBoostRecieve(new EntityBoost(boost));
	}
	
	public override void HandleRemoveEntityBoost(EntityBoost boost)
	{
		if(onBoostRemove != null)
			onBoostRemove(boost);
	}

	public override void HandleRemoveEntityBoosts(List<EntityBoost> boosts)
	{
		foreach( EntityBoost boost in boosts )
		{
			HandleRemoveEntityBoost(boost);
		}
	}
	
	public override void HandleEntityDeath(IEntityControllable victim, IAttackerControllable attacker, IEnumerable<HitInfo> assisters)
	{
		if(attacker.Id == Entity.Id)
			onHandleKill(victim, KillState.Killer);
	}
		
	public override void Respawn(Vector3 pos)
	{
		if(Entity.Active != false)
			Entity.Active = false;
		Entity.Trans.position = pos;
		Entity.Active = true;
		Entity.StateSync = EntityState.Stay;
        Entity.FixedPosition = pos;
		Entity.LostLife = 0f;
		Entity.Reset();
	}

	public override void SetLostEntityLife(float val)
	{
		Entity.LostLife = val;
	}

	public override void SlideToPosition (Vector3 pos, float slideTime = 0.5f)
	{
	}

	public override void BindToPos (Vector3 pos, float range, float slideSpeed, float time)
	{
	}

	public override void FlyOverGround (float yOffset, float time)
	{
	}

	public override void AddDamageRedirection (DamageRedirectInfo info)
	{
		Entity.DamageRedirectList.Add(info);
		info.target.onDeath += OnRedirectTargetDeath;
	}

	public override void RemoveDamageRedirection(IEntityControllable target)
	{
		for(byte i = 0; i < Entity.DamageRedirectList.Count; i++)
		{
			DamageRedirectInfo info = Entity.DamageRedirectList[i];
			if(info.target.Id == target.Id)
			{
				Entity.DamageRedirectList.RemoveAt(i--);
			}
		}
	}

	public void OnRedirectTargetDeath(IEntityControllable target)
	{
		RemoveDamageRedirection(target);
		target.onDeath -= OnRedirectTargetDeath;
	}

    public DebugOptions options
    {
        get { return Entity.LocalEntity.options; }
    }

}

