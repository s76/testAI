using System.Collections.Generic;
using Assets._Client;
using Assets._Controllable.BasicEntity;
using React;
using UnityEngine;

public abstract class AttackerMasterController : EntityMasterController
{
	protected abstract IAttackerControllable Attacker { get; }

	public override void HandleEntityDeath(IEntityControllable victim, IAttackerControllable attacker, IEnumerable<HitInfo> assisters)
	{
		base.HandleEntityDeath(victim, attacker, assisters);
		if(attacker.HasAttackTarget && attacker.Id == Entity.Id && Attacker.AttackTarget.Id == victim.Id)
		{
			Attacker.AttackTarget = null;
		}
	}

	public void AttackNextTarget(EType targetType, double? targetAngle = null)
	{
		if (IsBlocked || Attacker.Active == false || Attacker.State == EntityState.Dead)
			return;

		((AttackerActions)actions).AttackNextTargetInVisibilityRange(targetType, targetAngle);
		Attacker.AttackMode = AttackMode.Manual;
		OnCommandEvent();
	}

    public void AttackEnemyClosestToPointInVisibilityRange(Vector3 centerPosition, EType targetType = EType.Any)
	{
		if (IsBlocked || Attacker.Active == false || Attacker.State == EntityState.Dead)
			return;

        ((AttackerActions)actions).AttackEnemyClosestToPointInVisibilityRange(centerPosition, targetType);
        
		Attacker.AttackMode = AttackMode.Manual;
		OnCommandEvent();
	}

    public void AttackEnemyClosestToPointInVisibilityRange(ICollection<Entity> entities, Vector3 centerPosition, float range, EType targetType = EType.Any)
    {
        if (IsBlocked || Attacker.Active == false || Attacker.State == EntityState.Dead)
            return;

        IEnumerator<NodeResult> e = ((AttackerActions)actions).AttackClosestEnemyInRange(entities, range, centerPosition, targetType);
        while (e.MoveNext()) { }
        Attacker.AttackMode = AttackMode.Manual;
        OnCommandEvent();
    }

	public override void UpdateController()
	{
		base.UpdateController();

		if (Attacker.State == EntityState.Dead) return;
		UpdateState();
	}

	protected virtual void UpdateState()
	{
		if (Attacker.HasAttackTarget)
		{
			if (Attacker.CanTargetEnemy(Attacker.AttackTarget))
			{
				bool hasInAttackRangeAndLos = Attacker.HasInAttackRange(Attacker.AttackTarget) &&
				                              Attacker.HasInLineOfSight(Attacker.AttackTarget);
				if (Attacker.State == EntityState.Stay && hasInAttackRangeAndLos)
				{
					if (Attacker.AttackTarget.EntityTeam != Attacker.EntityTeam && Attacker.AttackTarget.EntityTeam != Team.None)
					{
						Attacker.StateSync = EntityState.Attack;
					}
					else
					{
						Attacker.StateSync = EntityState.Stay;
					}
				}
				else if (!hasInAttackRangeAndLos)
				{
					Attacker.StateSync = EntityState.Stay;
				}
			}
			else
			{
				Attacker.AttackTarget = null;
				Attacker.StateSync = EntityState.Stay;
			}
		}
		else
		{
			Attacker.StateSync = EntityState.Stay;
		}
	}
}