using System;
using System.Collections;
using System.Collections.Generic;
using AbilityCalculator;
using Assets._Client;
using Assets._Controllable.BasicEntity;
using Assets._Debug;
using UnityEngine;
using Assets._Manager;
using Assets._Pathfinding;

namespace Assets._AI.Controller.BasicEntity
{
    public abstract class MoverMasterController : AttackerMasterController
    {
	    protected EntityPath pathFinding;

	    internal EntityPath PathFinding
	    {
		    get { return pathFinding; }
	    }

	    protected abstract IMoverControllable Mover { get; }
        protected Mover LocalMover { get { return (Mover)Mover.LocalEntity; } }
		
        public override void Initialize()
        {
			// EntityPath
			pathFinding = GetEntityComponent<EntityPath>() ?? gameObject.AddComponent<EntityPath>();
			pathFinding.enabled = true;
			pathFinding.Initialize();

            base.Initialize();
        }

	    public override void UpdateController()
		{	
			base.UpdateController();
			UpdateFly();
			UpdateFall();

			pathFinding.canMove = Mover.State == EntityState.Run;
			//pathFinding.canSearch = Mover.State == EntityState.Run;
			if(Mover.State == EntityState.Dead) return;
			
			UpdateBind();
			UpdateSlide();
		}

		public override bool UpdateRegen()
		{
			if (base.UpdateRegen())
			{
				if (Mover.IsBleeding)
				{
					var mover = (Mover)Mover.LocalEntity;
					HandleHit(0.02f * Mover.MaxLife, mover.bleeding.Boosts[0].Owner, null, true);
				}

				if (Mover.IsIncinerated)
				{
					var mover = (Mover)Mover.LocalEntity;
					HandleHit(0.05f * Mover.MaxLife, mover.incineration.Boosts[0].Owner, null, true);
				}
				return true;
			}
			return false;
		}

		public override void Respawn(Vector3 pos)
		{
			base.Respawn(pos);
			Mover.MoveTargetPosition = pos;
			Mover.PredictedPath = null;
			pathFinding.Reset();
		}

		public override void HandleEntityDeath(IEntityControllable victim, IAttackerControllable attacker, IEnumerable<HitInfo> assisters)
		{
			base.HandleEntityDeath(victim, attacker, assisters);
			if (attacker.Id == Entity.Id && Attacker.HasAttackTarget && Attacker.AttackTarget.Id == victim.Id)
			{
				Mover.MoveTargetPosition = Mover.Position;
			}
		}

		/// <summary>
		///     Moves to position on map.
		/// </summary>
		/// <param name='pos'>
		///     Position.
		/// </param>
		/// <param name='b'>
		///     B.
		/// </param>
		public virtual void MoveToPositionOnMap(Vector3 pos)
		{
			if (!CanMoveCheck())
			{
				if(Mover.State == EntityState.Cast)
					Mover.MoveTargetPosition = pos;
				return;
			}

			Mover.MoveTargetPosition = pos;
//			Mover.State = EntityState.Run;
			OnCommandEvent();
		}

		public virtual void MoveInDirection(Vector3 direction)
		{
			if(!CanMoveCheck() && direction != Vector3.zero) return;

			Mover.DirectionOfJoy = direction;
//			Mover.State = EntityState.Run;
			OnCommandEvent();
		}

		/// <summary>
		/// Returns true if entity can move
		/// </summary>
		/// <returns></returns>
		protected bool CanMoveCheck()
		{
			if(!Mover.IsAlive ||
			   (Mover.State == EntityState.Cast 
			 		&& Mover.LastCastedSkill != null 
			 		&& !Mover.LastCastedSkill.CanBeCastedInRun 
			 		&& Mover.LastState == EntityState.Run))
			{
				return false;
			}

			return true;
		}

		/// <summary>
		///     Attacks the or follow the entity.
		/// </summary>
		/// <param name='e'>
		///     targeted entity
		/// </param>
		/// <param name='b'>
		///     B.
		/// </param>
		public virtual void AttackOrFollow(IEntityControllable e) // what is b for?
		{
			if (Mover.Active == false || Mover.State == EntityState.Dead)
				return;

			DebugManager.LogCommand(this);

			Mover.AttackTarget = e;
			Mover.AttackMode = AttackMode.Manual;

			OnCommandEvent();
		}

		protected override void UpdateState()
		{
			if (Mover.State == EntityState.Dead) return;

			if (Mover.IsStunned || Mover.IsDisarmed)
			{
				Mover.StateSync = EntityState.Stay;
				return;
			}

			if(Mover.State == EntityState.Run && Mover.IsSnared)
			{
				Mover.StateSync = EntityState.Stay;
			}


			if (Mover.State == EntityState.Cast && Mover.LastStateChangeTime + 1f > Time.time)
			{
				return;
			}
			
			////var localMover = (Mover)Mover; //!!!!INVALID CAST Mover mo�e byc senderem!!!!
		    var localMover = LocalMover;

			// je�li mamy AttackTarget
			if (Mover.HasAttackTarget)
			{
				switch (Mover.State)
				{
					case EntityState.Run:
					case EntityState.Stay:
						// je�li cel jest w zasi�gu ataku
						if (Mover.HasInAttackRange(Mover.AttackTarget))
						{
							// jesli jest wrogiem to atakujemy, w przeciwnym przypadku stoimy
							Mover.StateSync = Mover.CanTargetEnemy(Mover.AttackTarget) ? EntityState.Attack : EntityState.Stay;
						}
						else goto default;
						break;

					default:
						// cel poza zasi�giem
						if (!Mover.HasInAttackRange(Mover.AttackTarget))
						{
							if (localMover.IsPreparingAttack || localMover.IsFinishingAttack) return; //nie ruszaj sie od razu po ataku
							// biegniemy w jego kierunku
							Mover.StateSync = EntityState.Run;
						}
						break;
				}
			}
			else if (Mover.HasReachedMoveTarget() == false && Mover.MoveTargetPosition != Vector3.zero)
			{
				Mover.StateSync = EntityState.Run;
			}
			else
			{
				if (Mover.State == EntityState.Repair || Mover.State == EntityState.Work) return;
				else Mover.StateSync = EntityState.Stay;
			}
		}
		
		protected void UpdateSlide()
		{
			if(Mover.TimeToStopSlide == -1f)
				return;
			
			if(Mover.TimeToStopSlide <= NetworkManager.instance.ServerTimeInSeconds)
			{
				if((AstarPath.active.GetNearest(Mover.SlidePosition).clampedPosition - Mover.SlidePosition).SqrMagnitudeXZ() < 1f)
				{
                    Mover.MoveTargetPosition = Mover.Position;
				}
				Mover.TimeToStopSlide = -1f;
				return;
			}

			if(Mover.MaxSlideTime < 0.001f)
				return;

			Vector3 currSlideV = Mover.SlideV * Time.deltaTime / Mover.MaxSlideTime;

			if(float.IsNaN(currSlideV.x))
			{
				Debug.LogError("Nan in currSlideV");
				return;
			}
			float slideDist = currSlideV.magnitude;

            Mover.SlideRangeLeft = (Mover.SlidePosition - Mover.Position).magnitude;
			
			if(Mover.SlideRangeLeft < slideDist)
			{
				currSlideV = currSlideV.normalized * (Mover.SlideRangeLeft);
				Mover.TimeToStopSlide = -1f;
			}
			
			Vector3 newPos = Mover.Position + currSlideV;

			Vector3 outPos = AstarPath.active.GetNearest(newPos).clampedPosition;

			if((newPos - outPos).SqrMagnitudeXZ() > 0.02f)
			{
				newPos = outPos;
			}
			
			newPos.y = Mathf.Max(HeightMap.GetHeight(newPos), Mover.Position.y - 2f);
			
			if(Mover.IsFlying)
			{
				newPos.y = Mover.Position.y;
			}
			
			if(float.IsNaN(newPos.x))
			{
				Debug.LogError("Nan in newPos");
				return;
			}

			Vector3 lookV = newPos - Mover.Position;
			if(Mathf.Abs(lookV.x) > 0.01f && Mathf.Abs(lookV.z) > 0.01f)
			{
				lookV.y = 0f;
				((Mover)Mover.LocalEntity).RotateTowardsNow(lookV);
			}

			Mover.Position = newPos;
			Mover.MoveTargetPosition = Mover.Position;
		}
		
		protected void UpdateBind()
		{
			if(Mover.TimeToStopBind == -1f)
				return;
			
			if(Mover.TimeToStopBind <= NetworkManager.instance.ServerTimeInSeconds)
			{
				Mover.TimeToStopBind = -1f;
				return;
			}

			Vector3 dir = Mover.BindPosition - Mover.Position;
			float sqrMagnitude = dir.sqrMagnitude;
			if(sqrMagnitude > Mover.BindRange * Mover.BindRange)
			{
				Mover.Position = Mover.BindPosition + dir.normalized * -Mover.BindRange;
			}
			else if(sqrMagnitude > Mover.BindSpeed * Mover.BindSpeed)
			{
				Mover.Position = Mover.Position + dir.normalized * Mover.BindSpeed;
			}
		}
		
		protected void UpdateFly()
		{
			if(Mover.TimeToStopFly == -1f)
				return;
			
			if(Mover.TimeToStopFly <= NetworkManager.instance.ServerTimeInSeconds)
			{
				Mover.Position = new Vector3(Mover.Position.x, HeightMap.GetHeight(Mover.Position), Mover.Position.z);
				Mover.TimeToStopFly = -1f;
				return;
			}

			float timeDiff = Mover.TimeToStopFly - Mover.FlyStartTime;
			if(timeDiff < 0.00001f)
				return;
			Mover.Position = new Vector3(Mover.Position.x, 
			                             HeightMap.GetHeight(Mover.Position) + Mover.FlyOffset 
			                             	* Mathf.Abs(Mathf.Sin(180f * (NetworkManager.instance.ServerTimeInSeconds - Mover.FlyStartTime) 
			                      						/ timeDiff * Mathf.Deg2Rad)),
			                             Mover.Position.z);
		}

		void UpdateFall()
		{
			if(!Mover.IsFalling)
				return;

			LayerMask mask = (1 << LayerMask.NameToLayer("Obstacles"));
			RaycastHit hit;
			if(Physics.Raycast(new Ray(Mover.Position + Vector3.up, Vector3.down), out hit, 1000f, mask))
			{
				Mover.Position = hit.point;
			}
		}
		
		public override void SlideToPosition(Vector3 pos, float slideTime = 0.5f)
		{
			Mover.MaxSlideTime = slideTime;
			Mover.TimeToStopSlide = NetworkManager.instance.ServerTimeInSeconds + Mover.MaxSlideTime;

			pos = AstarPath.active.GetNearest(pos).clampedPosition;
			if(float.IsNaN(pos.x) || float.IsNaN(pos.z))
			{
				Debug.LogError("Nan in pos.xz from navmesh");
				pos = Mover.Position;
			}
			
			pos += EntityPusher.PredictPushVector(Mover, pos);
			if(float.IsNaN(pos.x) || float.IsNaN(pos.z))
			{
				Debug.LogError("Nan in pos.xz from predict push vector");
				pos = Mover.Position;
			}

			pos.y = Mathf.Max(HeightMap.GetHeight(pos), Mover.Position.y - 2f);
			if(float.IsNaN(pos.y))
			{
				Debug.LogError("Nan in pos.y from hMap");
				pos = Mover.Position;
			}

			Mover.SlidePosition = pos;
			Mover.SlideV = pos - Mover.Position;
			Mover.OnSlideToPosition(pos, slideTime);
		}
		
		public override void BindToPos(Vector3 pos, float range, float slideSpeed, float time)
		{
			Mover.TimeToStopBind = NetworkManager.instance.ServerTimeInSeconds + time;
			pos.y = Mathf.Max(HeightMap.GetHeight(pos), Mover.Position.y - 2f);
			Mover.BindPosition = pos;
			Mover.BindRange = range;
			Mover.BindSpeed = slideSpeed;

			Mover.OnBindToPos(pos, range, slideSpeed, time);
		}
		
		public override void FlyOverGround(float yOffset, float time)
		{
			Mover.TimeToStopFly = NetworkManager.instance.ServerTimeInSeconds + time;
			Mover.FlyOffset = yOffset;
			Mover.FlyStartTime = NetworkManager.instance.ServerTimeInSeconds;
			
			Mover.OnFlyOverGround(yOffset, time);
		}

        public const float TargetReachedDistance = 0.316f; // PanDenat - sqrt(0.1), wzgl�dem 0.1 by�y por�wnywane dot�d kwadraty odleg�o�ci
        public const float TargetReachedDistanceSqr = TargetReachedDistance * TargetReachedDistance;
    }
}
