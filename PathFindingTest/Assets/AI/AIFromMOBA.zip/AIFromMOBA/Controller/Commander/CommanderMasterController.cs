using Assets._Controllable.BasicEntity;
using Assets.game;
using Assets._AI.Controller.BasicEntity;
using Assets._Network.Sender.BasicEntity;

internal class CommanderMasterController : MoverMasterController
{
	private bool winnerMessageSend;

	public override IEntityControllable Entity{ get { return Commander; } }
	protected override IAttackerControllable Attacker { get { return Commander; } }
	protected override IMoverControllable Mover { get { return Commander; } }
	protected Commander Commander { get; set; }

	public override void Initialize()
	{
		Commander =GetEntityComponent<Commander>();
		if (NetworkManager.instance.isMultiplayer)
			Commander.Sender = new MoverSender(Commander);
		base.Initialize();
	}

	protected override void Update()
	{
		base.Update();

		while(Commander.Lvl < MinionManager.instance.RequestedMinionLvl)
		{
			Commander.Exp = Commander.NextLevelExp + 1;
		}
	}

	public override void HandleHit(float dmg, IAttackerControllable attacker, Skill skill, bool forceDmg = false)
	{
		if (Entity.IsAlive == false || attacker.CanTargetEnemy(Entity) == false) return;

		base.HandleHit(dmg, attacker, skill, forceDmg);

		if (Entity.State == EntityState.Dead && !winnerMessageSend)
		{
			winnerMessageSend = true;
			GameManager.instance.ShowWinner(attacker.EntityTeam);
		}
	}
}