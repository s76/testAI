﻿using Assets._Controllable.BasicEntity;
using Assets._Network.Sender.BasicEntity;

public class DropMasterController : EntityMasterController {
	public override IEntityControllable Entity {
        get { return Drop; }
    }

    protected Drop Drop { get; set; }

    public override void Initialize() {
        Drop = GetEntityComponent<Drop>();
	    if (NetworkManager.instance.isMultiplayer)
		    Drop.Sender = new EntitySender(Drop);
		base.Initialize();
        Drop.EntityName = ((Drop)Drop.LocalEntity).dropName;       
    }
}
