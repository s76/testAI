using Assets._Controllable.BasicEntity;
using UnityEngine;
using QTree;
using Assets._Client;
using System.Collections.Generic;
using Assets.game;
using System.Collections;

public class ConquestPointMasterController : AttackerMasterController
{
	public override IEntityControllable Entity { get { return ConquestPoint; } }
	protected override IAttackerControllable Attacker { get { return ConquestPoint; } }
	protected ConquestPoint ConquestPoint { get; set; }
	
	public float captureCheckInterval = 0.1f;
	float lastCaptureCheck = -10000f;

	public Spawner[] spawnersToWaitForDead;
	public bool clearCaptureTimeOnClearTeam = true;
	
	public override void Initialize()
	{
		ConquestPoint = GetEntityComponent<ConquestPoint>();
		if (NetworkManager.instance.isMultiplayer)
			ConquestPoint.Sender = new ConquestPointSender(ConquestPoint);
		base.Initialize();
        DebugConsole.RegisterCommand("UnlockCP",UnlockConquestPoint);

        GameManager.instance.onGameEndEvent += OnGameEnd;
	}

    protected void OnDestroy()
    {
        if (GameManager.instance)
            GameManager.instance.onGameEndEvent -= OnGameEnd;
        DebugConsole.UnRegisterCommand("UnlockCP");
    }
	
    private object UnlockConquestPoint(string[] args)
    {
        float timeDuration = GameManager.instance.GameCurrentTime;
		ConquestPoint.LastCaptureTime = timeDuration - ConquestPoint.LockTime;
        return "Unlocked conquest point";
    }

	protected override void Update()
	{
		base.Update();

		UpdateCapture();
	}

	void UpdateCapture()
	{
        float timeDuration = GameManager.instance.GameCurrentTime;
		if(lastCaptureCheck + captureCheckInterval < Time.time && ConquestPoint.LastCaptureTime + ConquestPoint.LockTime < timeDuration
		   && CheckSpawner())
		{			

			List<Entity> entities = QuadTreeFinder.FindRect(Entity.Position.x - ConquestPoint.VisibilityRange, Entity.Position.z - ConquestPoint.VisibilityRange, 
			                                                ConquestPoint.VisibilityRange * 2f, ConquestPoint.VisibilityRange * 2f);
			int eastUnits = 0;
			int westUnits = 0;
			foreach(Entity e in entities)
			{
				if(e.State == EntityState.Dead || e.EntityType != EType.Hero)
					continue;

				if( ((Mover)e).IsWorldBaned )
					continue;

				if(e.EntityTeam == Team.West)
				{
					westUnits++;
				}
				
				if(e.EntityTeam == Team.East)
				{
					eastUnits++;
				}
			}
			
			Team winTeam = eastUnits == westUnits ? Team.None : eastUnits > westUnits ? Team.East : Team.West;
			float waitTime = Mathf.Min(Time.time - lastCaptureCheck, 1.5f * captureCheckInterval);
			float progressChange = waitTime / ConquestPoint.CaptureWaitTime * (1.0f + Mathf.Max(0.33f * (float)(Mathf.Abs(eastUnits - westUnits) - 1), 0f));

			ConquestPoint.CapturingTeam = winTeam;

			if(winTeam != Team.None)
			{
				if(ConquestPoint.CurrentTeamColor != winTeam)
				{
					ConquestPoint.CaptureProgress = Mathf.Max(ConquestPoint.CaptureProgress - progressChange, 0f);	
					if(ConquestPoint.CaptureProgress <= 0f)
					{
						ConquestPoint.CaptureProgress = 0f;
						ConquestPoint.CurrentTeamColor = winTeam;
					}
				}
				else
				{
					ConquestPoint.CaptureProgress = Mathf.Min(ConquestPoint.CaptureProgress + progressChange, 1f);	
					if(ConquestPoint.CaptureProgress >= 1.0f && winTeam != ConquestPoint.LastCaptureTeam)
					{
						ConquestPoint.LastCaptureTime = timeDuration;
						ConquestPoint.LastCaptureTeam = winTeam;
						
						if(ConquestPoint.SkillOnCapture)
						{
							ConquestPoint.UseSkill(ConquestPoint.SkillOnCapture);
						}

						if(ConquestPoint.CaptureNeuralTeamOnUnlock)
						{
							StartCoroutine(ResetToNeutralAfterTime(ConquestPoint.LockTime));
						}
					}
				}
			}
			else if(/*ConquestPoint.LastCaptureTeam != Team.None 
			        && */ConquestPoint.CaptureProgress != 0f 
			    	&& ConquestPoint.CaptureProgress != 1f)
			{
				float returnBackSpeed = 0.2f;
				if(ConquestPoint.LastCaptureTeam == ConquestPoint.CurrentTeamColor)
				{
					if(ConquestPoint.CaptureProgress > 0.9f)
					{
						ConquestPoint.CaptureProgress = 1f;
					}
					else
					{
						progressChange = returnBackSpeed * (1.0f - ConquestPoint.CaptureProgress) * waitTime;
						float progress = ConquestPoint.CaptureProgress + progressChange;
						if(progress > 1f)
							progress = 1f;
						ConquestPoint.CaptureProgress = progress;
					}
				}
				else
				{
					if(ConquestPoint.CaptureProgress < 0.1f)
					{
						ConquestPoint.CaptureProgress = 0f;
						ConquestPoint.LastCaptureTeam = Team.None;
						ConquestPoint.LastCaptureTime = timeDuration;
					}
					else
					{
						progressChange = returnBackSpeed * ConquestPoint.CaptureProgress * waitTime;
						float progress = ConquestPoint.CaptureProgress - progressChange;
						if(progress < 0f)
						{
							progress = 0f;
							ConquestPoint.LastCaptureTeam = Team.None;
							ConquestPoint.LastCaptureTime = timeDuration;
						}
						ConquestPoint.CaptureProgress = progress;
					}
				}

			}
			
			lastCaptureCheck = Time.time;
		}
	}

	bool CheckSpawner()
	{
		if(spawnersToWaitForDead == null)
			return true;
		bool isNotWaiting = true;
		foreach(Spawner s in spawnersToWaitForDead)
		{
			isNotWaiting = isNotWaiting && 
							(s.SpawnedEntityList.Count == 0 || s.SpawnedEntityList[0].State == EntityState.Dead);
		}

		if(!isNotWaiting)
		{
            ConquestPoint.LastCaptureTime = GameManager.instance.GameCurrentTime;
		}
		return isNotWaiting;

	}

	IEnumerator ResetToNeutralAfterTime(float time)
	{
		yield return new WaitForSeconds(time);
		while(!CheckSpawner())
			yield return new WaitForSeconds(0.1f);
		
		if(clearCaptureTimeOnClearTeam)
            ConquestPoint.LastCaptureTime = GameManager.instance.GameCurrentTime - ConquestPoint.LockTime;
		ConquestPoint.CaptureProgress = 0f;
		ConquestPoint.CurrentTeamColor = Team.None;
		ConquestPoint.LastCaptureTeam = Team.None;
	}

    void OnGameEnd(Team t, float time)
	{
		enabled = false;
	}
}