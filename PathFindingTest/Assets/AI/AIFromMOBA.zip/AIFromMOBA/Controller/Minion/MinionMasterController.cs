using Assets._AI.Controller.BasicEntity;
using Assets._Client;
using Assets._Controllable.BasicEntity;
using Assets._Debug;
using Assets._Network.Sender.Minion;
using Assets._Pathfinding;
using UnityEngine;
using System.Collections.Generic;
using Assets._AI.Actions;

public class MinionMasterController : MoverMasterController
{
	public override IEntityControllable Entity { get { return Minion; } }
	protected override IAttackerControllable Attacker { get { return Minion; } }
	protected override IMoverControllable Mover { get { return Minion; } }
	protected Minion Minion { get; set; }
	protected Vector3[] waypoints;
    public Vector3[] Waypoints { get { return waypoints; } }
	public int currentWaypoint = -1;
	public float nextRange2 = 49;
    //public float maxDistanceFromWaypoint = 10.0f;
	private bool initializeHasRun = false;

	public override void Initialize()
	{
		Minion = GetEntityComponent<Minion>();
		if (NetworkManager.instance.isMultiplayer)
			Minion.Sender = new MinionSender(Minion);
		

		base.Initialize();
		pathFinding.repathRate = 1f;
		pathFinding.SetLane(Minion.MinionLane);
		((MinionActions)actions).AttackEnemyBase();
        GetComponent<Reactor>().Initialize();
		initializeHasRun = true;
        //Minion.LocalEntity.onStateChanged += OnMinionStateChange; -- Christian Magic
		//pathFinding.TrySearchPath();
	}

	public override void Respawn(Vector3 pos)
	{
		base.Respawn(pos);
		pathFinding.SetLane(Minion.MinionLane);
		pathFinding.Reset();
		((MinionActions)actions).AttackEnemyBase();
		while(Minion.Lvl < MinionManager.instance.RequestedMinionLvl)
		{
			Minion.Exp = Minion.NextLevelExp + 1;
		}
		//pathFinding.canSearch = true;
		//pathFinding.canMove = true;
		//pathFinding.TrySearchPath();
	}

	protected override void OnEnable()
	{
        if (initializeHasRun && DebugManager.options[DebugOption.react]) GetEntityComponent<Reactor>().enabled = true;
	}

	public void SetLane(Waypoints lanePoints)
	{
		/*
		switch (Minion.MinionLane)
		{
			case Lane.Top:
				waypoints = GameObject.FindGameObjectWithTag("Lanes").FindChild("TopLane").GetComponent<Waypoints>().points;
				break;
			case Lane.Middle:
				waypoints = GameObject.FindGameObjectWithTag("Lanes").FindChild("MiddleLane").GetComponent<Waypoints>().points;
				break;
			case Lane.Bottom:
				waypoints = GameObject.FindGameObjectWithTag("Lanes").FindChild("BottomLane").GetComponent<Waypoints>().points;
				break;
		}
		*/
		if (lanePoints == null) return;

		waypoints = lanePoints.points;

		if (Mover.EntityTeam == Team.East)
			currentWaypoint = waypoints.Length - 1;
		if  (Mover.EntityTeam == Team.West)
			currentWaypoint = 0;

		Minion.CurrentWaypoint = waypoints[currentWaypoint];
	}

	public void NextClosestWaypoint()
	{
		Vector3 moveVector = Entity.Position - waypoints[currentWaypoint];
		float distance = moveVector.sqrMagnitude;

		if (distance < nextRange2)
		{
			if (Mover.EntityTeam == Team.West)
				currentWaypoint++;
			else
				currentWaypoint--;

			Minion.CurrentWaypoint = waypoints[currentWaypoint];
		}
	}

	public void ClosestWaypoint()
	{
		float distance = (Entity.Position-waypoints[currentWaypoint]).sqrMagnitude;
		int i = Entity.EntityTeam == Team.West ? 0 : waypoints.Length - 1;
		int end = Entity.EntityTeam == Team.West ? waypoints.Length : -1;
		while (i != end)
		{
			Vector3 moveVector = Entity.Position - waypoints[i];
			float currentDistance = moveVector.sqrMagnitude;

			if (currentDistance < distance)
			{
				currentWaypoint = i;
				Minion.CurrentWaypoint = waypoints[currentWaypoint];
			}

			if (Entity.EntityTeam == Team.West) i++;
			else i--;
		}

		if ((Mover.EntityTeam == Team.East && currentWaypoint != 0) || (Mover.EntityTeam == Team.West && currentWaypoint != waypoints.Length - 1))
		{
			int nextWaypoint;
			if (Mover.EntityTeam == Team.West)
				nextWaypoint = currentWaypoint + 1;
			else
				nextWaypoint = currentWaypoint - 1;

			if ((Entity.Position - waypoints[nextWaypoint]).sqrMagnitude <
				(waypoints[currentWaypoint] - waypoints[nextWaypoint]).sqrMagnitude)
			{
				currentWaypoint = nextWaypoint;
				Minion.CurrentWaypoint = waypoints[currentWaypoint];
			}
		}
	}
	/*
    public bool IsTooFarFromWaypoint()
    {
	    float distanceFromWaypointSquared = Attacker.HasAttackTarget ? 
		                                        (Attacker.AttackTarget.Position - waypoints[currentWaypoint]).sqrMagnitude : 
		                                        (Entity.Position - waypoints[currentWaypoint]).sqrMagnitude;
        float maxDistanceFromWaypointSquared = maxDistanceFromWaypoint * maxDistanceFromWaypoint;
        return (distanceFromWaypointSquared > maxDistanceFromWaypointSquared);
    }
	*/


	public Vector3 CurrentWaypoint()
	{
		return waypoints[currentWaypoint];
	}

    public float guardingTime = 2f;
    [HideInInspector]
    public float guardUntilTime = 0f;
    [HideInInspector]
    public int? priorityOfGuardingEntity = null;
    public IEntityControllable guardingEntity;
    public override void AnswerHelpCall(IEntityControllable attacked)
    {
        IAttackerControllable agresor = attacked.LastHitter;
	    if (Attacker.CanTargetEnemy(agresor) == false) return;
        int helpPriority = AttackerActions.LastHitterPriority(attacked);
        if (Time.time < guardUntilTime)
        {
            if (attacked == guardingEntity)
            {
                if (agresor == Attacker.AttackTarget) { }
                else if (helpPriority > priorityOfGuardingEntity || Attacker.HasAttackTarget == false || Attacker.AttackTarget.State == EntityState.Dead)
					Attacker.AttackTarget = agresor;
                guardUntilTime = Time.time + guardingTime;
            }
            else
                if (helpPriority > priorityOfGuardingEntity)
                    ChangeGuardingEntity(attacked, agresor, helpPriority);
        }
        else ChangeGuardingEntity(attacked, agresor, helpPriority);
    }

    private void ChangeGuardingEntity(IEntityControllable attacked, IAttackerControllable agresor, int helpPriority)
    {
        Attacker.AttackTarget = agresor;
        guardingEntity = attacked;
        priorityOfGuardingEntity = helpPriority;
        guardUntilTime = Time.time + guardingTime;
    }

    [System.Obsolete("Is this some sort of Christian Magic?", true)]
    private void OnMinionStateChange(EntityState before, EntityState after, IEntityControllable entity) {
        if (DebugManager.options[DebugOption.back] && before == EntityState.Run && (after == EntityState.Stay || after == EntityState.Attack)) {
            Entity collidingEntity = FindCollidingEntity();
            if (collidingEntity == null) return;
            //MoveBackwards(collidingEntity); -- Christian Magic
        }
    }

    [System.Obsolete("Is this some sort of Christian Magic?", true)]
    private void MoveBackwards(Entity collidingEntity) {
        Minion.MoveTargetPosition = Minion.Position + Minion.Rotation * Vector3.back * (Minion.Radius + collidingEntity.Radius);
		Minion.StateSync = EntityState.Run;
    }

    private Entity FindCollidingEntity() {
        Entity collidingEntity = null;
        List<Entity> closeEntities = QuadTreeSystem.instance.QuadTree.Query(Minion.BoundingRectangle);
        foreach (Entity e in closeEntities) {
            if (e != Minion && e.IsAlive && !Minion.IsEnemy(e) && Minion.HasInRange(e, 0)) { 
                collidingEntity = e; break; 
            }
        }
        return collidingEntity;
    }
}
