﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using UnityEngine;


    abstract class BoostUpdater : MonoBehaviour
    {
        protected void Start()
        {
            StartCoroutine(UpdateBoostCoroutine());
        }

        private IEnumerator UpdateBoostCoroutine()
        {
            yield return null;
        }
    }

