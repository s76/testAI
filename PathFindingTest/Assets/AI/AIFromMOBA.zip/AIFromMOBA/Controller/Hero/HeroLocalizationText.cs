﻿using UnityEngine;
using System.Collections;
using Assets._Manager;

public static class HeroLocalizationText {


	static string noOneIsTargeted;
	static string youCannotTargetEnemy;
	static string cannotTargetAlly;
	static string drawLineFirst;
	static string notEnoughMana;
	static string notEnoughtLeadership;
	static string notEnoughFocus;
	static string notEnoughStamina;


	public static string NoOneIsTargeted {
		get { 
			return noOneIsTargeted.IsEmptyOrNull() ? noOneIsTargeted = LanguageManager.GetLocalizedString(LocalizationKey.NO_ONE_IS_TARGETED) : noOneIsTargeted;
		}
	}

	public static string YouCannotTargetEnemy {
		get { 
			return youCannotTargetEnemy.IsEmptyOrNull() ? youCannotTargetEnemy = LanguageManager.GetLocalizedString(LocalizationKey.YOU_CANNOT_TARGET_ENEMY) : youCannotTargetEnemy;
		}
	}

	public static string CannotTargetAlly {
		get { 
			return cannotTargetAlly.IsEmptyOrNull() ? cannotTargetAlly = LanguageManager.GetLocalizedString(LocalizationKey.YOU_CANNOT_TARGET_ALLY) : cannotTargetAlly;
		}
	}

	public static string DrawLineFirst {
		get { 
			return drawLineFirst.IsEmptyOrNull() ? drawLineFirst = LanguageManager.GetLocalizedString(LocalizationKey.YOU_HAVE_TO_DRAW_LINE_FIRST) : drawLineFirst;
		}
	}

	public static string NotEnoughMana {
		get { 
			return notEnoughMana.IsEmptyOrNull() ? notEnoughMana = LanguageManager.GetLocalizedString(LocalizationKey.YOU_HAVE_NOT_ENOUGH_MANA) : notEnoughMana;
		}
	}

	public static string NotEnoughtLeadership {
		get { 
			return notEnoughtLeadership.IsEmptyOrNull() ? notEnoughtLeadership = LanguageManager.GetLocalizedString(LocalizationKey.YOU_HAVE_NOT_ENOUGH_LEADERSHIP) : notEnoughtLeadership;
		}
	}

	public static string NotEnoughFocus {
		get { 
			return notEnoughFocus.IsEmptyOrNull() ? notEnoughFocus = LanguageManager.GetLocalizedString(LocalizationKey.YOU_HAVE_NOT_ENOUGH_FOCUS) : notEnoughFocus;
		}
	}

	public static string NotEnoughStamina {
		get { 
			return notEnoughStamina.IsEmptyOrNull() ? notEnoughStamina = LanguageManager.GetLocalizedString(LocalizationKey.YOU_HAVE_NOT_ENOUGH_STAMINA) : notEnoughStamina;
		}
	}
}
