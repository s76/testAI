﻿using Assets.game;
using Assets._Controllable.BasicEntity;
using Assets._Manager;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using UnityEngine;
using Assets._Client;
using System.Collections;
using Assets._AI.Controller.Hero.Bot;

public class HeroAI : MonoBehaviour
{
    private HeroMasterController controller;
    private IHeroControllable Hero { get; set; }

    public event Action<HeroAI> onAIRun;
    public event Action<HeroAI> onAIStop;
    public bool IsHeroControlledByAI { get { return AIReactor != null && AIReactor.enabled; } }

    //react used by Hero when is controlled by AI
    public Reactor AIReactor;
    public int[] tagPenalties = new int[32];
    private int[] dumbTagPenalties;
    private HeroActions actions;

    public BotDifficulty Difficulty = new BotDifficulty();
    private LevelingAI levelingAi;

    public void Initialize(HeroMasterController controller, EntityActions actions)
    {
        if (controller == null) Debug.LogError("Null controller reference in HeroAI", this);
        if (actions == null) Debug.LogError("Null actions reference in HeroAI", this);
        this.controller = controller;
        this.actions = actions as HeroActions;
        if (this.actions == null) Debug.LogError("Actions in HeroAI are not HeroActions!", this);
        System.Diagnostics.Debug.Assert(controller != null, "controller != null");
        Hero = controller.Hero;

        Difficulty.OnDifficultyChanged += Difficulty_OnDifficultyChanged;
        Difficulty.Initialize(controller);

        AIReactor.Initialize();
    }

    void Difficulty_OnDifficultyChanged(BotDifficulty difficulty)
    {
        AIReactor.TickDuration = CalcReactTickDuration(difficulty);
    }

    private float CalcReactTickDuration(BotDifficulty difficulty)
    {
        float minTickDuration = BotManager.instance.hardestBotTickDuratoin;
        float maxTickDuration = BotManager.instance.easiestBotTickDuration;
        const float p = 1.6f; // power in function easyness = (1-d)^p
        float d = difficulty.Difficulty;
        float scaledDifficulty = Mathf.Pow(1 - d, p);
        return Mathf.Lerp(minTickDuration, maxTickDuration, scaledDifficulty);
    }

    public void RunAI()
    {
        if (onAIRun != null) { onAIRun(this); }

        Hero.LocalEntity.AddOnLevelUpDelegate(Hero_OnLevelUp);
        if (GameStateManager.Current.Type == GameStateType.PlayingGame) //only if game has started
            Hero_OnLevelUp(Hero); //call to rise level on start or if player has AviableSkillPoints
        else
            GameManager.instance.onGameStartEvent += instance_onGameStartEvent;
        //AIReactor.Execute();
        AIReactor.enabled = true;

        Hero.AttackMode = AttackMode.Manual; //on auto is loosing it's target

        SetAITagPenalties();
    }

    private void SetAITagPenalties()
    {
        var seeker = GetComponent<Seeker>();
        if (seeker == null)
        {
            Debug.LogWarning("[HeroAI] Where is my seeker component, ey?", this);
            return;
        }
        dumbTagPenalties = seeker.tagPenalties;
        seeker.tagPenalties = tagPenalties;
    }
    protected void OnDestroy()
    {
        if (GameManager.instance)
            GameManager.instance.onGameStartEvent -= instance_onGameStartEvent;
    }

    void instance_onGameStartEvent()
    {
        Hero_OnLevelUp(Hero);
        GameManager.instance.onGameStartEvent -= instance_onGameStartEvent;
    }

    public void StopAI()
    {
        if (onAIStop != null) { onAIStop(this); }

        AIReactor.enabled = false;
        Hero.LocalEntity.RemoveOnLevelUpDelegate(Hero_OnLevelUp);

        SetDumbTagPenalties();
    }

    private void SetDumbTagPenalties()
    {
        var seeker = GetComponent<Seeker>();
        if (seeker == null)
        {
            Debug.LogWarning("[HeroAI] Where is my seeker component, ey?", this);
            return;
        }
        seeker.tagPenalties = dumbTagPenalties;
    }
    /// <summary>
    /// Used by AI to rise skill lev
    /// </summary>
    /// <param name="entity"></param>
    void Hero_OnLevelUp(IEntityControllable entity)
    {
        levelingAi = levelingAi ??
            (GetComponent<LevelingAI>() ?? gameObject.AddComponent<LevelingAI>()).Initialize(Hero);
        levelingAi.LevelHeroUp();
    }


    void OnEnable()
    {
        StartCoroutine(DeviateReactTimeStepALittleCoroutine());
    }

    const float timeBetweenDeviations = 5.0f;
    const float deviateScale = 0.25f;
    private IEnumerator DeviateReactTimeStepALittleCoroutine()
    {
        var delay = new WaitForSeconds(timeBetweenDeviations);
        while (true)
        {
            yield return delay;
            if (Hero != null && Hero.Active && AIReactor != null && AIReactor.enabled)
            {
                float randomMinus1To1 = (-1 + UnityEngine.Random.value * 2);
                AIReactor.TickDuration = CalcReactTickDuration(Difficulty) * (1 + randomMinus1To1 * deviateScale); 
            }
        }
    }

}

