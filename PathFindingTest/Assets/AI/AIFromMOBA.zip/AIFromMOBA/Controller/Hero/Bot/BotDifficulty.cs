﻿using Assets._Client;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Assets._Manager;
using UnityEngine;

[Serializable]
public class BotDifficulty
{
    public const float EasyBottom = 0.0f, MediumBottom = 0.3f, HardBottom = 0.7f;
    public enum DiffLvl { Easy, Medium, Hard }
    public event Action<BotDifficulty> OnDifficultyChanged;

    [Range(0,1)]
    public float _difficulty = 1.0f; //public to be editable from inspector
    public float Difficulty
    {
        get { return _difficulty; }
        set
        {
            _difficulty = value;
            if (OnDifficultyChanged != null) OnDifficultyChanged(this);
        }
    }

    public void Initialize(HeroMasterController controller)
    {
        //EditorInitialize(controller);
        IPlayer playerInfo = GetPlayerInfoForBot(controller);
        if (playerInfo != null) Difficulty = playerInfo.Level;
    }

    private IPlayer GetPlayerInfoForBot(HeroMasterController controller)
    {
        IPlayer playerInfo = PlayerManager.instance.PlayersInRoomOnStart.FirstOrDefault(info => info.HeroID == controller.Hero.Id);
        if (playerInfo == null) Debug.LogError("[HeroAI] Cannot get playerInfo.", controller);
        if (!playerInfo.IsBot) playerInfo.Level = 0.69f;
        return playerInfo;
    }
	/*using things like this makes you dont see if its working well on device...
    [System.Diagnostics.Conditional("UNITY_EDITOR")]
    void EditorInitialize(HeroMasterController controller)
    {
        controller.StartCoroutine(DifficultyChangeCheck(controller));
    }*/

    private IEnumerator DifficultyChangeCheck(HeroMasterController controller)
    {
        float lastDifficulty = Difficulty;
        while (true)
        {
            if (Difficulty != lastDifficulty)
            {
                OnDifficultyChanged(this);
                lastDifficulty = Difficulty;
                Debug.Log("[BotDifficulty] Difficulty changed to " + Difficulty + " in " + controller.Hero.CharacterName, controller);
            }
            yield return new WaitForSeconds(1.0f);
        }
    }

    void Start()
    {
        Difficulty = HardBottom;
    }

    public DiffLvl DifficultyLevel
    {
        get
        {
            if (Difficulty < MediumBottom) return DiffLvl.Easy;
            if (Difficulty < HardBottom) return DiffLvl.Medium;
            return DiffLvl.Hard;
        }
        set
        {
            switch (value)
            {
                case DiffLvl.Easy:
                    Difficulty = EasyBottom;
                    break;
                case DiffLvl.Medium:
                    Difficulty = MediumBottom;
                    break;
                case DiffLvl.Hard:
                    Difficulty = HardBottom;
                    break;
                default:
                    break;
            }
        }
    }
}

