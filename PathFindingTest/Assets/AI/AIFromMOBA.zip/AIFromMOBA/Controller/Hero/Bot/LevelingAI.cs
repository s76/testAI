﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using UnityEngine;

namespace Assets._AI.Controller.Hero.Bot
{
    class LevelingAI : MonoBehaviour
    {
        IHeroControllable Hero;
        HeroMasterController HeroController { get { return (HeroMasterController)Hero.Controller; } }

        public LevelingAI Initialize(IHeroControllable hero)
        {
            Hero = hero;
            return this;
        }

        public void LevelHeroUp()
        {
            const int maxLoops = 11; //it's impossible for the character to have more than ten points to distribute
            for (int i = 0; i < maxLoops; i++) //ensures no infinite loop
            {
                List<int> choosedSkillIDs = GetSkillIDsToChooseFrom();
                if (choosedSkillIDs.IsEmptyOrNull()) { return; }
                HeroController.IncreaseSkillLvl(choosedSkillIDs.GetRandom());
            }
            Debug.LogError("[LevelingAI] Probable infinite loop while leveling up.", this);
        }

        private List<int> GetSkillIDsToChooseFrom()
        {
            const int numberOfSkills = 3;
            List<int> availableSkillIDs = Enumerable.Range(0, numberOfSkills).Where(id => InputController.IsSkillAvailable(id, Hero)).ToList();
            int lowestAvailableSkillLevel = GetMinLevel(availableSkillIDs);
            List<int> choosedSkillIDs = availableSkillIDs.Where(id => Hero.GetSkill(id).Level == lowestAvailableSkillLevel).ToList();
            return choosedSkillIDs;
        }

        private int GetMinLevel(List<int> availableSkillIDs)
        {
            int lowestAvailableSkillLevel = int.MaxValue;
            foreach (var id in availableSkillIDs)
            {
                var skillLevel = Hero.GetSkill(id).Level;
                if (skillLevel < lowestAvailableSkillLevel)
                {
                    lowestAvailableSkillLevel = skillLevel;
                }
            }
            return lowestAvailableSkillLevel;
        }
    }
}
