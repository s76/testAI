﻿using Assets._Controllable._EntityPreferences;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Assets._Manager;
using UnityEngine;
using Assets._Controller;
using Assets._Controllable.BasicEntity;
using System.Collections;
using Assets.game;


class DifficultyBooster : MonoBehaviour
{
#if !UNITY_4_3
    [Header("Weakening options")]
#endif
    [Range(0, 1)]
    public float maxDifficultyToWeakenBot = 0.05f;
    [Range(0, 1)]
    public float lifeWeakenRatio = 0.5f;
    [Range(0, 1)]
    public float dmgWeakenRatio = 0.5f;
    public float refreshTime = 10f;

    private Hero hero;
    private HeroAI heroAI;
    private IEntityController controller;
    private IAttackerControllable attacker;//can be changed to hero if only this type uses booster
    private EntityBoost weakeningBoostAttack;
    private EntityBoost weakeningBoostLife;
    private bool inited = false;
    private bool firstBoosterStarted = false;

    protected void Start()
    {
        hero = GetComponentInParent<Hero>() ?? GetComponent<Hero>();
        if (!hero.Inited) 
        {
            Debug.LogWarning("[DifficultyBooster] Hero is not inited during my initialization. Switching to plan B.", this);
            hero.onPostInitialize += hero_onPostInitialize;
            return;
        }

		if(TutorialManager.IsTutorialModeOn)
			lifeWeakenRatio = 0f;

        Init();
    }

    void hero_onPostInitialize()
    {
        hero.onPostInitialize -= hero_onPostInitialize;
        Init();
    }

    private void Init()
    {
        controller = hero.Controller;
        heroAI = GetComponent<HeroAI>();
        attacker = (IAttackerControllable) controller.Entity;
        heroAI.onAIRun += heroAI_onAIRun;
        heroAI.onAIStop += heroAI_onAIStop;
        heroAI.Difficulty.OnDifficultyChanged += Difficulty_OnDifficultyChanged;

        weakeningBoostAttack = new EntityBoost(0f, true, BoostType.Attack, 1000f, attacker);
        weakeningBoostLife = new EntityBoost(0f, true, BoostType.Life, 1000f, attacker);

        GameManager.instance.onGameStartEvent += OnGameStart;
        GameManager.instance.onPlayersUnlockedEvent += OnGameStart;

        inited = true;
    }

    void OnGameStart()
	{
		if(!firstBoosterStarted)
			UpdateDifficultyBooster();
	}

    protected void OnEnable()
    {
        if (inited) { UpdateDifficultyBooster(); }
    }

    void Difficulty_OnDifficultyChanged(BotDifficulty obj)
    {
        UpdateDifficultyBooster();
    }

    private void UpdateDifficultyBooster()
    {
        if (IsBot())
        {
            if (ShouldBeWeakened()) { AddWeakeningBoost(); }
            else { RemoveWeakeningBoost(); }
        }
    }

    private bool ShouldBeWeakened()
    {
        if (NetworkManager.instance.isMultiplayer)
        {
            var playerInfo = PlayerManager.instance.PlayersInRoomOnStart.FirstOrDefault(player => player.HeroID == hero.Id);
            if (playerInfo != null) { return playerInfo.Level <= maxDifficultyToWeakenBot; }
            Debug.LogError("[DifficultyBooster] PlayerInfo not found."); return false;
        }
        else
        {
            return heroAI.Difficulty.Difficulty <= maxDifficultyToWeakenBot;
        }
    }

    private bool IsBot()
    {
        if (NetworkManager.instance.isMultiplayer)
        {
            var id = hero.Id;
            return PlayerManager.instance.PlayersInRoomOnStart.Any(player => player.HeroID == id && player.IsBot);   
        }
        else
        {
            return heroAI.IsHeroControlledByAI;
        }
    }

    void heroAI_onAIRun(HeroAI obj)
    {
        if (heroAI.Difficulty.Difficulty <= maxDifficultyToWeakenBot) { AddWeakeningBoost(); }
    }
    void heroAI_onAIStop(HeroAI obj)
    {
        RemoveWeakeningBoost();
    }

    private void AddWeakeningBoost()
    {
        if (weakeningBoostAttack != null)
        {
			firstBoosterStarted = true;
            StopAllCoroutines();
            if (gameObject.activeInHierarchy) { StartCoroutine(AddWeakeningBoostsCoroutine()); }
        }
    }

    IEnumerator AddWeakeningBoostsCoroutine()
    {
        while (true)
        {
			if(attacker.Inited)
			{
	            weakeningBoostAttack.val = -dmgWeakenRatio * attacker.DamageBase;
	            weakeningBoostLife.val = -lifeWeakenRatio * attacker.MaxBaseLife;
	            controller.HandleEntityBoost(weakeningBoostAttack);
	            controller.HandleEntityBoost(weakeningBoostLife);
			}
            yield return new WaitForSeconds(refreshTime);
        }
    }

    private void RemoveWeakeningBoost()
    {
        StopAllCoroutines();
        if (weakeningBoostAttack != null)
        {
            controller.HandleRemoveEntityBoost(weakeningBoostAttack);
            controller.HandleRemoveEntityBoost(weakeningBoostLife);
        }
    }

    protected void OnDestroy()
    {
        if (GameManager.instance != null)
        {
            GameManager.instance.onGameStartEvent -= OnGameStart;
            GameManager.instance.onPlayersUnlockedEvent -= OnGameStart;
        }
        if (heroAI != null)
        {
            heroAI.onAIRun -= heroAI_onAIRun;
            heroAI.onAIStop -= heroAI_onAIStop;

            if (heroAI.Difficulty != null)
            {
                heroAI.Difficulty.OnDifficultyChanged -= Difficulty_OnDifficultyChanged;
            }
        }
    }
}

