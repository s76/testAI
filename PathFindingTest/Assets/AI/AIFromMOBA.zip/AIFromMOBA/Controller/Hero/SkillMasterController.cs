﻿using System.Collections.Generic;
using System.Linq;
using Assets._Controllable.BasicEntity;
using Assets._Controller.Dispatcher;
using Assets._Debug;
using Assets._Inventory.New;
using UnityEngine;
using Assets.game;

namespace Assets._AI.Controller.Hero
{
    public class SkillMasterController
    {
        private HeroMasterController controller;
        private IHeroControllable hero;
        private Vector3 targetPositionBeforeCast = Vector3.zero;
        private IEntityControllable targetEntityBeforeCast;
        private AttackMode attackModeBeforeCast;
        private EntityState stateBeforeCast;
        private Queue<ActionQueue> queue = new Queue<ActionQueue>();
        private HeroActions actions;

        internal SkillMasterController(HeroMasterController controller, EntityActions actions)
        {
            this.controller = controller;
            this.actions = (HeroActions) actions;
            hero = controller.Hero;
        }

        public void Update()
        {
            UseSkillInQueue();
        }

        public Skill SkillToCast
        {
            get
            {
                if (queue.Count == 0) return null;
                var param = queue.Peek();
                var skill = param.Type == ActionType.UseItem ? param.item.ActiveSkill : param.skill;
                return IsSkillReadyToCast(skill, param.param) ? skill : null;
            }
        }

        public bool IsQueueEmpty
        {
            get { return queue.Count == 0; }
        }

        public void UseSkill(Skill skill, SkillParams skillParams)
        {
            if (IsSkillReadyToCast(skill, skillParams))
            {
                UseSkillNow(skill, skillParams);
            }
            else
            {
                AddSkillToQueue(skill, skillParams);
            }
        }

        private void UseSkillNow(Skill skill, SkillParams skillParams)
        {
            SetTargetBeforeCast(skill, skillParams);
            if (skill.Type != SkillType.Wall) skillParams.startPosition = hero.Position;
            hero.UseSkill(skill, skillParams);
            SetTargetAfterCast(skill, skillParams);
            skill.onSkillBulletExplode += OnSkillBulletExplode;
            ClearQueue();
        }

        public void UseItem(Item item, int id, SkillParams skillParams)
        {
            var skill = item.ActiveSkill;
            if (IsSkillReadyToCast(skill, skillParams))
            {
                UseItemNow(item, id, skillParams);
            }
            else
            {
                AddItemToQueue(item, id, skillParams);
            }
        }

        private void UseItemNow(Item item, int id, SkillParams skillParams)
        {
            var skill = item.ActiveSkill;
            SetTargetBeforeCast(skill, skillParams);
            if (skill.Type != SkillType.Wall && skillParams != null) skillParams.startPosition = hero.Position;
            hero.UseItem(item, id, skillParams);
            SetTargetAfterCast(skill, skillParams);
            skill.onSkillBulletExplode += OnSkillBulletExplode;
            ClearQueue();
        }

        // probably not working as expected
        public bool IsCasting
        {
            get
            {
                return hero.State == EntityState.Cast ||
                       hero.LastCastedSkill != null && hero.LastCastedSkill.IsCastLocking;
            }
        }

        public void SaveTargetBeforeCast(Skill skill, SkillParams param)
        {
            //if casting bomb while moving and target is out of range stay after cast
            if (param != null && !skill.IsBasicSkill && hero.State== EntityState.Run && skill.Type!=SkillType.SelfSupport
                && !hero.HasInRange(param.targetPosition,skill.Range))
                stateBeforeCast = EntityState.Stay;
            else
                stateBeforeCast = hero.State;
            targetPositionBeforeCast = hero.MoveTargetPosition;
            targetEntityBeforeCast = hero.AttackTarget;
            attackModeBeforeCast = hero.AttackMode;
        }

        private void SetTargetBeforeCast(Skill skill, SkillParams skillParams)
        {
        }

        private void SetTargetAfterCast(Skill skill, SkillParams skillParams)
        {
			if(skill.AfterCastBehaviour == BehaviourAfterCast.NoAction || hero.State == EntityState.Teleport)
				return;
            if (skill.CanBeCastedInRun)
            {
                if (skill.AfterCastBehaviour == BehaviourAfterCast.RestoreAndNoAssist ||
                    skill.AfterCastBehaviour == BehaviourAfterCast.BackToLastTarget)
                {
                    RestorePreviousTarget();
                    // To powoduje, że postać od razu zacznie isc do poprzedniego celu, a jak pocisk trafi to się wróci
                }
            }
            else
            {
                StopToFinishCast(skill);
            }
        }

        private void OnSkillBulletExplode(Skill skill, BulletEffect bulletEffect, Vector3 position)
        {
            // usuń powiązanie
            skill.onSkillBulletExplode -= OnSkillBulletExplode;

            // jak nie żyjesz lub masz następny skill w kolejce to koniec
            if (!hero.IsAlive || !IsQueueEmpty) return;

            // stój w miejscu
            if (skill.AfterCastBehaviour == BehaviourAfterCast.NoAction)
            {
                //HaltMovement();
                return;
            }
            if (skill.LastEnemiesHit.IsEmptyOrNull())
            {
                if (skill.AfterCastBehaviour == BehaviourAfterCast.AimAssist ||
                    skill.AfterCastBehaviour == BehaviourAfterCast.StopAndAssist)
                {
                    HaltMovement();
                    return;
                }
            }

            // przywróc na target przed skillem
            if (skill.AfterCastBehaviour == BehaviourAfterCast.RestoreAndNoAssist ||
                (skill.AfterCastBehaviour == BehaviourAfterCast.BackToLastTarget && skill.LastEnemiesHit.IsEmptyOrNull()))
            {
/*#if UNITY_EDITOR
                if (controller.IsLocalInput) Debug.Log("Restoring target...");
#endif*/
                RestorePreviousTarget();
                return;
            }

            if (skill.LastEnemiesHit.IsEmptyOrNull())
            {
                //DebugManager.LogError("Targetting error!", this); - null enemies hit is not an error man
                return;
            }

            // od tej linii skill trafił w kogoś

            if (skill.TargetingType == Skill.TargetType.Entity)
            {
                var target = skill.LastEnemiesHit.First();
                if (hero.CanTargetEnemy(target))
                {
                    hero.AttackTarget = target;
                    hero.AttackMode = AttackMode.Manual;
                }
                return;
            }

            if (skill.TargetingType == Skill.TargetType.Line)
            {
                AssistTargetAfterCast(skill, hero.Position);
                return;
            }

            AssistTargetAfterCast(skill, position);
        }

        private void HaltMovement(Vector3? position = null)
        {
            if (position == null) position = hero.Position;
            hero.AttackTarget = null;
            hero.FixedPosition = (Vector3) position;
            hero.AttackMode = AttackMode.Manual;
			hero.MoveTargetPosition = hero.FixedPosition;
			if(hero.State != EntityState.Teleport)
				hero.StateSync = EntityState.Stay;
            //hero.TimeToStopBind = -1f;
            //hero.TimeToStopFly = -1f;
            //hero.TimeToStopSlide = -1f;
            //hero.State = EntityState.Stay;
        }

        private void StopToFinishCast(Skill skill, Vector3? position = null)
        {
            if (position == null) position = hero.Position;
            hero.AttackTarget = null;
            hero.FixedPosition = (Vector3) position;
            hero.AttackMode = AttackMode.Manual;
            //hero.State = EntityState.Cast;
            //hero.LastCastedSkill = skill;
        }

        private void RestorePreviousTarget()
        {
			GameManager.instance.StartFunctionAfterTime(RestorePreviousTargetOnNextFrame, Time.deltaTime);
        }

		void RestorePreviousTargetOnNextFrame()
		{
			if (targetEntityBeforeCast != null)
			{
				if (hero.IsAutoTargetEnabled && hero.CanTargetEnemy(targetEntityBeforeCast) && hero.State != EntityState.Teleport)
				{
					hero.AttackTarget = targetEntityBeforeCast;
					hero.AttackMode = attackModeBeforeCast;
				}
				else HaltMovement();
			}
			else if (stateBeforeCast == EntityState.Run)
			{
				hero.MoveTargetPosition = targetPositionBeforeCast;
			}
			else
			{
				HaltMovement();
				return;
			}
			
			if (hero.State != EntityState.Cast)
				hero.StateSync = stateBeforeCast;
		}

        private void AssistTargetAfterCast(Skill skill, Vector3 searchPosition)
        {
            hero.AttackTarget = null;
            hero.MoveTargetPosition = hero.Position;
            controller.AttackEnemyClosestToPointInVisibilityRange(
                skill.LastEnemiesHit.Select(a => a.LocalEntity).ToList(), searchPosition, hero.VisibilityRange);

            // hardcoded melee change target
            if (hero.WeaponType == WeaponType.Meele &&
                hero.AttackTarget != null &&
                Vector3.Distance(hero.Position, hero.AttackTarget.Position) > 3.0f)
            {
                actions.AttackClosestEntityInChaseRange();
            }

            if (hero.AttackTarget != null)
            {
                hero.AttackMode = AttackMode.Manual;
            }
            else if (skill.AfterCastBehaviour == BehaviourAfterCast.RestoreAndNoAssist ||
                     skill.AfterCastBehaviour == BehaviourAfterCast.BackToLastTarget)
            {
                if (controller.IsLocalInput) Debug.Log("Restoring target backup...");
                RestorePreviousTarget();
            }
        }

        private class ActionQueue
        {
            public Skill skill;
            public Item item;
            public SkillParams param;
            public int slotId;

            public ActionType Type
            {
                get { return item != null ? ActionType.UseItem : ActionType.CastSkill; }
            }
        }

        private enum ActionType
        {
            UseItem,
            CastSkill
        }

        public void AddSkillToQueue(Skill skill, SkillParams skillParams)
        {
            Enqueue(new ActionQueue() {skill = skill, param = skillParams});
        }

        public void AddItemToQueue(Item item, int slotId, SkillParams skillParams)
        {
            Enqueue(new ActionQueue() {item = item, slotId = slotId, param = skillParams});
        }

        private bool IsSkillReadyToCast(Skill skill, SkillParams skillParams)
        {
            return (controller.SkillParamsOK(skill, skillParams) && !controller.IsHeroCastBlocked(!skill.IsBasicSkill) &&
                    (skill.TargetingType == Skill.TargetType.None || skill.Type == SkillType.FrontShot ||
                     skill.Type == SkillType.LineShot || skill.Type == SkillType.LineShotCutTarget ||
                     controller.IsInCastRange(skillParams.targetEntity, skill) ||
                     controller.IsInCastRange(skillParams.MovePosition, skill)));
        }

        private void UseSkillInQueue()
        {
            if (!hero.IsAlive)
            {
                ClearQueue();
                return;
            }

            if (queue.Count == 0) return;

            var action = queue.Peek();
            var skill = action.Type == ActionType.CastSkill ? action.skill : action.item.ActiveSkill;
            var skillParams = action.param;
            if (IsSkillReadyToCast(skill, skillParams))
            {
                if (action.Type == ActionType.CastSkill)
                {
                    UseSkillNow(skill, skillParams);
                }
                else if (action.Type == ActionType.UseItem)
                {
                    var slot = hero.ConsumableInventory.GetSlot(action.slotId);
                    if (slot == null || slot.ItemId != action.item.Id ||
                        !action.item.CanBeUsed(hero.ConsumableInventory))
                    {
                        DebugManager.LogError("Can't UseItem... ;[", this);
                        return;
                    }

                    if (slot.Item.ItemType == ItemType.ConsumableItem)
                    {
                        UseItemNow(action.item, slot.Id, skillParams);
                    }
                }
            }
            else if (skillParams != null)
            {
                if (skill.TargetingType == Skill.TargetType.Entity && hero.CanTargetEnemy(skillParams.targetEntity))
                {
                    hero.AttackTarget = skillParams.targetEntity;
                    hero.AttackMode = AttackMode.Manual;
                }
                else if (skillParams.MovePosition != Vector3.zero && skill.TargetingType != Skill.TargetType.Line)
                {
                    hero.MoveTargetPosition = skillParams.MovePosition;
                    hero.AttackMode = AttackMode.Manual;
                }
            }
        }

        private void Enqueue(ActionQueue actionQueue)
        {
//            if(controller.IsLocalInput && actionQueue.Type == ActionType.UseItem)
//                DebugManager.LogWarning("Addind skill " + actionQueue.item.Name + " to queue in frame " + Time.frameCount);
            queue.Clear();
            queue.Enqueue(actionQueue);
            hero.SkillInQueue = actionQueue.skill;
            hero.ItemInQueue = actionQueue.item;
        }

        public void ClearQueue()
        {
            queue.Clear();
            hero.SkillInQueue = null;
            hero.ItemInQueue = null;
        }

		internal void PrintQueue()
		{
			foreach(var q in queue)
			{
				if(q == null)
					Debug.Log("Null Q");
				else if(q.skill != null && q.param != null)
					Debug.Log(q.skill.SkillName + " " + q.param);
				else if(q.item != null && q.param != null)
					Debug.Log(q.item.Name + " " + q.param);
				else
					Debug.Log("Null skill or param" + q.skill + " " + q.param);
			}
		}
	}
}