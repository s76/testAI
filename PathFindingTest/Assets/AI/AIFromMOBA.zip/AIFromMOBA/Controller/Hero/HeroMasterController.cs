using System;
using System.Collections;
using Assets._AI.Controller.Hero;
using Assets._Common;
using Assets._Debug;
using Assets._Inventory.New;
using Assets._Shop;
using Assets.game;
using Assets._AI.Controller.BasicEntity;
using Assets._Controllable.BasicEntity;
using Assets._Controller.Dispatcher;
using System.Collections.Generic;
using UnityEngine;
using Assets._Controller;
using Assets._Manager;
using System.Linq;
using Assets.maps;
using Assets._Controllable._EntityPreferences;
using Assets._Inventory;

public class HeroMasterController : MoverMasterController
{
    public override IEntityControllable Entity
    {
        get { return Hero; }
    }

    protected override IAttackerControllable Attacker
    {
        get { return Hero; }
    }

    protected override IMoverControllable Mover
    {
        get { return Hero; }
    }

	public Hero Hero { get; private set; }

    protected Hero LocalHero
    {
        get { return (Hero) Hero.LocalEntity; }
    }

    public override event OnHandleKill onHandleKill;

    public HeroRespawnTime RespawnTime { get; private set; }

    //react used by Hero when is controlled by Player
    public Reactor InputRangeReactor;
    public Reactor InputMeeleReactor;
    private Reactor InputReactor;

    [HideInInspector] public HeroAI heroAI;
	private SkillMasterController skillController;

    public override void Initialize()
    {
		Hero = GetEntityComponent<Hero>();
	    if (NetworkManager.instance.isMultiplayer)
		    Hero.Sender=Hero.HeroSender = new HeroSender(Hero);
     
        heroAI = GetComponent<HeroAI>();
        SetCustomHeroActions();

        RespawnTime = new HeroRespawnTime(Hero);
        Hero.RespawnInterval = RespawnTime.Interval;
        base.Initialize();
        heroAI.Initialize(this, actions);
        skillController = new SkillMasterController(this, actions);

        GameManager.instance.onGameStartEvent += OnGameStart;
    }

    protected void OnDestroy()
    {
        if (GameManager.instance)
            GameManager.instance.onGameStartEvent -= OnGameStart;
    }

    private void OnGameStart()
    {
        if (enabled && this.gameObject.activeSelf)
        {
            StartCoroutine(AutoExpUpdate());
        }
    }

    private void AddItems()
    {
        Hero.ConsumableInventory.AddItem(InitDataManager.instance.GetItemCopyById(new Id("GreenHealingPotionNormal")));
        Hero.ConsumableInventory.AddItem(InitDataManager.instance.GetItemCopyById(new Id("GrapeshotArea")));
    }

    protected override void OnEnable()
    {
        base.OnEnable();
        if (GameStateManager.Current.Type == GameStateType.PlayingGame)
        {
            StartCoroutine(AutoExpUpdate());
        }
    }

    protected override void StartReact()
    {
        if (Hero.WeaponType == WeaponType.Meele)
        {
            InputReactor = InputMeeleReactor;
            DebugManager.Log("InputReactor.reactable = InputMeeleReactor", this);
        }
        else if (Hero.WeaponType == WeaponType.Range)
        {
            InputReactor = InputRangeReactor;
            DebugManager.Log("InputReactor.reactable = InputRangeReactor", this);
        }

        InputReactor.enabled = true;
    }

    private void SetCustomHeroActions()
    {
        string heroName = Hero.CharacterName;
        try
        {
            var customAI = BotManager.instance.customAI.FirstOrDefault(ai => ai.name.Contains(heroName));
            if (customAI != null)
            {
                heroAI.AIReactor.reactable = customAI.reactGraph;
            }
            else
            {
                var defaultReact = BotManager.instance.defaultAI;
                if (defaultReact != null) heroAI.AIReactor.reactable = defaultReact;
            }
        }
        catch (NullReferenceException)
        {
#if !UNITY_IPHONE
            Debug.Log("[BotAI] No customAI list in BotManager " + heroName);
#endif
            actions = gameObject.AddComponent<HeroActions>();
        }
    }

    /// <summary>
    /// Used to turn on AI when Bot is spawned or player disconnect
    /// </summary>
    public void RunAI()
    {
        InputReactor.enabled = false;
        heroAI.RunAI();
    }

    /// <summary>
    /// Used to turn off AI when player has reconnect
    /// </summary>
    public void StopAI()
    {
        Debug.Log("Stopping AI on player reconnect in " + this.name);
        heroAI.StopAI();
        InputReactor.enabled = true;
    }

    public void IncreaseSkillLvl(int skillId)
    {
		if(!Hero.CanSkillBeUpgraded(skillId))
			return;

        int skillLvl = Hero.GetSkill(skillId).Level + 1;
        for (int i = skillId%4; i < Hero.GetSkillCount(); i += 4)
        {
            Hero.SetSkillLvl(i, skillLvl);
        }
    }

    public override void UpdateInactive()
    {
        if (MapManager.instance.LastLoadedMap.gameMode == GameMode.BattleArena
            || MapManager.instance.LastLoadedMap.gameMode == GameMode.BossMode)
            return;

        base.UpdateInactive();
        UpdateRespawn();
    }

    public override void UpdateController()
    {
        UpdateInventory();
        if (skillController != null)
            skillController.Update();

        if (GameManager.instance.GameCurrentTime < InGameSettings.currentInstance.playersStartLockTime)
        {
            if (Mover.State != EntityState.Stay
                && Mover.State != EntityState.Dead)
				Mover.StateSync = EntityState.Stay;
            return;
        }

        base.UpdateController();
        UpdateRespawn();

        if (Mover.State == EntityState.Dead)
            return;

        pathFinding.canMove = Mover.State == EntityState.Run
                              || (Hero.State == EntityState.Cast
                                  && Hero.LastCastedSkill.CanBeCastedInRun
                                  && Hero.LastState == EntityState.Run);
    }

    private void UpdateRespawn()
    {
        if (Hero.State == EntityState.Dead)
        {
            if (GameStateManager.Current.Type != GameStateType.AfterGame)
            {
                if (Hero.TimeLeftToRespawn <= 0)
                {
                    Respawn(Entity.SpawnPoint);
                }
            }

            return;
        }
    }

    private float lastInventoryUpdate;

    private void UpdateInventory()
    {
        if (InventorySettings.currentInstance!=null 
            && lastInventoryUpdate + InventorySettings.currentInstance.cashIncreaseInterval < Time.time
            && Hero.State != EntityState.Dead
            && !GameManager.instance.ArePlayersLocked
            && GameStateManager.Current.Type == GameStateType.PlayingGame)
        {
            Hero.Wallet.Cash += InventorySettings.currentInstance.cashIncrease;
            Hero.Wallet.TotalCash += InventorySettings.currentInstance.cashIncrease;

            if (ConquestPoint.instances != null)
            {
                foreach (ConquestPoint cp in ConquestPoint.instances)
                {
                    if (cp.LastCaptureTeam == Hero.EntityTeam && cp.CaptureProgress > 0.99f)
                    {
                        Hero.Wallet.Cash += InventorySettings.currentInstance.conquestCashIncrease;
                        Hero.Wallet.TotalCash += InventorySettings.currentInstance.conquestCashIncrease;
                    }
                }
            }
            lastInventoryUpdate = Time.time;
        }
    }

    public IEnumerator AutoExpUpdate()
    {
        while(Level.Settings.expPerSecond > 0 || TutorialManager.IsTutorialModeOn)
        {
            yield return new WaitForSeconds(1f);
            if (GameStateManager.Current.Type == GameStateType.PlayingGame && !GameManager.instance.ArePlayersLocked)
                Hero.Exp += Level.Settings.expPerSecond;
        }
    }

    public override bool UpdateRegen()
    {
        if (base.UpdateRegen() && (Hero.SkillEnergyType == EnergyType.Mana 
		                           || Hero.SkillEnergyType == EnergyType.Focus
		                           || Hero.SkillEnergyType == EnergyType.Stamina) 
		    && options.ManaRegen)
        {
            const float updateRegenInterval = Assets._Controllable.BasicEntity.Entity.updateRegenInterval;
            Hero.LostMana -= Hero.IsHypothermic
                ? Hero.ManaRegen*updateRegenInterval*0.5f
                : Hero.ManaRegen*updateRegenInterval;
            return true;
        }
        return false;
    }

    protected override void UpdateState()
    {
		if ((Mover.IsStunned || Mover.IsFlying) && Mover.State != EntityState.Cast || GameManager.instance.GameCurrentTime < InGameSettings.currentInstance.playersStartLockTime)
        {
			Mover.StateSync = EntityState.Stay;
            //Mover.SetLastAttackTime(Time.time);
            return;
        }

        //to let use cast animation
        if (Mover.State == EntityState.Cast)
        {
            if (Hero.LastCastedSkill == null && Mover.LastStateChangeTime + 1f > Time.time)
            {
                return;
            }

            if (Hero.LastCastedSkill != null &&
                (Hero.LastCastedSkill.IsCastLocking
                 || Mover.LastStateChangeTime + Hero.LastCastedSkill.CastTime > Time.time && !Hero.LastCastedSkill.LastCastWasRupted))
            {
                return;
            }
        }

        if (Mover.HasAttackTarget)
        {
            bool isInRange = skillController.SkillToCast == null
                ? Mover.HasInAttackRange(Mover.AttackTarget) && Mover.HasInLineOfSight(Mover.AttackTarget)
                : IsInCastRange(Mover.AttackTarget);

            if (Hero.AttackMode == AttackMode.Auto) UpdateStateAutoHasAttackTarget(isInRange);
            if (Hero.AttackMode == AttackMode.Manual) UpdateStateManualHasAttackTarget(isInRange);
        }
        else
        {
            switch (Hero.State)
            {
                case EntityState.Run:
                    if (skillController.SkillToCast != null &&
                        (skillController.SkillToCast.Type == SkillType.FrontShot
                         || skillController.SkillToCast.Type == SkillType.LineShot
                         || skillController.SkillToCast.Type == SkillType.LineShotCutTarget
                         || IsInCastRange(Hero.MoveTargetPosition)))
                    {
                        Hero.LastCastedSkill = skillController.SkillToCast;
						Hero.StateSync = EntityState.Cast;
                    }
                    else if (Hero.HasReachedMoveTarget() && Hero.DirectionOfJoy == Vector3.zero)
                    {
						Hero.StateSync = EntityState.Stay;
                    }
                    break;
                case EntityState.Cast:
                    float dSqr = (Hero.MoveTargetPosition - Hero.Position).sqrMagnitude;
                    if (dSqr > 0.2f)
						Hero.StateSync = EntityState.Run;
                    else
						Hero.StateSync = EntityState.Stay;
                    break;
                case EntityState.Attack:
					Hero.StateSync = EntityState.Stay;
                    break;
                case EntityState.Dead:
                case EntityState.Stay:
                    if ((Hero.DirectionOfJoy != Vector3.zero || Hero.HasReachedMoveTarget() == false)
                        && (skillController.SkillToCast == null || !IsInCastRange(Hero.MoveTargetPosition)))
                    {
						Hero.StateSync = EntityState.Run;
                    }
                    else if (skillController.SkillToCast != null && IsInCastRange(Hero.MoveTargetPosition))
                    {
                        Hero.LastCastedSkill = skillController.SkillToCast;
						Hero.StateSync = EntityState.Cast;
                    }
                    break;
                case EntityState.Teleport:
                default:
                    break;
            }
        }
    }

    public override void AttackOrFollow(IEntityControllable e)
    {
        skillController.ClearQueue();
        base.AttackOrFollow(e);
    }

    public override void MoveToPositionOnMap(Vector3 pos)
    {
        skillController.ClearQueue();

        pos = AstarPath.active.GetNearest(pos).clampedPosition;
		pos.y = HeightMap.GetHeight(pos);
        CancelTeleport();
        base.MoveToPositionOnMap(pos);
    }

    public override void MoveInDirection(Vector3 direction)
    {
        if (direction != Vector3.zero)
        {
            /*
            if (DebugManager.options[DebugOption.joyfix])
            {
                if (IsLocalInput) DebugManager.LogWarning("Clearing queue prevented in frame " + Time.frameCount);
            } else {
                skillController.ClearQueue();
                if (IsLocalInput) DebugManager.LogWarning("Clearing queue in frame " + Time.frameCount);
            }
            */
            skillController.ClearQueue();
        }
        base.MoveInDirection(direction);
    }

    /// <summary>
    /// Does not take into consideration radius of the target. Use with caution.
    /// </summary>
    /// <param name="targetPoint"></param>
    /// <param name="cast"></param>
    /// <returns></returns>
    public bool IsInCastRange(Vector3 targetPoint, Skill cast = null)
    {
        if (cast == null) cast = skillController.SkillToCast;
        return Hero.HasInRange(targetPoint, cast.Range);
    }

    public bool IsInCastRange(IEntityControllable target, Skill cast = null)
    {
        if (cast == null) cast = skillController.SkillToCast;
        return Hero.HasInRange(target, cast.Range);
    }

    private void UpdateStateManualHasAttackTarget(bool isInRange)
    {
        if (!Hero.IsEnemy(Hero.AttackTarget)
            &&
            (skillController.SkillToCast == null || skillController.SkillToCast.TargetingType != Skill.TargetType.Entity)
            && (Hero.State != EntityState.Cast))
        {
            return;
        }

        switch (Hero.State)
        {
            case EntityState.Run:
            case EntityState.Stay:
            case EntityState.Cast:
            case EntityState.Teleport:
            case EntityState.Attack:
                if (Hero.CanTargetEnemy(Hero.AttackTarget) ||
                    (skillController.SkillToCast != null &&
                     skillController.SkillToCast.TargetingType == Skill.TargetType.Entity))
                {
                    // jak wr�g nie �yje
                    if (Hero.AttackTarget.State == EntityState.Dead || Hero.AttackTarget.State == EntityState.Destroyed)
                    {
                        Hero.MoveTargetPosition = Hero.Position; // to chyba stajemy w miejscu jednak..
						Hero.StateSync = EntityState.Stay;
                        break;
                    }

//					if (Hero.IsPreparingAttack()/* && isInRange*/)
//					{
//						return;
//					}

                    if(skillController.SkillToCast == null || Hero.IsSilenced && skillController.SkillToCast.IsBasicSkill)
                    {
						Hero.StateSync = (isInRange || LocalHero.IsFinishingAttack) ? EntityState.Attack : EntityState.Run;
                    }
                    else
                    {
                        if (isInRange)
                        {
                            Hero.LastCastedSkill = skillController.SkillToCast;
							Hero.StateSync = EntityState.Cast;
                        }
                        else
                        {
							Hero.StateSync = EntityState.Run;
                        }
                    }
                }
                else
                {
                    // sledzenie
                    if (Hero.AttackTarget.State == EntityState.Dead)
                    {
                        Hero.AttackTarget = null;
                        Hero.MoveTargetPosition = Hero.Position;
                    }
                    else
						Hero.StateSync = Hero.HasInRange(Hero.AttackTarget, Hero.VisibilityRange)
                            ? EntityState.Stay
                            : EntityState.Run;
                }
                break;
            case EntityState.Dead:
                break;
        }
    }

    private void UpdateStateAutoHasAttackTarget(bool isInRange)
    {
        if (!Hero.CanTargetEnemy(Hero.AttackTarget)) {
            Hero.AttackTarget = null;
			Hero.StateSync = EntityState.Stay;
            return;
        }

        switch (Hero.State)
        {
            case EntityState.Run:
            case EntityState.Stay:
            case EntityState.Cast:
            case EntityState.Attack:
                if (isInRange)
                    // jak wr�g w zasi�gu ataku
                {
					Hero.StateSync = EntityState.Attack; // to go atakujemy
                    if (Hero.AttackTarget.State == EntityState.Dead || Hero.AttackTarget.State == EntityState.Destroyed)
						Hero.StateSync = EntityState.Stay;
                }
                    // jak wr�g poza zasi�giem ataku
                else
                {
                    Hero.AttackTarget = null; // to przerywamy atak
					Hero.StateSync = EntityState.Stay;
                }
                break;
            case EntityState.Dead:
            case EntityState.Teleport:
                break;
        }
    }

    public override void HandleEntityDeath(IEntityControllable victim, IAttackerControllable attacker,
        IEnumerable<HitInfo> assisters)
    {
        if (victim == null || attacker == null || victim.EntityTeam == Hero.EntityTeam || victim.Id == Hero.Id ||
            victim.Id == attacker.Id || victim.IsManualRespawning) return;

        float cash = -1;
        if (attacker.Id == Hero.Id)
        {
            cash = Hero.Wallet.Cash;
        }

        var result = Hero.UpdateEntityDeath(victim, attacker);
        Hero.Exp = Hero.Exp;

        switch (result)
        {
            case KillState.Killer:
                Hero.Score.AddKilledHero(victim as IHeroControllable);
                break;
            case KillState.Assist:
                Hero.Score.AddAssistedHero(victim as IHeroControllable);
                break;
            case KillState.TowerKiller:
            case KillState.MinionKiller:
                Hero.Score.AddKilledMinion();
                break;
        }

        if (onHandleKill != null)
            onHandleKill(victim, result);

//#if !HEADLESS
//        if (attacker.Id == hero.Id && cash != hero.Inventory.Cash)
//        {
//            HUDUnits.instance.ShowEntityCash(hero.LocalEntity, (int)(hero.Inventory.Cash - cash));
//            EffectManager.instance.CreateGoldSquirt(victim);
//        }
//#endif
//        if (hero.AttackTarget != null && attacker.Id == hero.Id && hero.AttackTarget.Id == victim.Id)
//        {
//            hero.MoveTargetPosition = hero.Position;
//        }
    }

    public override void HandleHit(float dmg, IAttackerControllable attacker, Skill skill, bool forceDmg = false)
    {
        bool alive = Entity.IsAlive;

#if !HEADLESS
        if (alive && skill != null && PlayerManager.instance.LocalHero != null &&
            PlayerManager.instance.LocalHero.Id == Hero.Id)
        {
            BulletEffect bullet = skill.Bullet;
            if (bullet != null)
                bullet.StartAfterHitLocalHeroEffect(Hero.Position);
        }
#endif

        base.HandleHit(dmg, attacker, skill, forceDmg);

        if (alive && !Entity.IsAlive)
        {
			if(!Hero.IsManualRespawning)
				Hero.Score.AddDeath(Hero.ComputeLastKiller());
        }

        if (dmg > 0) CancelTeleport();
    }

	public override void HandleSupport(float heal, IAttackerControllable supporter, Skill skill)
	{
		bool alive = Entity.IsAlive;

		base.HandleSupport(heal, supporter, skill);
		
		if(alive && !Entity.IsAlive)
		{
			if(!Hero.IsManualRespawning)
				Hero.Score.AddDeath(Hero.ComputeLastKiller());
		}
	}

    public bool IsHeroCastBlocked(bool isConsumableSkill)
    {
        return Hero.IsStunned || Hero.IsSilenced && !isConsumableSkill || Hero.IsWorldBaned || Hero.State == EntityState.Cast
                || Hero.LastCastedSkill != null && Hero.LastCastedSkill.IsCastLocking
                || Hero.IsSlidingOrFlying || !Hero.IsTargetable;
    }

    public bool UseSkill(Skill skill, SkillParams skillParams = null)
    {
        if (!Hero.IsAlive) return false;
        if (skillController.IsQueueEmpty) skillController.SaveTargetBeforeCast(skill, skillParams);
        skillController.UseSkill(skill, skillParams);
        return true;
    }

    public void UseItem(Id id, int slotId, SkillParams param = null)
    {
        if (!Hero.IsAlive) return;

        var slot = Hero.ConsumableInventory.GetSlot(slotId);
        if (slot == null || slot.ItemId != id || !((IItem) slot.Item).CanBeUsed(Hero.ConsumableInventory))
            return;

        if (slot.Item.ItemType == ItemType.ConsumableItem)
        {
            var item = (Item) slot.Item;
            if (skillController.IsQueueEmpty) skillController.SaveTargetBeforeCast(item.ActiveSkill,param);
            skillController.UseItem(item, slot.Id, param);
        }
    }

    // should be moved to skillmastercontroller asap
    public bool SkillParamsOK(Skill skill, SkillParams skillParams = null)
    {
        var castTarget = skillParams != null ? skillParams.targetEntity : null;

        if (skill == null)
        {
            Debug.LogWarning("Skill is null!");
            return false;
        }

        if (!Hero.IsAlive || !skill.IsActivable)
        {
            return false;
        }

        if (castTarget == null && Hero.AttackTarget != null)
        {
            castTarget = Hero.AttackTarget;
        }

        string err = "";

        if (skill.TargetingType == Skill.TargetType.Entity)
        {
            if (castTarget == null)
            {
                err = HeroLocalizationText.NoOneIsTargeted;
            }
            else if (skill.Type == SkillType.TargetSupport
                     && castTarget.EntityTeam != Hero.EntityTeam)
            {
                err = HeroLocalizationText.YouCannotTargetEnemy;
            }
            else if (skill.Type != SkillType.TargetSupport
                     && skill.Type != SkillType.SelfSupport
                     && skill.Type != SkillType.TargetAny
                     && castTarget.EntityTeam == Hero.EntityTeam
                )
            {
                err =HeroLocalizationText.CannotTargetAlly;
            }
        }

        if (skill.TargetingType == Skill.TargetType.Line)
        {
            if (skillParams.startPosition == skillParams.endPosition)
            {
                err = HeroLocalizationText.DrawLineFirst+" - " + Hero.EntityName;
            }
        }

        if (Hero.SkillEnergyType == EnergyType.Mana && skill.ManaCost > Hero.Mana)
        {
            err = HeroLocalizationText.NotEnoughMana;
        }

        if (Hero.SkillEnergyType == EnergyType.Leadership && skill.ManaCost > Hero.Mana)
        {
            err = HeroLocalizationText.NotEnoughtLeadership;
        }

        if (Hero.SkillEnergyType == EnergyType.Focus && skill.ManaCost > Hero.Mana)
        {
            err = HeroLocalizationText.NotEnoughFocus;
        }
		
		if (Hero.SkillEnergyType == EnergyType.Stamina && skill.ManaCost > Hero.Mana)
		{
			err = HeroLocalizationText.NotEnoughStamina;
		}

        if (err.Length > 0)
        {
            //Debug.Log(err);
#if !HEADLESS
            GUIManager.instance.GameLayout.HUDQuickMessage.Show(1.5f, err);
            InputManager.Controller.CurrentTargetSkill = null;
#endif
            return false;
        }

        //InputManager.Controller.CurrentTargetSkill = null;
        OnCommandEvent();
        return true;
    }

    private IBaseItem CheckShopAndItemAvailability(Id id, VendorEntity vendor)
    {
        if (vendor == null || !vendor.IsAlive || vendor.EntityTeam != Hero.EntityTeam ||
            (Hero.State == EntityState.Dead && vendor.ShopType != ShopType.Base) ||
            (!vendor.HasInCatchArea(Hero) && Hero.State != EntityState.Dead))
            return null;
        IBaseItem item = InitDataManager.instance.GetItemById(id);
        return item;
    }

    public void BuyItem(Id id, VendorEntity vendor)
    {
        var item = CheckShopAndItemAvailability(id, vendor);
        if (item == null)
            return;

        switch (item.ItemType)
        {
            case ItemType.ConsumableItem:
                vendor.Shop.Buy(id, Hero.Wallet, Hero.ConsumableInventory);
                break;
            case ItemType.Item:
                vendor.Shop.Buy(id, Hero.Wallet, Hero.Inventory);
                break;
        }
    }

    /// <summary>
    /// Used for standard teleport
    /// </summary>
    public void Teleport()
    {
        //if(hero.ThiefMode)
        //{
        //    GUIManager.instance.GameLayout.hudQuickMessage.Show(1.5f, "You cannot teleport while you hold intel!");
        //    return;
        //}
        //SelectionManager.instance.ClearSelection();

        /*Transform spawn =
            GameObject.FindGameObjectWithTag(Hero.EntityTeam == Team.East
                ? "PlayerEastSpawn"
                : "PlayerWestSpawn").transform;
        Teleport(spawn.position, 5);*/
		Teleport(Hero.SpawnPoint, 3f);
    }

    /// <summary>
    /// Used for non standard teleport
    /// </summary>
    /// <param name="position">target position</param>
    /// <param name="time">teleporting time duration</param>
    public void Teleport(Vector3 position, float time)
    {
        if( !Hero.CanTeleport )
        {
            return;
        }

		position = HeightMap.CalcPositionWithHeight(position);
        Hero.AttackTarget = null;
		Hero.StateSync = EntityState.Teleport;
        Hero.StartTeleport(position, time);
        Hero.PredictedPath = null;
        OnCommandEvent();
        StartCoroutine(FinishTeleport(position, time));
    }

    private IEnumerator FinishTeleport(Vector3 teleportPos, float time)
    {
		float endTime = Time.time + time;
		while(endTime > Time.time)
		{
			yield return new WaitForSeconds(0.1f);
			if (Hero.State != EntityState.Teleport) yield break;
		}

        if (Hero.State != EntityState.Dead)
        {
            Hero h = (Hero.LocalEntity as Hero);
            h.FireOnTeleportBlinkEvent();
            Hero.FixedPosition = teleportPos;
	        Hero.MoveTargetPosition = teleportPos;
			Hero.StateSync = EntityState.Stay;
            h.FireOnTeleportBlinkedEvent();
        }
    }

    public void CancelTeleport()
    {
        if (Hero.State == EntityState.Teleport)
        {
			Hero.StateSync = EntityState.Stay;
			Hero.CancelTeleport();
        }
    }

    public override void Respawn(Vector3 pos)
	{
        RespawnTime.IncreaseTime();

        pos = AstarPath.active.GetNearest(pos).clampedPosition;
		
		if(Entity.Active != false)
			Entity.Active = false;
		Entity.Trans.position = pos;
        
        Hero.FixedPosition = pos;
        Hero.MoveTargetPosition = pos;
        Hero.PredictedPath = null;
        Hero.Active = true;
		Hero.StateSync = EntityState.Stay;
        Hero.Reset();

        OnCommandEvent();
    }

    public void ClearSkillQueue()
    {
        skillController.ClearQueue();
    }

	public SkillMasterController SkillController
	{
		get { return skillController; }
	}
}