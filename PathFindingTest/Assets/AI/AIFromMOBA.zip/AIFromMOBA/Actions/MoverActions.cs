﻿using System.Collections;
using Assets._Controllable.BasicEntity;
using UnityEngine;
using React;
using System.Collections.Generic;

public class MoverActions : AttackerActions {
    protected IMoverControllable Mover { get; set; }

    public override void Initialize(IEntityControllable entity) {
        Mover = entity as IMoverControllable;
        base.Initialize(entity);
    }

    public IEnumerator<NodeResult> TryRespawn() {
        if (Mover.LastStateChangeTime + Mover.RespawnInterval < Time.time) {
            Mover.Controller.Respawn(Mover.SpawnPoint);
            yield return NodeResult.Success;
        }
        yield return NodeResult.Failure;
    }

    public bool IsOutsideBase() {
        return (Entity.Position - Entity.SpawnPoint).sqrMagnitude > 1f;
    }

    public IEnumerator<NodeResult> ReturnToBase() {
#if DEBUG_AI_HERO
			Debug.Log(Entity + " returns to base");
#endif
        Mover.MoveTargetPosition = Entity.SpawnPoint;
        yield return NodeResult.Success;
    }

    /// <summary>
    /// Target Enemy Base
    /// </summary>
    /// <returns></returns>
    public virtual IEnumerator<NodeResult> AttackEnemyBase() {
        //Debug.Log("TarGetEnemyBaseOrCommander: " + Mover.EnemyTeam);
        Attacker.AttackTarget = EntityManager.instance.GetEnemyBaseOrCommander(Entity);
        yield return NodeResult.Success;
    }
}
