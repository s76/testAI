using System;
using System.Collections;
using System.Collections.Generic;
using Assets._Controllable.BasicEntity;
using UnityEngine;
using React;

public class EntityActions : MonoBehaviour
{
	protected bool isInitialized;
	//protected Dictionary<String, IEnumerator<NodeResult>> searchCoroutines = new Dictionary<string, IEnumerator<NodeResult>>();
	protected IEntityControllable Entity { get; set; }

	public virtual void Initialize(IEntityControllable entity)
	{
		Entity = entity;
		isInitialized = true;
	}

	public bool IsInitialized()
	{
		return isInitialized;
	}

	public bool IsOperational()
	{
		return isInitialized && Entity.Active && 
			(Entity.State == EntityState.Stay || Entity.State == EntityState.Run
			 || Entity.State == EntityState.Attack || Entity.State == EntityState.Cast );
	}

	public bool IsStateEqualStay()
	{
		return Entity.State == EntityState.Stay;
	}

	public bool IsStateEqualDead()
	{
		return Entity.State == EntityState.Dead;
	}

    public IEnumerator<NodeResult> SetVisibleForEnemies() {
        Entity.IsVisibleForEnemies = true;
        yield return NodeResult.Success;
    }

    public IEnumerator<NodeResult> SetInvisibleForEnemies() {
        Entity.IsVisibleForEnemies = false;
        yield return NodeResult.Success;
    }

    public bool IsRecentlyAttacked() {
        float recently = 1f;
        return Time.time < Entity.LastHitTime + recently;
    }

    public bool Success() {
        return true;
    }
}