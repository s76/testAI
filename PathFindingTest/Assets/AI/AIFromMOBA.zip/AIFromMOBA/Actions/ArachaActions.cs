using Assets._AI.Actions;
using Assets._Client;
using Assets._Controllable.BasicEntity;
using Assets._Manager;
using React;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using UnityEngine;

class ArachaActions : MonsterActions {
    private VendorEntity closestVendor;
    private bool hasDied = false;
    private Team teamAdherence;

    public override void Initialize(Assets._Controllable.BasicEntity.IEntityControllable entity) {
        base.Initialize(entity);
        hasDied = false;
        Entity.onDeath += Entity_OnDeath;
        if (InitMacroTargets() == false)
            PostponeInitialization();
    }

    void Entity_OnDeath(IEntityControllable obj) {
        hasDied = true;
    }

    private bool InitMacroTargets() {
        Func<Entity, Entity, Entity> getCloser = (closest, e) => (closest == null || DistToSqr(e) < DistToSqr(closest)) ? e : closest;

        closestVendor = EntityManager.instance.GetAllEntities()
            .Where(e => (e.EntityType == EType.Vendor))
            .Aggregate(null as Entity, (closest, e) => (closest == null || DistToSqr(e) < DistToSqr(closest)) ? e : closest) as VendorEntity;
        teamAdherence = EntityManager.instance.GetAllEntities()
            .Where(e => (e.EntityType == EType.Commander) || (e.EntityType == EType.Base))
            .Aggregate(null as Entity, (closest, e) => (closest == null || DistToSqr(e, closestVendor) < DistToSqr(closest, closestVendor)) ? e : closest)
            .EntityTeam;

        return !(closestVendor == null);
    }

    private float DistToSqr(IEntityControllable entity) {
        return DistToSqr(entity, Attacker);
    }

    private float DistToSqr(IEntityControllable e1, IEntityControllable e2) {
        return (e1.Position - e2.Position).sqrMagnitude;
    }

    private void PostponeInitialization() {
        Debug.Log("[ArachaAI] Not all prerequirements are met. Initialization postponed.", Attacker.LocalEntity);
        isInitialized = false;

        StartCoroutine(WaitForInitialization());
    }

    private IEnumerator WaitForInitialization() {
        float timeOfInitialization = Time.time;
        float maxWaitTime = 10f;
        while (Time.time - timeOfInitialization < maxWaitTime) {
            yield return new WaitForSeconds(0.1f);
            if (InitMacroTargets()) {
                Debug.Log(String.Join(" ", new String[] {
                        "[ArachaAI] Initialization postponed by",
                        (Time.time - timeOfInitialization).ToString(), 
                        "seconds"}),
                    Attacker.LocalEntity);
                isInitialized = true;
                yield break;
            }
        }
        Debug.LogError("[ArachaAI] Bot failed to initialize. Abandoned after" + (Time.time - timeOfInitialization) + " seconds", Attacker.LocalEntity);
    }

    public bool HasDied() {
        return hasDied;
    }

    public IEnumerator<NodeResult> MakeAlive() {
		Entity.StateSync = EntityState.Stay;

        yield return NodeResult.Success;
    }

    public IEnumerator<NodeResult> MakeUntargetable() {
        Entity.IsTargetable = false;
        yield return NodeResult.Success;
    }

    public IEnumerator<NodeResult> MakeFaster() {
        throw new NotImplementedException();
        //Mover.MoveSpeed *= 4;
    }

    public IEnumerator<NodeResult> GoToVendor() {
        Mover.MoveTargetPosition = closestVendor.Position;
        while (Mover.HasInRange(closestVendor, 0) == false) yield return NodeResult.Continue;
        yield return NodeResult.Success;
    }

    public IEnumerator<NodeResult> KillThyself() {
		Entity.StateSync = EntityState.Dead;
        yield return NodeResult.Success;
    }

    public bool IsVendorEnemyOfKiller() {
        if (Entity.LastHitter == null) return false;
        return Entity.LastHitter != null && Entity.LastHitter.IsEnemyTeam(teamAdherence);
    }

    public IEnumerator<NodeResult> ChangePrices() {
        throw new NotImplementedException("there is no SetUsableItemPricePercentageFactor(0.33f) in inventory");
        yield return NodeResult.Success;
    }
}
