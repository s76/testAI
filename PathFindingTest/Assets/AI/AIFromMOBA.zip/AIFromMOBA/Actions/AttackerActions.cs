﻿using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Assets._Controllable.BasicEntity;
using Assets._Debug;
using Assets._Network;
using QTree;
using UnityEngine;
using System;
using React;

public class AttackerActions : EntityActions
{
    public float cooldown = 3.0f;
    private float? cooldownStartTime;
	private List<int> prevTargetsIds = new List<int>(3);
	private float prevTargetsUpdate;

	protected IAttackerControllable Attacker { get; set; }
	
	public override void Initialize(IEntityControllable entity)
	{
		Attacker = entity as IAttackerControllable;
		base.Initialize(entity);
	}

    /// <summary>
    /// Is cooldown on entity off? If it is start a new one.
    /// </summary>
    /// <returns></returns>
    public bool IsCooldownOff() //TODO: its an ugly "React cooldown" problem resolve attempt
    {
        if (cooldownStartTime == null)
        {
            cooldownStartTime = Time.time;
            return true;
        }
        if (Time.time - cooldownStartTime < cooldown) return false;
        else
        {
            cooldownStartTime = null;
            return false;
        }
    }

	/// <summary>
	/// Is AttackTarget alive?
	/// </summary>
	/// <returns></returns>
	public bool IsAttackTargetAlive()
	{
		return Attacker.HasAttackTarget
            && Attacker.AttackTarget.State != EntityState.Dead
            && Attacker.AttackTarget.State != EntityState.Destroyed;
	}

	/*
	 * Czy wróg w zasięgu widoku
	 */
	public bool IsAttackTargetAliveAndInVisibilityRange()
	{
        return IsAttackTargetAlive()
            && Attacker.HasInVisibilityRange(Attacker.AttackTarget)
            && IsAttackTargetInLineOfSight();
	}

    public bool IsAttackTargetInLineOfSight() {
        return Attacker.HasAttackTarget && Attacker.HasInLineOfSight(Attacker.AttackTarget);
    }

    [Obsolete("Use Entity.HasInLineOfSight(...) instead.", true)]
    private bool IsInLineOfSight(IEntityControllable entity) {
        //return FOWSystem.instance.IsInLOS(Attacker.Position, entity.Position);
        Profiler.BeginSample("Manual LineOfSight Check");
		bool isTrue = true;//FOWSystem.instance.IsInLOS(Attacker.Position, entity.Position);
        Profiler.EndSample();
        return isTrue;

    }

	/*
	 * Czy wróg w zasięgu ataku
	 */
	public bool IsAttackTargetAliveAndInAttackRange()
	{
		return IsAttackTargetAlive() && Attacker.HasInAttackRange(Attacker.AttackTarget);
	}

	/*
     * Przerwij atak
     */
    public IEnumerator<NodeResult> AbandonAttack()
    {
		if (Attacker.State == EntityState.Attack || Attacker.State == EntityState.Stay || Attacker.State == EntityState.Dead)
			Attacker.AttackTarget = null;

		//if (Attacker.EntityType == EType.Tower) Oh.. man
		// Debug.Log("Abandon Attack: " + (Attacker.AttackTarget != null ? Attacker.AttackTarget.EntityName : "null"));

        yield return NodeResult.Success;
    }

	/// <summary>
	/// Atakuj nastepnego wroga w zasiegu widoku
	/// </summary>
	/// <param name="entityType">Opcjonalnie typ jednostki</param>
	/// <param name="targetAngle">Opcjonaly kąt ataku</param>
	public void AttackNextTargetInVisibilityRange(EType entityType = EType.Any, double? targetAngle = null)
	{
		if (Time.time > prevTargetsUpdate + 3.0f) prevTargetsIds.Clear();
		if (Attacker.HasAttackTarget && !prevTargetsIds.Contains(Attacker.AttackTarget.Id))
		{
			//Debug.Log("Target excluded: " + Attacker.AttackTarget.Id);
			prevTargetsIds.Add(Attacker.AttackTarget.Id);
		}
		IEnumerator<NodeResult> task;
		var name = "AttackNextTargetInVisibilityRange";
		//if (!searchCoroutines.TryGetValue(name, out task))
		{
            ICollection<Entity> entities = GetEntitiesInArea(Attacker.VisibilityRange);
			entities = entities.Where(entity => !prevTargetsIds.Contains(entity.Id)).ToList();
			string text = entities.Aggregate("", (current, filteredEntity) => current + (filteredEntity.Id + ", "));
			//Debug.Log("Possible AutoAttack targets: " + text);
			if (targetAngle != null)
			{
				task = AttackClosestEnemyInDirection(entities, Attacker.VisibilityRange, (double) targetAngle, entityType);
			}
			else
			{
				task = AttackClosestEnemyInRange(entities, Attacker.VisibilityRange, entityType);
			}
		}
        IEnumerator<NodeResult> e = task;
		while (e.MoveNext()) { }
		
		if (e.Current == NodeResult.Failure)
		{
			Attacker.AttackTarget = null;
			if (prevTargetsIds.Count != 0)
			{
				prevTargetsIds.Clear();
				AttackNextTargetInVisibilityRange(entityType);
				return;
			}
		}

		prevTargetsUpdate = Time.time;
	}

    public void AttackEnemyClosestToPointInVisibilityRange(Vector3 centerPosition, EType type = EType.Any)
    {
        ICollection<Entity> entities = GetEntitiesInArea(Attacker.VisibilityRange);
        IEnumerator<NodeResult> e = AttackClosestEnemyInRange(entities, Attacker.VisibilityRange, centerPosition, type);     
        while (e.MoveNext()) { }
    }

	private IEnumerator<NodeResult> AttackClosestEnemyInDirection(ICollection<Entity> entities, float visibilityRange, double targetAngle, EType entityType)
	{
		var angleEntities = new List<Entity>();
		foreach (var entity in entities)
		{
			var relativePosition = entity.Position - Attacker.Position;
			var angle = Math.Atan(relativePosition.z / relativePosition.x) * 180 / Math.PI;
			const int angleMargin = 15;
			if (targetAngle - angleMargin < angle || angle < targetAngle + angleMargin)
			{
				angleEntities.Add(entity);
			}
		}
		return AttackClosestEnemyInRange(angleEntities, visibilityRange, entityType);
	}

	/* 
	 * Atakuj najblizszego wroga
     */
    public IEnumerator<NodeResult> AttackClosestEnemyInRange(ICollection<Entity> entities, float range, EType type = EType.Any, EntityState? state = null) {
        return AttackClosestEnemyInRange(Attacker, entities, range, type, e => state == null || e.State == state);
    }

    public IEnumerator<NodeResult> AttackClosestEnemyInRange(ICollection<Entity> entities, float range, Vector3 centerPosition, EType type = EType.Any, EntityState? state = null)
    {
        return AttackClosestEnemyInRange(Attacker, entities, range, type, e => state == null || e.State == state, centerPosition);
    }

    static public IEnumerator<NodeResult> AttackClosestEnemyInRange(IAttackerControllable Attacker, ICollection<Entity> entities, float range, EType type = EType.Any, Func<IEntityControllable, bool> Filter = null, Vector3? centerPosition = null, bool fast = false)
	{
		IEntityControllable closest = null;
		float distance = range * range; //TODO: implement better solution
		float visibilityRange = distance;
        Vector3 position = centerPosition != null ? (Vector3)centerPosition : Attacker.Position;
		int listCount = entities.Count;

		foreach (IEntityControllable entity in entities)
		{
			if(entity == null || entity.Trans == null) continue;
			if(Attacker.CanTargetEnemy(entity) == false) continue;
			if(type != EType.Any && entity.EntityType != type) continue;
            if(Filter != null && Filter(entity) == false) continue;
            if(entity.EntityType == EType.HealingTower) continue;
			if(entity.EntityType == EType.Chest) continue;
            if(entity.EntityType == EType.BridgeSupport) continue;
            if(entity.EntityType == EType.Spawn && !entity.IsMover) continue;
            if(!entity.IsVisibleForEnemies) continue;
            if(!Attacker.HasInLineOfSight(entity)) continue;
			if(!entity.IsVisible) continue;

			Vector3 diff = (entity.Position - position);
			float curDistance = diff.sqrMagnitude;

            if (closest == null && curDistance < (Attacker.Radius + range + entity.Radius) * (Attacker.Radius + range + entity.Radius))  //TODO: not a pretty solution
			{
				closest = entity;
				distance = curDistance;
			}
			else if (curDistance < distance)
			{
				closest = entity;
				distance = curDistance;
			}

			if (!fast) yield return NodeResult.Continue;

			if (entities.Count != listCount)
				break;
		}

		if (closest == null)
			yield return NodeResult.Failure;

		Attacker.AttackTarget = closest;
	}

    /* Atakuj entity które atakuje twojego bohatera
     */
    public IEnumerator<NodeResult> AttackHeroAttackerInAttackRange()
    {
        //Debug.Log("Tower Attack: DefendHeroUnderAttackAndInRange");
        var visibilityRange = Attacker.VisibilityRange * Attacker.VisibilityRange;
        var attackRange = Attacker.AttackRange * Attacker.AttackRange;
		// quadtree nie ma sensu w momencie gdy herosow jest tak mało
//			ICollection<Entity> heroes = QuadTreeSystem.instance.QuadTree.Query(
//				new BoundingRect(Attacker.Position.x - Entity.VisibilityRange, Attacker.Position.z - Entity.VisibilityRange, Entity.VisibilityRange * 2, Entity.VisibilityRange*2)
//			);
		var heroes = EntityManager.instance.GetEntitiesOfType(Attacker.EntityTeam, EType.Hero);

        foreach (Entity hero in heroes)
        {
            if (hero.LastHitter == null) continue;
			if (Attacker.CanTargetEnemy(hero.LastHitter) == false) continue;
			if (hero.LastHitter.State == EntityState.Dead) continue;

			yield return NodeResult.Continue;

            Vector3 diff = hero.Position - Attacker.Position;
            float distance = diff.sqrMagnitude;
            if (!(distance < visibilityRange)) continue;

            diff = hero.LastHitter.Position - Attacker.Position;
            distance = diff.sqrMagnitude;
            if (!(distance < attackRange)) continue;

            Attacker.AttackTarget = hero.LastHitter;
            yield return NodeResult.Success;
        }

        yield return NodeResult.Failure;
    }

	/* Atakuj entity które atakuje ciebie
     */
    public IEnumerator<NodeResult> AttackLastHitterInAttackRange() {
        var attackRange = Attacker.AttackRange * Attacker.AttackRange;

        if (Attacker.LastHitter != null && Attacker.LastHitTime > 1f && Attacker.CanTargetEnemy(Attacker.LastHitter)) {
            if (Attacker.HasInAttackRange(Attacker.LastHitter)) {
                Attacker.AttackTarget = Attacker.LastHitter;
                yield return NodeResult.Success;
            }
        }

        yield return NodeResult.Failure;
    }

	/* Atakuj entity które atakuje ciebie
     */
    public IEnumerator<NodeResult> AttackLastHitterInVisibilityRange() {
        //var visibilityRange = Attacker.VisibilityRange * Attacker.VisibilityRange;

        if (Attacker.LastHitter != null && Attacker.LastHitTime > 1f && Attacker.CanTargetEnemy(Attacker.LastHitter)) {
            if (Attacker.HasInVisibilityRange(Attacker.LastHitter)) {
                Attacker.AttackTarget = Attacker.LastHitter;
                yield return NodeResult.Success;
            }
        }

        yield return NodeResult.Failure;
    }

	/// <summary>
	/// Atakuj najbliższego wrogiego Miniona
	/// </summary>
	/// <returns></returns>
	public IEnumerator<NodeResult> AttackClosestMinionInVisibilityRange()
	{
		IEnumerator<NodeResult> task;
		//var name = "AttackClosestMinionInVisibilityRange";
		//if (!searchCoroutines.TryGetValue(name, out task))
		{
			//var entities = EntityManager.instance.GetEnemyEntitiesOfType(Entity, EType.Minion);
			var entities = GetEntitiesInArea(Attacker.VisibilityRange);
			task = AttackClosestEnemyInRange(entities, Attacker.VisibilityRange, EType.Minion);
		}
		var e = task;

		while (e.MoveNext())
			yield return e.Current;
			
		yield return NodeResult.Success;
	}

	/// <summary>
	/// Atakuj najbliższego wrogiego Miniona
	/// </summary>
	/// <returns></returns>
	public IEnumerator<NodeResult> AttackClosestMinionInAttackRange()
	{
		IEnumerator<NodeResult> task;
		//var name = "AttackClosestMinionInAttackRange";
		//if (!searchCoroutines.TryGetValue(name, out task))
		{
			//var entities = EntityManager.instance.GetEnemyEntitiesOfType(Entity, EType.Minion);
			var entities = GetEntitiesInArea(Attacker.AttackRange);
			task = AttackClosestEnemyInRange(entities, Attacker.AttackRange, EType.Minion);
		}

		var e = task;

		while (e.MoveNext())
			yield return e.Current;

		yield return NodeResult.Success;
	}
	
	public IEnumerator<NodeResult> AttackClosestSpawnInAttackRange()
	{
		IEnumerator<NodeResult> task;
		//var name = "AttackClosestSpawnInAttackRange";
		//if (!searchCoroutines.TryGetValue(name, out task))
		{
			//var entities = EntityManager.instance.GetEnemyEntitiesOfType(Entity, EType.Spawn);
			var entities = GetEntitiesInArea(Attacker.AttackRange);
			task = AttackClosestEnemyInRange(entities, Attacker.AttackRange, EType.Spawn);
		}

		var e = task;

		while (e.MoveNext())
			yield return e.Current;

		yield return NodeResult.Success;
	}

    /// <summary>
    /// Atakuj najbliższego wrogiego Monstera
    /// </summary>
    /// <returns></returns>
    public IEnumerator<NodeResult> AttackClosestMonsterInAttackRange() {
        IEnumerator<NodeResult> task;
        //var name = "AttackClosestMonsterInVisibilityRange";
        //if (!searchCoroutines.TryGetValue(name, out task))
        {
            //var entities = EntityManager.instance.GetEnemyEntitiesOfType(Entity, EType.Minion);
            var entities = GetEntitiesInArea(Attacker.AttackRange);
            task = AttackClosestEnemyInRange(entities, Attacker.VisibilityRange, EType.Monster);
        }
        var e = task;

        while (e.MoveNext())
            yield return e.Current;

        yield return NodeResult.Success;
    }


	/// <summary>
	/// Atakuj najbliższrgo wrogiego Hero
	/// </summary>
	/// <returns></returns>
	public IEnumerator<NodeResult> AttackClosestHeroInVisibilityRange()
	{
		IEnumerator<NodeResult> task;
		//var name = "AttackClosestHeroInVisibilityRange";
		//if (!searchCoroutines.TryGetValue(name, out task))
		{
			ICollection<Entity> entities = EntityManager.instance.GetEnemyEntitiesOfType(Entity, EType.Hero);
			task = AttackClosestEnemyInRange(entities, Attacker.VisibilityRange, EType.Hero);
		}
		var e = task;
		while (e.MoveNext())
			yield return e.Current;

		yield return NodeResult.Success;
	}

	/// <summary>
	/// Atakuj najbliższrgo wrogiego Hero
	/// </summary>
	/// <returns></returns>
	public IEnumerator<NodeResult> AttackClosestHeroInAttackRange()
	{
		IEnumerator<NodeResult> task;
		//var name = "AttackClosestHeroInAttackRange";
		//if (!searchCoroutines.TryGetValue(name, out task))
		{
			var entities = EntityManager.instance.GetEnemyEntitiesOfType(Entity, EType.Hero);
			//var data = new StringBuilder("Tower: " + Entity + ", heroes: "); foreach (var entity in entities) data.AppendLine(entity.ToString()); Debug.Log(data.ToString());
			task = AttackClosestEnemyInRange(entities, Attacker.AttackRange, EType.Hero);
		}
		var e = task;
		while (e.MoveNext())
			yield return e.Current;

		yield return NodeResult.Success;
	}

	/// <summary>
	/// Atakuj najbliższego wroga dowolnego typu
	/// </summary>
	/// <returns></returns>
	public IEnumerator<NodeResult> AttackClosestEntityInAttackRange()
	{
		IEnumerator<NodeResult> task;
		//var name = "AttackClosestEntityInAttackRange";
		//if (!searchCoroutines.TryGetValue(name, out task))
		{
			var entities = GetEntitiesInArea(Attacker.VisibilityRange);
			task = AttackClosestEnemyInRange(entities, Attacker.AttackRange);
		}
		var e = task;
        while (e.MoveNext())
        {
            if (Attacker.AttackMode == AttackMode.Manual && Attacker.AttackTarget != null) yield return NodeResult.Failure;
            yield return e.Current;
        }

		yield return NodeResult.Success;
	}

	/// <summary>
	/// Atakuj najbliższego wroga dowolnego typu
	/// </summary>
	/// <returns></returns>
	public IEnumerator<NodeResult> AttackClosestEntityInVisibilityRange()
	{
		IEnumerator<NodeResult> task;
		//var name = "AttackClosestEntityInVisibilityRange";
		//if (!searchCoroutines.TryGetValue(name, out task))
		{
			var entities = GetEntitiesInArea(Attacker.VisibilityRange);
			task = AttackClosestEnemyInRange(entities, Attacker.VisibilityRange);
		}
		var e = task;
		while (e.MoveNext())
			yield return e.Current;

		yield return NodeResult.Success;
	}

	/// <summary>
	/// Atakuj najbliższego wroga w zasięgu ataku, dowolnego typu w trybie ataku 
	/// </summary>
	/// <returns></returns>
	public IEnumerator<NodeResult> AttackClosestAgressorInAttackRange()
	{
		IEnumerator<NodeResult> task;
		//var name = "AttackClosestAgressorInAttackRange";
		//if (!searchCoroutines.TryGetValue(name, out task))
		{
			//var entities = EntityManager.instance.GetEnemyEntities(Entity);
			var entities = GetEntitiesInArea(Attacker.AttackRange);
			task = AttackClosestEnemyInRange(entities, Attacker.AttackRange, EType.Any, EntityState.Attack);
		}
		var e = task;
		while (e.MoveNext())
			yield return e.Current;

		yield return NodeResult.Success;
	}

	/// <summary>
	/// Atakuj najbliższego wroga w zasiegu widoku, dowolnego typu w trybie ataku 
	/// </summary>
	/// <returns></returns>
	public IEnumerator<NodeResult> AttackClosestAgressorInVisibilityRange()
	{
		IEnumerator<NodeResult> task;
		//var name = "AttackClosestAgressorInVisibilityRange";
		//if (!searchCoroutines.TryGetValue(name, out task))
		{
			var entities = GetEntitiesInArea(Attacker.AttackRange);
			task = AttackClosestEnemyInRange(entities, Attacker.VisibilityRange, EType.Any, EntityState.Attack);
		}
		var e = task;
		while (e.MoveNext())
			yield return e.Current;

		yield return NodeResult.Success;
	}
	
    const float chaseRange = 3.0f;
    public IEnumerator<NodeResult> AttackClosestAttackingMeEntityInChaseRange() {
        float chaseRangeWithBelly = chaseRange + Entity.Radius;
        var entities = GetEntitiesInArea(chaseRangeWithBelly);
        var task = AttackClosestEnemyInRange(Attacker, entities, chaseRange, EType.Any,
            e => e.State == EntityState.Attack
                && ((IAttackerControllable)e).AttackTarget != null
                && ((IAttackerControllable)e).AttackTarget == Entity);
        while (task.MoveNext())
            yield return task.Current;
        yield return NodeResult.Success;
    }

    public IEnumerator<NodeResult> AttackClosestEntityInChaseRange() {
        float chaseRangeWithBelly = chaseRange + Entity.Radius;
        var entities = GetEntitiesInArea(chaseRangeWithBelly);
        var task = AttackClosestEnemyInRange(entities, chaseRange);
        while (task.MoveNext())
            yield return task.Current;
        yield return NodeResult.Success;
    }

	public bool IsAutoTargetEnabled()
	{
		return Attacker.IsAutoTargetEnabled;
	}

    [ObsoleteAttribute("This method is obsolete. It's uses an old LoL'like priority system.", true)]
    public IEnumerator<NodeResult> AttackHighestPriorityHitterInAttackRange()
    {
        ICollection<Entity> enTities = GetEntitiesInArea(Attacker.AttackRange);
	    IEntityControllable helpThisEntity = null;
        int highestPriority = 0;
        Vector3 myPosition = Attacker.Position;
        float attackRangeSqr = Attacker.AttackRange * Attacker.AttackRange;

        foreach (Entity entity in enTities)
        {
            if (entity.EntityTeam != Attacker.EntityTeam) continue; // jak nie w naszym teamie to go olewamy
            if (entity.LastHitter == null) continue;
            if (entity.EntityType == EType.Tower) continue;
            if (entity.EntityType == EType.HealingTower) continue;
            if (entity.EntityType == EType.Spawn && !entity.IsMover) continue;
            if (entity.LastHitter.State == EntityState.Dead) continue;
	        if (Attacker.CanTargetEnemy(entity.LastHitter) == false) continue;

            float distance = (entity.LastHitter.Position - myPosition).sqrMagnitude;
            if (!(distance < attackRangeSqr)) continue;

            if (helpThisEntity == null) {
                highestPriority = LastHitterPriority(entity);
	            helpThisEntity = entity;
                continue;
            }

	        var tmpPriority = LastHitterPriority(entity);
	        if (tmpPriority > highestPriority)
	        {
				highestPriority = tmpPriority; 
				helpThisEntity = entity;   
	        }

            yield return NodeResult.Continue;

            if (highestPriority == 0) break;
        }

        if (helpThisEntity == null)
            yield return NodeResult.Failure;

        Attacker.AttackTarget = helpThisEntity.LastHitter;
        yield return NodeResult.Success;
    }

    /// <summary>
    /// Shows log message with time and entity details. Returns success.
    /// </summary>
    /// <returns></returns>
    public IEnumerator<NodeResult> ShowLogMessageAndReturnSuccess()
    {
        Debug.Log("AI log, time: " + Time.time + ", " + Entity.ToString());
        yield return NodeResult.Success;
    }

    [ObsoleteAttribute("This method is obsolete. It's just an old LoL'like priority system.", false)]
    static public int LastHitterPriority(IEntityControllable entity)
    {
        int priority = 0;
        EType entityType = entity.EntityType;
        EType hitterType = entity.LastHitter.EntityType;
        if (entityType == EType.Hero && hitterType == EType.Hero) return priority;
        priority--;
        if (entityType == EType.Hero && hitterType == EType.Minion) return priority;
        priority--;
        if ((entityType == EType.Base || entityType == EType.Commander) && hitterType == EType.Hero) return priority;
        priority--;
		if ((entityType == EType.Base || entityType == EType.Commander) && hitterType == EType.Minion) return priority;
        priority--;
        if (entityType == EType.Minion && hitterType == EType.Minion) return priority;
        priority--;
        if (entityType == EType.Minion && hitterType == EType.Tower) return priority;
        priority--;
        if (entityType == EType.Minion && hitterType == EType.Hero) return priority;
        priority--;
        if (entityType == EType.Spawn && hitterType == EType.Tower) return priority;
        priority--;
        if (entityType == EType.Hero && hitterType == EType.Tower) return priority;
        priority--;
        if (entityType == EType.Hero && hitterType == EType.Monster) return priority;
        priority--;
        if (hitterType == EType.Spawn) return priority; //QQQ
        priority--;
        //Debug.Log("LastHitterPriority below minimum: " + priority, entity.LastHitter.LocalEntity);
        //Debug.LogWarning("Attacked entity: " + entity + " LastHitter: " + entity.LastHitter);
        return priority;
    }

	protected ICollection<Entity> GetEntitiesInArea(float range)
	{
#if ENABLE_PROFILER
		Profiler.BeginSample("SearchQaudTree");
#endif
		List<Entity> list;
		if (DebugManager.options[DebugOption.qtree] && QuadTreeSystem.instance!=null)
		{
			list = QuadTreeSystem.instance.QuadTree.Query(
				new BoundingRect(Attacker.Position, range)
				);
		}
		else list = new List<Entity>();
#if ENABLE_PROFILER
		Profiler.EndSample();
#endif
		return list;
	}

	private bool IsTargetableEnemy(IEntityControllable defender)
	{
		return Attacker.CanTargetEnemy(defender);
	}

	public bool IsStateEqualAttack()
	{
		return Attacker.State == EntityState.Attack;
	}

	public bool IsAttackModeEqualAuto()
	{
		return Attacker.AttackMode == AttackMode.Auto;
	}

	public bool IsAttackModeEqualManual()
	{
		return Attacker.AttackMode == AttackMode.Manual;
	}

	public void SetAttackModeToAuto()
	{
		Attacker.AttackMode = AttackMode.Auto;
	}

	public void SetAttackModeToManual()
	{
		Attacker.AttackMode = AttackMode.Manual;
	}

    public bool HasAttackTarget()
    {
        return Attacker.HasAttackTarget;
    }

    public bool IsAttackTargetAHero() {
        return Attacker.AttackTarget != null && Attacker.AttackTarget.EntityType == EType.Hero;
    }

    public bool IsAllyHeroCloseby() {
        var heroes = EntityManager.instance.GetEntitiesOfType(Entity.EntityTeam, EType.Hero);
        var closeHeroes = heroes.Where(h => Attacker.HasInAttackRange(h));
        return closeHeroes.Any();
    }

    public IEnumerator<NodeResult> AttackClosestEnemyBuilding() {
        var towers = EntityManager.instance.GetEnemyEntitiesOfType(Attacker, EType.Tower);
        Entity target = towers.Where(t => t.IsTargetableBy(Attacker))
            .OrderBy(t => (Attacker.Position - t.Position).sqrMagnitude)
            .FirstOrDefault();
        if (target == null) target = EntityManager.instance.GetEnemyBaseOrCommander(Attacker);

        while (target != null && target.IsTargetableBy(Attacker)) {
            Attacker.AttackTarget = target;
            yield return NodeResult.Continue;
        }
        yield return NodeResult.Success;
    }
}
