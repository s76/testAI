﻿using Assets._Controllable.BasicEntity;
using React;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using UnityEngine;

class MovingSpawnActions : MoverActions {

    public float minLifeTime = 0f;

    protected IMovingSpawnControllable MovingSpawn { get; set; }
    protected IEntityControllable Owner { get { return MovingSpawn == null ? null : MovingSpawn.SpawnOwner; } }

    protected bool isSkillUsed = false;

    public override void Initialize(IEntityControllable entity) {
        MovingSpawn = (IMovingSpawnControllable)entity;
        base.Initialize(entity);

    }

    public bool IsMinLifeTimeExpired() {
        return Entity.LocalEntity.InitTime + minLifeTime < Time.time;
    }

    public bool IsEnemyInAttackRange() {
        ICollection<Entity> entities = GetEntitiesInArea(Attacker.AttackRange);
        foreach (Entity e in entities) {
            if (MovingSpawn.IsEnemy(e) && Attacker.HasInAttackRange(e))
                return true;
        }
        return false;
    }

    public IEnumerator<NodeResult> UseSkill() {
        MovingSpawn.UseSkill();
        isSkillUsed = true;
        if (MovingSpawn.IsSelfDestruct) {
            StartCoroutine(KillThyselfAfterSecond());
        }
        yield return NodeResult.Success;
    }

    public bool IsExpired() {
        return MovingSpawn.LifeTimeLeft <= 0f;
    }

    public IEnumerator KillThyselfAfterSecond() {
        yield return new WaitForSeconds(1f);
        MovingSpawn.StateSync = EntityState.Dead;
    }

    public IEnumerator<NodeResult> KillThyself() {
		MovingSpawn.StateSync = EntityState.Dead;
        yield return NodeResult.Success;
    }

    public bool IsSkillUsed() {
        return isSkillUsed;
    }

    public bool IsSkillUnUsed() {
        return !isSkillUsed;
    }

    public virtual IEnumerator<NodeResult> GoToOwner() {
        MovingSpawn.MoveTargetPosition = MovingSpawn.SpawnOwner.Position;
        yield return NodeResult.Success;
    }
}
