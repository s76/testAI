﻿using UnityEngine;
using System.Collections;
using React;
using System.Collections.Generic;
using System;
using Assets._Controllable.BasicEntity;
using System.Linq;
using Assets._AI.Actions;
using Assets._AI;



class ConquestMonsterActions : MonsterActions {

    List<EntityAggro> aggroList = new List<EntityAggro>();

    public override void Initialize(IEntityControllable entity) {
        base.Initialize(entity);
        var controller = entity.Controller;
        controller.onHandleHit += controller_onHandleHit;

    }

    void controller_onHandleHit(float dmg, IAttackerControllable attacker, Skill skill) {
        var aggro = aggroList.FirstOrDefault(a => a.entity == attacker);
        if (aggro != null) {
            aggro.aggro += dmg;
        } else {
            aggro = new EntityAggro(attacker, dmg);
            aggroList.Add(aggro);
        }
        aggroList.Sort((a1, a2) => (int)(a2.aggro - a1.aggro));
    }

    public IEnumerator<NodeResult> AttackAggroTarget() {
        var targetAggro = aggroList.FirstOrDefault();
        if (targetAggro != null) {
            var target = targetAggro.entity;
            if (Attacker.CanTargetEnemy(target)) {
                Attacker.AttackTarget = target;
            } else {
                aggroList.Remove(targetAggro);
            }
            yield return NodeResult.Success;
        } else yield return NodeResult.Failure;
    }

    public IEnumerator<NodeResult> AttackClosestEnemyHero() {
        var heroes = EntityManager.instance.GetEntitiesOfType(EType.Hero);
        IEntityControllable closest = null;
        if (heroes != null) {
            closest = heroes.ClosestTo(Attacker, (e => Attacker.CanTargetEnemy(e)));
            if (closest != null) {
                Attacker.AttackTarget = closest;
                yield return NodeResult.Success;
            } else {
                yield return NodeResult.Failure;
            }
        } else {
            yield return NodeResult.Failure;
        }
    }

    void OnDestroy() {
        Entity.Controller.onHandleHit -= controller_onHandleHit;
    }

    class EntityAggro {
        public IEntityControllable entity;
        public float aggro;

        public EntityAggro(IEntityControllable entity, float aggro) {
            this.entity = entity;
            this.aggro = aggro;
        }
    }
}