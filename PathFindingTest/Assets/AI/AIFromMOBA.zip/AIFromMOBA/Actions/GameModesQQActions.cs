﻿using UnityEngine;
using System.Collections;
using Assets.maps;
using Assets._Controllable.BasicEntity;
using System.Collections.Generic;
using React;
using Assets._Controller;
using System.Linq;
using Assets._Client;

public class GameModesQQActions : MonoBehaviour {

    Hero Hero;

    void Awake() {
        Hero = transform.parent.gameObject.GetComponent<Entity>() as Hero;
        if (Hero == null) Debug.LogError("No hero in parent?", this);
    }

    IEnumerable<Entity> ConquestPoints { get { return EntityManager.instance.GetEntitiesOfType(EType.ConquestPoint); } }

    public bool IsCurrentMapModeCP() {
        return MapManager.instance.LastLoadedMap.gameMode == GameMode.ConquestPoint;
    }

    public bool IsCurrentMapModeBrawler() {
        return MapManager.instance.LastLoadedMap.gameMode == GameMode.Brawler;
    }        
}
