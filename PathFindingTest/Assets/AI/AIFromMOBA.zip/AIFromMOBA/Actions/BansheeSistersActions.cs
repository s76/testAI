﻿using UnityEngine;
using System.Collections;
using Assets._AI.Actions;
using Assets._Controllable.BasicEntity;
using System;
using System.Collections.Generic;
using QTree;

namespace Assets._AI.Actions {
    class BansheeSistersActions : SimpleSpawnActions {

        public override void Initialize(IEntityControllable entity) {
            base.Initialize(entity);
        }

        public bool CannotStayAlive() 
		{
			bool cannot = (Spawn.Position - Owner.Position).sqrMagnitude > 49f || !((BansheeSister)Spawn.LocalEntity).IsTargetAlive;
			return cannot;
        }

    }
}
