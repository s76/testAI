﻿using Assets._Client;
using React;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using UnityEngine;

namespace Assets._AI.Actions {
    class MinionActions : MoverActions {
        MinionMasterController controller;

        public override void Initialize(_Controllable.BasicEntity.IEntityControllable entity) {
            controller = entity.Controller as MinionMasterController;
            base.Initialize(entity);
        }

        public IEnumerator<NodeResult> ReturnToWaypoint() {
            Attacker.AttackTarget = null;
            Mover.MoveTargetPosition = controller.CurrentWaypoint();
            yield return NodeResult.Success;
        }

        public bool IsGuarding() {
            return (controller.priorityOfGuardingEntity != null);
        }

        public bool IsGuardingTooLong() {
            return Time.time > controller.guardUntilTime;
        }

        public IEnumerator<NodeResult> stopGuarding() {
            controller.priorityOfGuardingEntity = null;
            controller.guardingEntity = null;
            if (!IsAttackTargetAliveAndInAttackRange()) Attacker.AttackTarget = null;
            yield return NodeResult.Success;
        }

        public override IEnumerator<NodeResult> AttackEnemyBase() {
            if (controller.Waypoints == null)
                yield return NodeResult.Failure;

            controller.ClosestWaypoint();
            if ((Mover.EntityTeam == Team.East && controller.currentWaypoint == 0) ||
                (Mover.EntityTeam == Team.West && controller.currentWaypoint == controller.Waypoints.Length - 1)) {
                Attacker.AttackTarget = EntityManager.instance.GetEnemyBaseOrCommander(Entity);
            } else {
                controller.NextClosestWaypoint();
                Mover.MoveTargetPosition = controller.Waypoints[controller.currentWaypoint];
            }

            yield return NodeResult.Success;
        }
    }
}
