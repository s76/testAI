﻿using Assets._Controllable.BasicEntity;
using React;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using UnityEngine;

class GargoyleActions : MovingSpawnActions {
    public float preparationDelay = 1.0f;
    public float minDistanceToExplode = 1.5f;
    private float initializationTime = Mathf.Infinity;
    
    public override void Initialize(IEntityControllable entity)
    {
        base.Initialize(entity);

        initializationTime = Time.time;
    }

    public IEnumerator<NodeResult> AttackEntityInRangeOf3() {
        const float range = 3.0f;

        var entities = GetEntitiesInArea(range);
        IEnumerator<NodeResult> enumerator = AttackClosestEnemyInRange(entities, range + Entity.Radius, EType.Any);

        while (enumerator.MoveNext())
            yield return enumerator.Current;

        yield return NodeResult.Success;
    }

    public IEnumerator<NodeResult> KABOOM() {
        Debug.LogWarning("[Gaygoyle] KABOOM not implemented.", this);
        yield return NodeResult.Success;
    }

    public bool IsTargetInDistanceToExplode() {
        return Attacker.HasInRange(Attacker.AttackTarget, minDistanceToExplode);
    }

    public bool IsPreparedToAct()
    {
        return Time.time > initializationTime + preparationDelay;
    }
}

