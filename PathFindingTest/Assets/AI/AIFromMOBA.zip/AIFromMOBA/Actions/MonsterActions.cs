﻿using React;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Assets._AI.Actions
{
    class MonsterActions : MoverActions
    {
        private Vector3 spawnPoint;
        public float maxDistanceFromWaypoint;
        public float distanceFromCampConsideredAsReturned = 1;

        public override void Initialize(_Controllable.BasicEntity.IEntityControllable entity)
        {
            base.Initialize(entity);
            spawnPoint = Entity.Position;
        }

        public bool IsTooFarFromSpawnPoint()
        {
            return (DistanceFromSpawnPointSqr() > MaxDistanceFromWaypointSqr);
        }

        private float DistanceFromSpawnPointSqr()
        {
            Vector2 position2D = new Vector2(Entity.Position.x, Entity.Position.z);
            Vector2 spawnPoint2D = new Vector2(spawnPoint.x, spawnPoint.z); 
            float distanceFromSpawnPointSqr = (position2D - spawnPoint2D).sqrMagnitude;
            return distanceFromSpawnPointSqr;
        }

        public IEnumerator<NodeResult> ReturnToSpawnPoint()
        {
            Attacker.AttackTarget = null;
            Mover.MoveTargetPosition = spawnPoint;
            while (DistanceFromSpawnPointSqr() > ReturnedDistanceSqr) yield return NodeResult.Continue;
            yield return NodeResult.Success;
        }

        private float MaxDistanceFromWaypointSqr { get { return maxDistanceFromWaypoint * maxDistanceFromWaypoint; } }

        private float ReturnedDistanceSqr { get { return distanceFromCampConsideredAsReturned * distanceFromCampConsideredAsReturned; } }
    }
}
