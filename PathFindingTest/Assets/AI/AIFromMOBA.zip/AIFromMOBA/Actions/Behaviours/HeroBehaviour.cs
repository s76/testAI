﻿using Assets._Client;

namespace Assets._AI.Actions.Behaviours {
    public abstract class HeroBehaviour : Behaviour {
        protected IHeroControllable Hero;
        protected Team allyTeam;
        protected Team enemyTeam;

        public override void Initialize() {
            base.Initialize();
            Hero = (IHeroControllable) Entity;
            allyTeam = Hero.EntityTeam;
            enemyTeam = Hero.TeamOfEnemy;
        }

        public bool HasBeenHitRecently()
        {
            return Hero.HasBeenHitRecently();
        }

        private const float minimumHealthPercent = 0.5f;
        public bool IsHurt()
        {
            return Hero.Life / Hero.MaxLife < minimumHealthPercent;
        }
    }
}
