﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Assets._AI;
using React;


class TrollActionsWithHeroes : ActionsWithHeroes
{
    private const int StoneTossId = 0; //LineShot, exp range 2.5, range 8
    private const int EarthquakeId = 1; //Area, exp range 3.5
    private const int MonstrousStengthId = 2; //LineShot, casttime 1, range 8, exp range 4, second range 3.05

    public IEnumerator<NodeResult> CastStoneToss()
    {
        if (Hero.AttackTarget != null && Hero.HasInAttackRange(Hero.AttackTarget))
        {
            return CastLineShotAtTarget(StoneTossId);
        }
        return Enumerable.Empty<NodeResult>().GetEnumerator();
    }

    public bool CanCastEarthquake()
    {
        return GetReadySkill(EarthquakeId);
    }

    public bool CanHitTwoTargetsWithEarthquake()
    {
        var skill = Hero.GetSkill(EarthquakeId);
        if (skill == null) { return false; }

        return HasEnemyHeroesInRangeWthoutBellys(2, skill.ExplosionRange, skill.CastTime);
    }

    public bool CanHitAttackTargetWithEarthquake()
    {
        return CanHitAttackTargetWithAura(EarthquakeId);
    }

    public IEnumerator<NodeResult> CastEarthquake()
    {
        return CastAuraSkill(EarthquakeId);
    }

    public IEnumerator<NodeResult> CastMonstrousStrength()
    {
        return CastLineShotAtTarget(MonstrousStengthId);
    }

    public IEnumerator<NodeResult> CastStoneTossDefensively()
    {
        var skill = Skill.GetSkillForHero(StoneTossId, Hero);
        var skillRange = skill.Range;

        return CastLineShotAt(StoneTossId, enemyHeroes.FirstOrDefault(eh => Hero.HasInRange(eh, skillRange)));
    }
}

