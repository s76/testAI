﻿using Assets._AI.Actions.Behaviours;
using Assets._AI.Shopping;
using Assets._Common;
using Assets._Inventory.New;
using Assets._AI;
using Assets._Controllable.BasicEntity;
using React;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using UnityEngine;

class ActionsWithVendor : BotBehaviour {
    List<VendorEntity> Vendors { get { return commonCache.Vendors[allyTeam]; } }
    private ShoppingAI shoppingAi;

    //Id lastBoughtItemId = null;
    //Id nextItemIdToBuy = null;
    //int shoplistIndexOfNextItemToBuy = 0;
    //bool boughtEverything = false;

    protected override bool AreRequirementsMet() {
        return commonCache.IsCached(allyTeam, Assets._AI.BotCache.Vendors);
    }

    public override void Initialize()
    {
        base.Initialize();
        shoppingAi = gameObject.AddComponent<ShoppingAI>().Initialize(Hero);
    }

    protected bool IsNearVendor(VendorEntity vendor)
    {
        return vendor.HasInRange(Hero, vendor.VendorShopRange);
    }

    public bool IsNearVendor()
    {
        var closestVendor = Vendors.ClosestTo(Hero);
        if (closestVendor == null)
        {
            Debug.LogError("[BotsAI] " + Hero.CharacterName + ":  No vendor? No shop shop?", this);
            return false;
        }
        return IsNearVendor(closestVendor);
    }

    public IEnumerator<NodeResult> GoToVendor() {
        //const float closeEnough = 2.0f;
        var closestVendor = Vendors.ClosestTo(Hero);
        if (closestVendor == null) {
            Debug.LogError("[BotsAI] " + Hero.CharacterName + ":  No vendor? No shop shop?", this);
            yield return NodeResult.Failure;
        }
        while (IsNearVendor(closestVendor) == false) {
            Hero.MoveTargetPosition = closestVendor.Position;
            yield return NodeResult.Continue;
        }
        yield return NodeResult.Success;
    }

    public bool HasOver1k2Gold()
    {
        return Hero.Wallet.Cash >= 1200;
    }

    public bool CanBuyNextItem()
    {
        return shoppingAi.CanBuyItem();
    }

    //    if (boughtEverything == true) return false;
    //    UpdateItemToBuy();
    //    if (nextItemIdToBuy == null) return false;
    //    var closestVendor = Vendors.ClosestTo(Hero);
    //    if (closestVendor == null) {
    //        Debug.LogError("[BotsAI] " + Hero.CharacterName + ":  No vendor? No shop shop?", this);
    //        return false;
    //    }
    //    return closestVendor.Shop.CanBuyItem(nextItemIdToBuy, Hero.Wallet, Hero.Inventory);
    //}

    //private void UpdateItemToBuy() {
    //    if (nextItemIdToBuy == null || nextItemIdToBuy == lastBoughtItemId) {
    //        var shoppingList = BotManager.instance.botsShopLists.FirstOrDefault(list => list.botName.Contains(Hero.CharacterName));
    //        if (shoppingList == null)
    //            shoppingList = BotManager.instance.botsShopLists.FirstOrDefault(list => list.botName.Contains("Default"));
    //        if (shoppingList == null) {
    //            Debug.LogError("[BotsAI] " + Hero.CharacterName + ": Where is my shoplist? Gimme my shoplist!", this);
    //            nextItemIdToBuy = null;
    //            return;
    //        }
    //        if (shoplistIndexOfNextItemToBuy >= shoppingList.itemIDs.Length) {
    //            boughtEverything = true;
    //            nextItemIdToBuy = null;
    //            return;
    //        }
    //        nextItemIdToBuy = new Id(shoppingList.itemIDs[shoplistIndexOfNextItemToBuy]);
    //    }
    //}

    public IEnumerator<NodeResult> BuyItems()
    {
        if (shoppingAi.BuyItem()) { yield return NodeResult.Success; }
        yield return NodeResult.Failure;
    }

    //    if (boughtEverything == true) yield return NodeResult.Failure;
    //    UpdateItemToBuy();
    //    if (nextItemIdToBuy == null) yield return NodeResult.Failure;
    //    var closestVendor = Vendors.ClosestTo(Hero);
    //    if (closestVendor == null) {
    //        Debug.LogError("[BotsAI] " + Hero.CharacterName + ":  No vendor? No shop shop?", this);
    //        yield return NodeResult.Failure;
    //    }
    //    if (closestVendor.Shop.CanBuyItem(nextItemIdToBuy, Hero.Wallet, Hero.Inventory) == false)
    //        yield return NodeResult.Failure;
    //    if (closestVendor.Shop.Buy(nextItemIdToBuy, Hero.Wallet, Hero.Inventory) != null) {
    //        lastBoughtItemId = nextItemIdToBuy;
    //        shoplistIndexOfNextItemToBuy++;
    //        UpdateItemToBuy();
    //        yield return NodeResult.Success;
    //    } else {
    //        Debug.LogError("[BotsAI] " + Hero.CharacterName + ": Vendor told me I can buy item but I couldn't. Boohoo.", this);
    //        yield return NodeResult.Failure;
    //    }
    //}

    public override bool IsAIReady() {
        return _IsAIReady();
    }
}

