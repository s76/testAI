﻿using Assets._AI;
using Assets._AI.Actions.Behaviours;
using Assets._Client;
using React;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

class ActionsWithIntel : BotBehaviour {

    private List<VendorEntity> enemyIntelVendors { get { throw new NotImplementedException(); } }

    protected override bool AreRequirementsMet() {
        return commonCache.IsCached(Team.None, BotCache.IntelVendors);
    }

    public IEnumerator<NodeResult> AttackIntelVendor() {
        float distanceToDecideToAttack = 30;

        throw new NotImplementedException();

        foreach (var vendor in enemyIntelVendors) {
            if (Hero.CanTargetEnemy(vendor) && Hero.HasInRange(vendor, distanceToDecideToAttack)) {
                Hero.AttackTarget = vendor;
                while (vendor.IsAlive) yield return NodeResult.Continue;
                yield return NodeResult.Success;
            } else continue;
        }
        yield return NodeResult.Failure;
    }

    public override bool IsAIReady() {
        throw new NotImplementedException();
    }
}

