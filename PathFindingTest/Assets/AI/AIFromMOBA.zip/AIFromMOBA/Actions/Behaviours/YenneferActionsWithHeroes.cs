﻿using Assets._Controller.Dispatcher;
using Assets._AI;
using React;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using UnityEngine;
using UnityMock;
using ScriptableSkills;


class YenneferActionsWithHeroes : ActionsWithHeroes
{
	const int ravenLordtId = 0;
	const int weddingId = 1;
	const int cageId = 2;

    public override void Initialize()
    {
        base.Initialize();
    }
	
    public IEnumerator<NodeResult> UseRavenLord()
    {
        Skill skill = Hero.GetSkill(ravenLordtId);
        Skill weddingSkill = Hero.GetSkill(weddingId);
        if (skill == null || CanCast(skill) == false) yield return NodeResult.Failure;

        float skillRange = skill.Range - Hero.Radius;
        var enemyHeroesInRange = enemyHeroes.Where(eH => eH.IsTargetableBy(Hero) && Hero.HasInRange(eH, skillRange));
		if(enemyHeroesInRange.Count() == 0)
			 yield return NodeResult.Failure;

		Vector3 targetPos = Vector3.zero;
		bool useSkill = false;
		var weakestEnemy = enemyHeroesInRange.GetWeakest();
		if(weddingSkill.IsActivable || weddingSkill.Level == 0)
		{
			if(HeroValue(weakestEnemy) < HeroValue(Hero))
			{
				useSkill = true;
				targetPos = weakestEnemy.Position;
			}
		}
		else//wedding skill was used few secs ago
		{
			useSkill = true;
			targetPos = weakestEnemy.Position;
		}

		if(useSkill)
		{
			Hero.UseSkill(skill, new SkillParams() { startPosition = Hero.Position, endPosition = targetPos });
			yield return NodeResult.Success;
		}
		else
			yield return NodeResult.Failure;
    }
    
    public IEnumerator<NodeResult> UseWeddingRing()
    {
        Skill skill = Hero.GetSkill(weddingId);
        if (skill == null || CanCast(skill) == false) yield return NodeResult.Failure;

        float skillRange = skill.Range - Hero.Radius;
        var enemyHeroesInRange = enemyHeroes.Where(eH => eH.IsTargetableBy(Hero) && Hero.HasInRange(eH, skillRange));
		if(enemyHeroesInRange.Count() == 0)
			 yield return NodeResult.Failure;
		
		Vector3 targetPos = Vector3.zero;
		bool useSkill = false;
		if(enemyHeroesInRange.Count() == 1)
		{
			var firstEnemy = enemyHeroesInRange.First();
			if(firstEnemy.Life / firstEnemy.MaxLife < 0.25f || Hero.Life / Hero.MaxLife < 0.5f)//enemy is weak or we are going to escape soon
			{
				targetPos = firstEnemy.Position;
				useSkill = true;
			}
		}
		else
		{
			targetPos = enemyHeroesInRange.ToList().GetHitableCenter(skill.ExplosionRange);
			if (targetPos == Vector3.zero) 
				useSkill = false;
			else
				useSkill = true;
		}

		if(useSkill)
		{
			Hero.UseSkill(skill, new SkillParams() { targetPosition = targetPos });
			yield return NodeResult.Success;
		}
		else
			yield return NodeResult.Failure;
    }
	
    public IEnumerator<NodeResult> UseCage()
    {
        Skill skill = Hero.GetSkill(cageId);
        if (skill == null || CanCast(skill) == false) yield return NodeResult.Failure;

        float skillRange = skill.Range - Hero.Radius;
        var enemyHeroesInRange = enemyHeroes.Where(eH => eH.IsTargetableBy(Hero) && Hero.HasInRange(eH, skillRange));
		if(enemyHeroesInRange.Count() == 0)
			 yield return NodeResult.Failure;
		
		Vector3 targetPos = Vector3.zero;
		bool useSkill = false;
		if(enemyHeroesInRange.Count() == 1)
		{
			//do nothing - its waste of skill and huge possibility to die
		}
		else if(Hero.Life / Hero.MaxLife > 0.25f)
		{
			targetPos = enemyHeroesInRange.ToList().GetHitableCenter(skill.ExplosionRange);
			if (targetPos == Vector3.zero) 
				useSkill = false;
			else
				useSkill = true;
		}

		if(useSkill)
		{
			Hero.UseSkill(skill, new SkillParams() { targetPosition = targetPos });
			yield return NodeResult.Success;
		}
		else
			yield return NodeResult.Failure;
    }
}