﻿using Assets._AI;
using Assets._Client;
using Assets._Controllable.BasicEntity;
using React;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using UnityEngine;


class ActionsWithCPAndHeroes : BotBehaviour
{
    protected List<Hero> allyHeroes { get { return commonCache.Heroes[allyTeam]; } }
    protected List<ConquestPoint> conquestPoints { get { return commonCache.ConquestPoints[Team.None]; } }
    protected List<Hero> enemyHeroes { get { return commonCache.Heroes[enemyTeam]; } }

    protected IEnumerable<ConquestPoint> pointsInNeed
    {
        get { return conquestPoints.Where(cp => cp.LastCaptureTeam != allyTeam || cp.CapturingTeam == enemyTeam); }
    }

    protected override bool AreRequirementsMet()
    {
        return commonCache.IsCached(allyTeam, BotCache.Heroes)
               && commonCache.IsCached(enemyTeam, BotCache.Heroes);
    }

    public IEnumerator<NodeResult> GoToCPClosestAndSafe()
    {
        Func<Entity> closestCPGetter = () =>
            conquestPoints.Where(
                cp => cp.LastCaptureTeam != allyTeam && enemyHeroes.Any(eh => eh.IsTargetableBy(Hero) && cp.HasInRange(eh, Hero.VisibilityRange)) == false)
                .ClosestTo(Hero);

        return GoTo(closestCPGetter,
            refreshTarget: true,
            positionModifier: e => PositionModifierRandomOffset(e, e.VisibilityRange, e.radius + Hero.Radius));

    }

    public IEnumerator<NodeResult> GoToCPBeingCapturedByEnemyIf()
    {
        var closestCP = pointsInNeed.ClosestTo(Hero);
        if (closestCP != null && closestCP.CapturingTeam == enemyTeam)
        {
            float allyTeamValue =
                allyHeroes.Where(ah => (Hero.HasInVisibilityRange(ah) || closestCP.HasInRange(ah, Hero.VisibilityRange)) && ah.IsAlive)
                    .Select(ah => ActionsWithHeroes.HeroValue(ah))
                    .Sum();
            float enemyTeamValue =
                enemyHeroes.Where(eh => closestCP.HasInRange(eh, Hero.VisibilityRange))
                    .Select(ah => ActionsWithHeroes.HeroValue(ah))
                    .Sum();

            const float requiredAdvantageRatio = 0.8f;
            if (allyTeamValue > enemyTeamValue*requiredAdvantageRatio)
            {
                return GoTo(() => closestCP);
            }
        }
        return (new List<NodeResult>(1) {NodeResult.Failure}).GetEnumerator();
    }

    public IEnumerator<NodeResult> GoToCPClosestToEnemiesCenter()
    {
        return GoTo(
            () => conquestPoints.ClosestTo(enemyHeroes.GetCenter()),
            refreshTarget: true,
            positionModifier: e => PositionModifierRandomOffset(e, e.VisibilityRange, e.radius + Hero.Radius));
    }


    public override bool IsAIReady()
    {
        return _IsAIReady();
    }
}

