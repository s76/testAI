﻿using Assets._Controller.Dispatcher;
using Assets._AI;
using React;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using UnityEngine;
using UnityMock;
using ScriptableSkills;


class CiriActionsWithHeroes : ActionsWithHeroes
{
	const int entityShiftId = 0;
	const int afterImageId = 1;
	const int worldBreakId = 2;
	const int omniId = 4;
	const int slashId = 5;
	private float lastEntityShiftUseTime;
	private float entityShiftCashedDmg;

    public override void Initialize()
    {
        base.Initialize();
        CacheSkillDamage(entityShiftId, (dmg => entityShiftCashedDmg = dmg));
    }
	
    public IEnumerator<NodeResult> UseEntityShift()
    {
        Skill skill = Hero.GetSkill(entityShiftId);
        if (skill == null || CanCast(skill) == false || Hero.Stance != 0) yield return NodeResult.Failure;

        float skillRange = skill.Range - Hero.Radius;
        var enemyHeroesInRange = enemyHeroes.Where(eH => eH.IsTargetableBy(Hero) && Hero.HasInRange(eH, skillRange));
		if(enemyHeroesInRange.Count() == 0)
			 yield return NodeResult.Failure;

		Vector3 midPoint = Hero.Position;
		if(enemyHeroesInRange.Count() == 1)
		{
			var target = enemyHeroesInRange.First();
			midPoint = target.Position;
			float myValue = HeroValue(Hero);
			float enemyValue = HeroValue(target);
			float valueFactor = (enemyValue - myValue) / myValue;
			if(target.Life > Hero.Damage + entityShiftCashedDmg && Hero.Life / Hero.MaxLife > 0.1f //skill gives 1s invulerability so maybe this will rescue her
				&& (lastEntityShiftUseTime + skill.CoolDown * 2f > Time.time || valueFactor > 0.5f))
				yield return NodeResult.Failure;
		}
		else
		{
			midPoint = enemyHeroesInRange.GetCenter();
			if (midPoint.IsNaN()) yield return NodeResult.Failure;
			var closest = enemyHeroesInRange.ClosestTo(midPoint);
			midPoint = closest.Position;
		}

        Hero.UseSkill(skill, new SkillParams() { targetPosition = midPoint });
		lastEntityShiftUseTime = Time.time;
        yield return NodeResult.Success;
    }
    
    public IEnumerator<NodeResult> UseAfterImage()
    {
        Skill skill = Hero.GetSkill(afterImageId);
        if (skill == null || CanCast(skill) == false || Hero.Stance != 0) yield return NodeResult.Failure;

        float skillRange = skill.ExplosionRange;
		bool found = false;
        foreach(var eH in enemyHeroes)
		{
			if(eH.IsTargetableBy(Hero) && Hero.HasInRange(eH, skillRange) && AfterImage.CanBeTargetOfAfterImage(eH))
			{
				found = true;
				break;	
			}
		}
		
		if(found)
		{
			Hero.UseSkill(skill);
			yield return NodeResult.Success;
		}
		else
			yield return NodeResult.Failure;
    }
	
    public IEnumerator<NodeResult> UseWorldBreak()
    {
        Skill skill = Hero.GetSkill(worldBreakId);
        if (skill == null || CanCast(skill) == false || Hero.Stance != 0) yield return NodeResult.Failure;
		
		bool foundTargetable = false;
        foreach(var eH in enemyHeroes)
		{
			if(eH.IsTargetable)
			{
				foundTargetable = true;
				break;
			}
		}
        

		if(foundTargetable)
		{
			Hero.UseSkill(skill);
			yield return NodeResult.Success;
		}
		else
			 yield return NodeResult.Failure;
    }
	
    public IEnumerator<NodeResult> UseOmni()
    {
        Skill skill = Hero.GetSkill(omniId);
        if (skill == null || CanCast(skill) == false || Hero.Stance != 1) yield return NodeResult.Failure;
		
        Hero.UseSkill(skill);
        yield return NodeResult.Success;
    }
	
    public IEnumerator<NodeResult> UseSlash()
    {
        Skill skill = Hero.GetSkill(slashId);
        if (skill == null || CanCast(skill) == false || Hero.Stance != 1) yield return NodeResult.Failure;
		
        Hero.UseSkill(skill);
        yield return NodeResult.Success;
    }
}