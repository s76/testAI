﻿using React;
using Assets._Controllable.BasicEntity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Assets._Controller.Dispatcher;


class ZoltanActionsWithHeroes : ActionsWithHeroes
{
    const int BullRushID = 0; //LineShot (Barge and Charge)
    const int WhirlingDwarvishID = 1; //Aura (Spinning Strike)
    const int WorthItID = 2; //LineShot (Worth It)

    public IEnumerator<NodeResult> CastBullRushAtTarget()
    {
        return CastLineShotAtTarget(BullRushID);
    }

    public IEnumerator<NodeResult> CastWhirlingDwarvishAtTarget()
    {
        var target = Hero.AttackTarget;
        if (target == null) { yield return NodeResult.Failure; }

        var whirlingDwarvish = GetReadySkill(WhirlingDwarvishID);
        if (whirlingDwarvish == null) { yield return NodeResult.Failure; }

        if (target.IsTargetableBy(Hero) && Hero.HasInRangeWithoutBellys(target, whirlingDwarvish.ExplosionRange))
        {
            Hero.UseSkill(whirlingDwarvish);
            yield return NodeResult.Success;
        }
        yield return NodeResult.Failure;
    }

    public IEnumerator<NodeResult> CastWorthItAtTarget()
    {
        return CastLineShotAtTarget(WorthItID);
    }

}

