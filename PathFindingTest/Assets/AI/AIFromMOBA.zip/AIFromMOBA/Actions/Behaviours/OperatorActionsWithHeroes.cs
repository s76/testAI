﻿using React;
using ScriptableSkills;
using Assets._AI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Assets._Controller.Dispatcher;
using Assets._Controllable.BasicEntity;
using UnityEngine;

class OperatorActionsWithHeroes : ActionsWithHeroes
{
    const int TimeBreachID = 0; //AreaTarget
    const int CollapsingPlanesID = 1; //Area
    const int WhenWorldsCollideID = 2; //AreaTarget

    private float _collapsingPlanesCachedDmg;
    private float CollapsingPlanesCachedDmg { get { return _collapsingPlanesCachedDmg; } }

    public override void Initialize()
    {
        base.Initialize();
        CacheSkillDamage(CollapsingPlanesID, (dmg => _collapsingPlanesCachedDmg = dmg));
    }

    const int maxBreachesOnTarget = 3;
    public IEnumerator<NodeResult> CastTimeBreachAtTarget()
    {
        var timeBreach = GetReadySkill(TimeBreachID);
        if (timeBreach == null || Hero.AttackTarget == null) { yield return NodeResult.Failure; }

        int breachesOnTarget = TheBreach.GetBreachesCount(Hero, Hero.AttackTarget);
        if (breachesOnTarget < maxBreachesOnTarget)
        {
            var targetPosition = enemyHeroes.Where(eH => Hero.AttackTarget.HasInRange(eH, timeBreach.ExplosionRange * 2)).GetCenter();
            if (Hero.HasInRange(targetPosition, timeBreach.Range) == false) {
                targetPosition = ClampTargetToMaxRange(timeBreach, targetPosition); //LineShotEndPosition(timeBreach, targetPosition);
                if (enemyHeroes.Any(eH => targetPosition.HasInRange(eH.Position, timeBreach.ExplosionRange)) == false) { yield return NodeResult.Failure; }
            }
            Hero.UseSkill(timeBreach, new SkillParams { targetPosition = targetPosition });
            yield return NodeResult.Success;
        }
        yield return NodeResult.Failure;
    }

    public IEnumerator<NodeResult> CastCollapsingPlanesForKill()
    {
        var collapsingPlanes = GetReadySkill(CollapsingPlanesID);
        if (collapsingPlanes == null) { yield return NodeResult.Failure; }

        foreach (var eH in enemyHeroes)
        {
            int stacksOnEnemyHero = TheBreach.GetBreachesCount(Hero, eH);
            float rawDmg = CollapsingPlanesCachedDmg * stacksOnEnemyHero;
            float potentialLifeLost = eH.CalculateHit(stacksOnEnemyHero, Hero, collapsingPlanes);
            if (potentialLifeLost > eH.Life)
            {
                Hero.UseSkill(collapsingPlanes);
                yield return NodeResult.Success;
                yield break;
            }
        }
        yield return NodeResult.Failure;
    }

    const int minStacksToTriggerPlanes = 3;
    public IEnumerator<NodeResult> CastCollapsingPlanesDefensively()
    {
        var collapsingPlanes = GetReadySkill(CollapsingPlanesID);
        if (collapsingPlanes == null) { yield return NodeResult.Failure; }

        if (Hero.HasBeenHitRecently() || enemyHeroes.Any(eH => eH.IsTargetableBy(Hero) && eH.HasInAttackRange(Hero)))
        {
            int stacks = 0;

            foreach (var eH in enemyHeroes)
            {
                if (eH.IsTargetableBy(Hero))
                {
                    stacks += TheBreach.GetBreachesCount(Hero, eH);
                }
            }

            if (stacks >= minStacksToTriggerPlanes)
            {
                Hero.UseSkill(collapsingPlanes);
                yield return NodeResult.Success;
            }
        }
        yield return NodeResult.Failure;
    }

    public IEnumerator<NodeResult> CastWhenWorldsCollideAtEnemies()
    {
        const int minTargetCount = 2;

        var whenWorldsCollide = GetReadySkill(WhenWorldsCollideID);
        if (whenWorldsCollide == null) { yield return NodeResult.Failure; }

        var firstTarget = Hero.AttackTarget ?? enemyHeroes.Where(eH => eH.IsTargetableBy(Hero)).ClosestTo(Hero);

        if (firstTarget == null || Hero.HasInRangeWithoutBellys(firstTarget, whenWorldsCollide.Range + whenWorldsCollide.ExplosionRange) == false)
        {
            yield return NodeResult.Failure;
        }

        var enemiesInRange = enemyHeroes.Where(eH => eH.IsTargetableBy(Hero) && firstTarget.HasInRangeWithoutBellys(eH, whenWorldsCollide.ExplosionRange * 2));

        var targetCenter = enemiesInRange.GetCenter();
        var caughtEnemiesCount = enemyHeroes.Count(eH => eH.IsTargetableBy(Hero) && targetCenter.HasInRange(eH, whenWorldsCollide.ExplosionRange));
        if (caughtEnemiesCount < minTargetCount) { yield return NodeResult.Failure; }

        var caughtAllies = allyHeroes.Where(aH => aH.IsAlive && targetCenter.HasInRange(aH, whenWorldsCollide.ExplosionRange));
        var caughtAlliesCount = caughtAllies.Count();

        foreach (var aH in caughtAllies)
        {
            if (aH.Id == Hero.Id || caughtEnemiesCount <= caughtAlliesCount)
            {
                const float moveMargin = 0.5f;
                var aH2center = targetCenter - aH.Position;
                var aH2centerDistance = aH2center.magnitude;
                var ah2centerUnitV = aH2center / aH2centerDistance;
                var moveCenterDist = whenWorldsCollide.ExplosionRange - aH2centerDistance;
                targetCenter += ah2centerUnitV * (moveCenterDist + moveMargin);
                
                caughtAlliesCount--;
            }
        }

        targetCenter = ClampTargetToMaxRange(whenWorldsCollide, targetCenter);

        Hero.UseSkill(whenWorldsCollide, new SkillParams { targetPosition = targetCenter });
        yield return NodeResult.Success;
    }
}

