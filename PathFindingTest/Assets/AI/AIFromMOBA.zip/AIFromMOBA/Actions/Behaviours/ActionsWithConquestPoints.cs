﻿using UnityEngine;
using System.Collections;
using Assets._Client;
using Assets._AI;
using System.Collections.Generic;
using React;
using Assets._AI.Actions.Behaviours;
using Assets._Controllable.BasicEntity;
using System.Linq;
using System;

public class ActionsWithConquestPoints : BotBehaviour
{
    protected override bool AreRequirementsMet()
    {
        return commonCache.IsCached(Team.None, BotCache.ConquestPoints);
    }

    private List<ConquestPoint> conquestPoints { get { return commonCache.ConquestPoints[Team.None]; } }

    public IEnumerator<NodeResult> TakeOverConquestPointYoureAt_Meh()
    {
        var conquestPoint = conquestPoints.ClosestTo(Hero);
        if (conquestPoint != null)
        {
            while (conquestPoint.HasInRangeWithoutBellys(Hero, conquestPoint.VisibilityRange) && conquestPoint.CaptureProgress < 1f)
            {
                yield return NodeResult.Continue;
            }
            if (conquestPoint.CaptureProgress >= 1) { yield return NodeResult.Success; }
        }
        yield return NodeResult.Failure;
    }

    public IEnumerator<NodeResult> GoToClosestCP()
    {
        return GoTo(
            entityGetter: () => conquestPoints.ClosestTo(Hero),
            closeEnoughDistance: distanceCloseEnough,
            refreshTarget: true,
            positionModifier: PositionModifierForConquestPoint
            );
    }



    private Vector3 PositionModifierForConquestPoint(Entity e)
    {
        return PositionModifierRandomOffset(e, e.VisibilityRange, e.radius + Hero.Radius);
    }

    const float distanceCloseEnough = 0.1f;

    public IEnumerator<NodeResult> GoToClosestNeutralCP()
    {
        return GoTo(
            entityGetter: () => conquestPoints.Where(cp => cp.LastCaptureTeam == Team.None).ClosestTo(Hero),
            closeEnoughDistance: distanceCloseEnough,
            refreshTarget: true,
            positionModifier: PositionModifierForConquestPoint
            );
    }


    public IEnumerator<NodeResult> GoToClosestEnemyCP()
    {
        return GoTo(
            entityGetter: () => conquestPoints.Where(cp => cp.LastCaptureTeam == Hero.TeamOfEnemy).ClosestTo(Hero),
            closeEnoughDistance: distanceCloseEnough,
            refreshTarget: true,
            positionModifier: PositionModifierForConquestPoint
            );
    }

    public bool ThereAreConquestPointsToTake()
    {
        return conquestPoints.Any(cp => cp.LastCaptureTeam == Hero.TeamOfEnemy || cp.LastCaptureTeam == Team.None);
    }

    public bool IsCapturingConquestPoint()
    {
        var closestCP = conquestPoints.ClosestTo(Hero);
        return closestCP != null && closestCP.HasInVisibilityRange(Hero) && (closestCP.CaptureProgress != 1f || closestCP.LastCaptureTeam == enemyTeam);
    }

    public override bool IsAIReady()
    {
        return _IsAIReady();
    }
}
