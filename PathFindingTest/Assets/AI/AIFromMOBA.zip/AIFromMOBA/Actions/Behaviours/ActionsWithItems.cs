﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Assets._AI;
using Assets._Controllable.BasicEntity;
using Assets._Controller.Dispatcher;
using Assets._Inventory.New;
using Assets._Shop;
using React;
using UnityEngine;

public class ActionsWithItems : BotBehaviour
{
    private float swallowCooldown;
    private float bombCooldown;

    protected override bool AreRequirementsMet()
    {
        return Hero != null;
    }

    public override void Initialize()
    {
        base.Initialize();
        CacheCooldowns();
    }

    public IEnumerator<NodeResult> ThrowBombWithFailure()
    {
        var enumerator = ThrowBomb();
        while (enumerator.MoveNext())
        {
            yield return NodeResult.Failure;
        }
    }

    public bool IsBombCooldownOff()
    {
        return IsItemCooldownOff(ShopCategory.Bombs, bombCooldown);
    }

    public bool IsPotionCooldownOff()
    {
        return IsItemCooldownOff(ShopCategory.Potions, swallowCooldown);
    }

    private bool IsItemCooldownOff(ShopCategory shopCategory, float cooldown)
    {
        var slots = Hero.ConsumableInventory.Slots;
        for (int i = 0; i < slots.Count; ++i)
        {
            var slot = slots[i] as BindedItemSlot;
            if (slot != null
                && slot.ShopCategory == shopCategory
                && NetworkManager.instance.ServerTimeInSeconds > slot.LastActivationTime + cooldown)
            {
                return true;
            }
        }
        return false;
    }

    public bool HasNoBombs()
    {
        return HasNoConsumable(ShopCategory.Bombs);
    }

    public bool HasNoPotions()
    {
        return HasNoConsumable(ShopCategory.Potions);
    }

    private bool HasNoConsumable(ShopCategory shopCategory)
    {
        var bombSlot = GetSlot(shopCategory);
        if (bombSlot == null || bombSlot.Item == null) return true;
        else return false;
    }

    public IEnumerator<NodeResult> UseSwallow()
    {
        var swallowSlot = GetSlot(ShopCategory.Potions);
        if (swallowSlot == null)
        {
            yield return NodeResult.Failure;
            yield break;
        }
        var swallow = (Item)swallowSlot.Item;
        if (swallow.ActiveSkill != null && swallow.CanBeUsed(Hero.ConsumableInventory))
        {
            bool errorOccured = false;
            try
            {
                ((HeroMasterController)Hero.Controller).UseItem(swallow.Id, swallowSlot.Id);
            }
            catch (Exception e)
            {
                Debug.LogError(e, this);
                errorOccured = true;
            }
            if (errorOccured) yield return NodeResult.Failure;
            yield return NodeResult.Success;
        }
        else
        {
            yield return NodeResult.Failure;
        }
    }

    public IEnumerator<NodeResult> UseSwallowAlwaysSuccess()
    {
        var enumerator = UseSwallow();
        while (enumerator.MoveNext())
        {
            yield return NodeResult.Success;
        }
    }

    public IEnumerator<NodeResult> ThrowBomb()
    {
        if (Hero.AttackTarget == null) yield return NodeResult.Failure;

        var bombSlot = GetSlot(ShopCategory.Bombs);
        if (bombSlot == null) yield return NodeResult.Failure;

        var bomb = (Item)bombSlot.Item;
        if (bomb == null) yield return NodeResult.Failure;

        SkillParams skillParams;
        if (GetBombReadyAndFused(bomb, out skillParams))
        {
            if (UseItem(bombSlot, bomb, skillParams))
            {
                yield return NodeResult.Success;
            }
        }
        yield return NodeResult.Failure;
    }

    private bool GetBombReadyAndFused(Item bomb, out SkillParams skillParams)
    {
        if (bomb.ActiveSkill != null && Hero.CanTargetEnemy(Hero.AttackTarget) && bomb.CanBeUsed(Hero.ConsumableInventory))
        {
            var skill = bomb.ActiveSkill;
            switch (skill.Type)
            {
                case SkillType.Area:
                    if (Hero.HasInRangeWithoutBellys(Hero.AttackTarget, skill.ExplosionRange))
                    {
                        skillParams = new SkillParams(); return true;
                    }
                    else { break; }
                case SkillType.AreaTarget:
                    if (Hero.HasInRangeWithoutBellys(Hero.AttackTarget, skill.Range))
                    {
                        skillParams = new SkillParams { targetPosition = Hero.AttackTarget.Position };
                        return true;
                    }
                    else { break; }
                case SkillType.LineShot:
                case SkillType.FrontShot:
                    if (Hero.HasInRangeWithoutBellys(Hero.AttackTarget, skill.Range))
                    {
                        skillParams = new SkillParams { startPosition = Hero.Position, endPosition = LineShotEndPosition(skill, Hero.AttackTarget) };
                        return true;
                    }
                    else { break; }
                default:
#if !PRODUCTION
                    Debug.LogWarning("[BotAI] How the hell do I use " + skill.Type + " bomb? Hurr durr.", this);
#endif
                    break;
            }
        }
        skillParams = null;
        return false;
    }

    private bool UseItem(ISlot<IBaseItem> bombSlot, Item bomb, SkillParams skillParams)
    {
        try
        {
            ((HeroMasterController)Hero.Controller).UseItem(bomb.Id, bombSlot.Id, skillParams);
            return true;
        }
        catch (Exception e)
        {
            Debug.LogError("Exception in UseItem \n" + e, this);
            return false;
        }
    }

    private ISlot<IBaseItem> GetSlot(ShopCategory category)
    {
        var bombSlot = Hero.ConsumableInventory.Slots.FirstOrDefault(
            slot => slot.IsSlotItemCategory(category));
        return bombSlot;
    }

    private void CacheCooldowns()
    {
        try
        {
            bombCooldown = InitDataManager.instance.Items.First(item => item.Id.Value.Contains("Grapeshot")).Cooldown;
            swallowCooldown = InitDataManager.instance.Items.First(item => item.Id.Value.Contains("SwallowTier3")).Cooldown;
        }
        catch (Exception e)
        {
            Debug.LogError("[ActionsAtArena] CacheCooldowns failed \n" + e.ToString());
        }
    }



    public override bool IsAIReady()
    {
        return _IsAIReady();
    }
}

