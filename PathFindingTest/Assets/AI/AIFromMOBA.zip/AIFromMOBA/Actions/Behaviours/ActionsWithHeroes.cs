﻿using Assets._AI;
using Assets._AI.Actions.Behaviours;
using Assets._Client;
using Assets._Controllable.BasicEntity;
using Assets._Controllable.Tower;
using Assets._Controller.Dispatcher;
using QTree;
using React;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using UnityEngine;

public class ActionsWithHeroes : BotBehaviour {

    protected List<Hero> allyHeroes { get { return commonCache.Heroes[allyTeam]; } }
    protected List<Hero> enemyHeroes { get { return commonCache.Heroes[enemyTeam]; } }

    protected List<Tower> allyTowers { get { return GetTowersIfAvailable(allyTeam); } }
    protected List<Tower> enemyTowers { get { return GetTowersIfAvailable(enemyTeam); } }

    protected const float safetyMargin = HeroActions.safetyMargin;

    protected override bool AreRequirementsMet() {
        return commonCache.IsCached(allyTeam, BotCache.Heroes)
            && commonCache.IsCached(enemyTeam, BotCache.Heroes);
    }

    public bool IsAttackTargetAHero()
    {
        return Hero.AttackTarget != null && Hero.AttackTarget.EntityType == EType.Hero;
    }

    public IEnumerator<NodeResult> CarefulEngage() {
        float requiredAdvantageRatio = 2f;

        Hero lHero = (Hero)Hero.LocalEntity;
        float heroDPS = lHero.Damage * lHero.AttackSpeed;

        ////float combinedEnemyDPS = 0;
        //foreach (var enemyHero in enemyHeroes) {
        //    if (enemyHero.IsAlive && enemyHero.HasInAttackRange(Hero, safetyMargin))
        //        combinedEnemyDPS += enemyHero.Damage * enemyHero.AttackSpeed;
        //}
        //Tower tower = (Tower)Closest(enemyTowers, null);
        //if (tower != null)
        //    if (tower.HasInAttackRange(Hero, safetyMargin))
        //        combinedEnemyDPS += tower.Damage * tower.AttackSpeed;

        Hero target = null;
        float bestAdvantageRatio = 0;
        foreach (var enemyHero in enemyHeroes) {
            if (enemyHero.IsAlive && Hero.HasInVisibilityRange(enemyHero) && Hero.HasInLineOfSight(enemyHero)) {
                float combinedEnemyDPS = 0;
                foreach (var coverHero in enemyHeroes.Where(eh => enemyHero.IsCoveredBy(eh, Hero, safetyMargin)))
                    combinedEnemyDPS += coverHero.Damage * coverHero.AttackSpeed;
                foreach (var coverTower in enemyTowers.Where(et => enemyHero.IsCoveredBy(et, Hero, safetyMargin)))
                    combinedEnemyDPS += coverTower.Damage * coverTower.AttackSpeed;
                float heroAliveTime = lHero.Life / combinedEnemyDPS;
                float enemyAliveTime = enemyHero.Life / heroDPS;
                if (Hero.HasInAttackRange(enemyHero) == false) { 
                    if (enemyHero.State == EntityState.Run) {
                        if (enemyHero.MoveSpeed > Hero.MoveSpeed)
                            enemyAliveTime = Mathf.Infinity;
                        else {
                            enemyAliveTime += TimeToGetInRange(Hero, enemyHero, Hero.AttackRange);
                            float relativeSpeed = RelativeSpeed(Hero, enemyHero);
                            if (relativeSpeed > 0)
                                enemyAliveTime += Mathf.Ceil(enemyHero.Life / Hero.Damage) * ((1 / Hero.AttackSpeed) / relativeSpeed);
                        }
                    }
                }
                float advantageRatio = heroAliveTime / enemyAliveTime;
                if (advantageRatio > bestAdvantageRatio) {
                    bestAdvantageRatio = advantageRatio;
                    target = enemyHero;
                }
            }
        }
        if (bestAdvantageRatio > requiredAdvantageRatio) {
            Hero.AttackTarget = target;
            yield return NodeResult.Success;
        } else
            yield return NodeResult.Failure;
    }

    public IEnumerator<NodeResult> Engage() {
        return Engage(Hero, enemyHeroes, allyHeroes, enemyTowers, e => true);
    }

    public IEnumerator<NodeResult> EngageHard()
    {
        return ActionsWithHeroes.Engage(Hero, enemyHeroes, allyHeroes,
            Enumerable.Empty<IAttackerControllable>(),
            enemyFilter: e => true,
            takeValueAsTargetIntoAccount: true,
            requiredAdvantageRatio: .9f);
    }

    static public IEnumerator<NodeResult> Engage<T>(
            IHeroControllable Hero,
            List<Hero> enemyHeroes,
            List<Hero> allyHeroes,
            IEnumerable<T> towurCovers,
            Func<Entity, bool> enemyFilter,
            bool takeValueAsTargetIntoAccount = false,
            float requiredAdvantageRatio = 1.0f) where T : IAttackerControllable 
    {
        Hero bestTarget;
        do {
            bestTarget = null;
            float bestAdvantageRatio = 0;
            float enemyTeamValue = 0;
            foreach (var eh in enemyHeroes.Where(eh => eh.IsAlive && eh.IsVisible && eh.HasInVisibilityRange(Hero)))
                enemyTeamValue += HeroValue(eh);

            foreach (var enemyHero in enemyHeroes.Where(eh => eh.IsTargetableBy(Hero) && Hero.HasInVisibilityRange(eh) && enemyFilter(eh)))
            {
                if (enemyHero.IsCoveredBy(towurCovers, Hero, safetyMargin)) continue; //never attack hero under tower == cheap
                float allyTeamValue = 0;
                foreach (var ah in allyHeroes.Where(ah => ah.IsAlive && ah.HasInVisibilityRange(enemyHero)))
                {
                    allyTeamValue += HeroValue(ah);
                }
                float advantageRatio = allyTeamValue/enemyTeamValue;

                if (advantageRatio > bestAdvantageRatio)
                {
                    bestAdvantageRatio = advantageRatio;
                    bestTarget = enemyHero;
                }

                if (takeValueAsTargetIntoAccount && Mathf.Approximately(bestAdvantageRatio, advantageRatio)
                    && HeroValueAsTarget(enemyHero) > HeroValueAsTarget(bestTarget))
                {
                    bestTarget = enemyHero;
                }
            }

            if (bestAdvantageRatio > requiredAdvantageRatio)
            {
                Hero.AttackTarget = bestTarget;
            }
            else
                yield return NodeResult.Failure;

            yield return NodeResult.Continue;
        } while (bestTarget);

        yield return NodeResult.Failure;
    }

    public IEnumerator<NodeResult> StayAwayFromEnemyHeroes() {
        float singleRunDistance = 2;

        var closeEnemyHeroes = enemyHeroes.Where(enemyHero => enemyHero.HasInAttackRange(Hero, safetyMargin));
        while (!closeEnemyHeroes.IsEmptyOrNull()) {
            var center = closeEnemyHeroes.GetCenter();
            Hero.MoveTargetPosition = Hero.Position + (Hero.Position - center).normalized * singleRunDistance;
            yield return NodeResult.Continue;
        }
        yield return NodeResult.Failure; // -- no enemyHeroes to avoid anymore
    }

    public bool IsInAttackRangeOfHero() {
        foreach (var h in enemyHeroes)
            if (h.IsTargetableBy(Hero) && h.HasInAttackRange(Hero, safetyMargin)) return true;
        return false;
    }

    public IEnumerator<NodeResult> SpamSkillsAtTargetedHero() {
        if (Hero.AttackTarget != null && Hero.AttackTarget.EntityType == EType.Hero) {
            var enumerator = SpamSkills();
            while (enumerator.MoveNext())
                yield return NodeResult.Failure; //always fail to not block priority selectors (do in meantime)
        } else yield return NodeResult.Failure;
    }

    public IEnumerator<NodeResult> SpamSkills() {
        if (CanCast() == false) yield return NodeResult.Failure;

        for (int i = 0; i < 3; i++) {
            if (Cast(i)) yield return NodeResult.Success;
        }
        yield return NodeResult.Failure;
    }

    protected bool Cast(int skillID)
    {
        Skill skill = Hero.GetSkill(skillID);
        if (skill == null) { Debug.LogWarning("[BotAI] Problem with Skill (not initialized skill?)", Hero.LocalEntity); return false; }
        if (HasManaFor(skill) == false) return false;
        if (skill.IsActivable) return Cast(skill);
        return false;
    }

    public bool IsAllowedToRun() {
        const float requiredAdvantageRatio = 1.0f;
        float enemyHeroesValue = 0;
        float allyHeroesValue = 0;
        var enemyHeroesCounted = Hero.AttackTarget != null ?
            enemyHeroes.Where(eh => eh.IsTargetableBy(Hero) && Hero.AttackTarget.IsCoveredBy(eh, Hero))
            : enemyHeroes.Where(eh => eh.IsTargetableBy(Hero) && Hero.HasInVisibilityRange(eh));
        var allyHeroesCounted = allyHeroes.Where(ah => ah.IsAlive && ah.Id != Hero.Id && Hero.HasInVisibilityRange(ah));

        foreach (var eh in enemyHeroesCounted) { enemyHeroesValue += HeroValue(eh); }
        foreach (var ah in allyHeroesCounted) { allyHeroesValue += HeroValue(ah); }

        float myValue = HeroValue(Hero);
        float requiredValue = enemyHeroesValue * requiredAdvantageRatio;
        bool alliesAloneAreStrongerThanEnemy = allyHeroesValue >= requiredValue;
        bool alliesWithMeAreWeakerThanEnemy = allyHeroesValue + myValue < requiredValue;
        return alliesAloneAreStrongerThanEnemy || alliesWithMeAreWeakerThanEnemy;
    }

    public IEnumerator<NodeResult> LastHitHero() {
        const float maxNumOfHits = 2f;
        var target = enemyHeroes.FirstOrDefault(eh => eh.IsTargetableBy(Hero) && Hero.HasInAttackRange(eh)
            && eh.Life < eh.CalculateHit(Hero.Damage, Hero, null) * maxNumOfHits);
        if (target != null) {
            while (target.IsTargetableBy(Hero) && Hero.HasInAttackRange(target)
                && target.Life < target.CalculateHit(Hero.Damage, Hero, null) * maxNumOfHits) {
                Hero.AttackTarget = target;
                yield return NodeResult.Continue;
            }
        } else {
            yield return NodeResult.Failure;
        }            
    }

    protected bool HasEnemyHeroesInRangeWthoutBellys(int minNumOfHeroes, float range, float predictionTime = 0)
    {
        int numOfEnemiesInRange = enemyHeroes.Where(eh => eh.IsTargetableBy(Hero)
            && Hero.HasInRange((predictionTime == 0 ? eh.Position : eh.PredictPosition(predictionTime)), range)).Take(minNumOfHeroes).Count();
        return numOfEnemiesInRange >= minNumOfHeroes;
    }

    public bool HasAtLeastTwoEnemyHeroesInVisibilityRange()
    {
        return HasEnemyHeroesInRangeWthoutBellys(2, Hero.VisibilityRange);
    }

    public bool HasEnemyHeroInVisibilityRange()
    {
        return enemyHeroes.Any(eh => eh.IsTargetableBy(Hero) && Hero.HasInVisibilityRange(eh));
    }

    public IEnumerator<NodeResult> AttackClosestEnemyHero()
    {
        while (true)
        {
            IHeroControllable closestEnemyHero = enemyHeroes.Where(eH => eH.IsTargetableBy(Hero)).ClosestTo(Hero);
            if (closestEnemyHero == null) { break; }
            Hero.AttackTarget = closestEnemyHero;
            yield return NodeResult.Continue;
        }
        yield return NodeResult.Failure;
    }

    public bool AmIGroupedWithAllies()
    {
        return allyHeroes.TakeWhile(ah => ah.IsAlive && Hero.HasInVisibilityRange(ah)).Count() >= allyHeroes.Count;
    }

    public bool AreEnemiesGrouped()
    {
        var properEnemies = enemyHeroes.Where(eh => eh.IsTargetableBy(Hero));
        var firstEnemy = properEnemies.FirstOrDefault();
        if (firstEnemy == null) { return false; }
        return properEnemies.Skip(1).TakeWhile(eh => firstEnemy.HasInVisibilityRange(eh)).Count() >= enemyHeroes.Count - 1;
    }

    #region Tools
    private float TimeToGetInRange(IMoverControllable attacker, IMoverControllable victim, float range) {
        float relativeSpeed = RelativeSpeed(attacker, victim);
        float distanceToVictim = (victim.Position - attacker.Position).magnitude;
        float distanceToGo = distanceToVictim - range - attacker.Radius - victim.Radius;
        float time = distanceToGo / relativeSpeed;
        return time;
    }

    private static float RelativeSpeed(IMoverControllable attacker, IMoverControllable victim) {
        float victimAwaySpeed = (victim.State == EntityState.Run)
            ? Quaternion.Dot(Quaternion.LookRotation(victim.Position - attacker.Position), victim.Rotation) * victim.MoveSpeed
            : 0;
        float relativeSpeed = attacker.MoveSpeed - victimAwaySpeed;
        return relativeSpeed;
    }

    public static float HeroValue_DPS_Coeff = .3f;
    public static float HeroValue_HP_Coeff = 1f;
    public static float HeroValue_range_Coeff = .15f;

    static public float HeroValue(IHeroControllable h) {
        float DPS_Coeff = HeroValue_DPS_Coeff;  //1f;
        float HP_Coeff = HeroValue_HP_Coeff;   //4f;
        float rangeCoeff = HeroValue_range_Coeff; //1f;

        float dps = h.AttackSpeed * h.Damage;
        float hp = h.Life;
        float range = h.AttackRange;

        return Mathf.Pow(dps, DPS_Coeff) * Mathf.Pow(hp, HP_Coeff) * Mathf.Pow(range, rangeCoeff);
    }

    public static float HeroValueAsTarget_DPS_Coeff = 0.5f;
    public static float HeroValueAsTarget_HP_Coeff = -1f;
    public static float HeroValueAsTarget_range_Coeff = 0f;
    static public float HeroValueAsTarget(IHeroControllable h)
    {
        if (h == null) { return 0; }

        float DPS_Coeff = HeroValueAsTarget_DPS_Coeff;// 1f;
        float HP_Coeff = HeroValueAsTarget_HP_Coeff;// -4f;
        float rangeCoeff = HeroValueAsTarget_range_Coeff;// 1f;

        float dps = h.AttackSpeed * h.Damage;
        float hp = h.Life;
        float range = h.AttackRange;

        return Mathf.Pow(dps, DPS_Coeff) * Mathf.Pow(hp, HP_Coeff) * Mathf.Pow(range, rangeCoeff);
    }

    protected bool Cast(Skill skill) {
        try {
            switch (skill.TargetingType) {
                case Skill.TargetType.Line:
                    if (Hero.AttackTarget == null) { Debug.LogError("[BotAI] No attack target to cast skill of type " + skill.Type, Hero.LocalEntity); return false; }
                    if (Hero.HasInRange(Hero.AttackTarget, skill.Range) == false) { return false; }
                    Hero.UseSkill(skill, new SkillParams() { startPosition = Hero.Position, endPosition = Hero.AttackTarget.Position });
                    return true;

                case Skill.TargetType.Entity:
                    if (Hero.AttackTarget == null) { Debug.LogError("[BotAI] No attack target to cast skill of type " + skill.Type, Hero.LocalEntity); return false; }
                    if (Hero.HasInRange(Hero.AttackTarget, skill.Range) == false) { return false; }
                    Hero.UseSkill(skill, new SkillParams() { targetEntity = Hero.AttackTarget });
                    return true;

                case Skill.TargetType.Pos:
                    if (Hero.AttackTarget == null) { Debug.LogError("[BotAI] No attack target to cast skill of type " + skill.Type, Hero.LocalEntity); return false; }
                    if (Hero.HasInRange(Hero.AttackTarget, skill.Range) == false) { return false; }
                    Hero.UseSkill(skill, new SkillParams() { targetPosition = Hero.AttackTarget.Position });
                    return true;

                case Skill.TargetType.None:
                    Hero.UseSkill(skill);
                    return true;

                default:
                    //Debug.LogWarning("[BotAI] Can't cast skill of type " + skill.Type + " (targeting: " + skill.TargetingType + ") yet.", Hero.LocalEntity);
                    return false;
            }
        } catch (Exception e) {
            Debug.LogError("Error in skill effect:\n" + e.Message + e.StackTrace, Hero.LocalEntity);
            return false;
        }
    }

    protected IEnumerator<NodeResult> CastLineShotAtTarget(int skillID)
    {
        var target = Hero.AttackTarget;
        return CastLineShotAt(skillID, target);
    }

    protected IEnumerator<NodeResult> CastLineShotAt(int skillID, IEntityControllable target)
    {
        if (target == null) { yield return NodeResult.Failure; }

        var skill = GetReadySkill(skillID);
        if (skill == null) { yield return NodeResult.Failure; }

        var distanceToTarget = Vector3.Distance(Hero.Position, target.Position);
        var bulletSpeed = skill.Bullet.speed;
        float bulletTravelTime = (distanceToTarget != 0f && bulletSpeed != Mathf.Infinity) ? distanceToTarget/skill.Bullet.speed : 0;

        var targetPosition = target.PredictPosition(skill.CastTime + bulletTravelTime);

        if (target.IsTargetableBy(Hero) && Hero.HasInRangeWithoutBellys(targetPosition, skill.Range))
        {
            Hero.UseSkill(skill, new SkillParams {startPosition = Hero.Position, endPosition = LineShotEndPosition(skill, targetPosition)});
            yield return NodeResult.Success;
        }
        yield return NodeResult.Failure;
    }

    protected bool CanHitAttackTargetWithAura(int skillId)
    {
        var target = Hero.AttackTarget;
        if (target == null || target.IsTargetableBy(Hero) == false) { return false; }
        var sign = Hero.GetSkill(skillId);
        if (sign == null) { return false; }

        return Hero.HasInRangeWithoutBellys(Hero.AttackTarget.PredictPosition(sign.CastTime), sign.ExplosionRange);
    }

    #endregion

    #region Misc

    private List<Tower> GetTowersIfAvailable(Team team) {
        List<Tower> towers=commonCache.Towers[team];
        if (towers!=null)
            return towers;
        else return emptyTowersList;
    }

    private List<Tower> emptyTowersList = new List<Tower>(0);

    #endregion

    public override bool IsAIReady() {
        return _IsAIReady();
    }
}

