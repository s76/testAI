﻿using Assets._AI;
using Assets._AI.Actions.Behaviours;
using Assets._Controllable.BasicEntity;
using Assets._Effects.Skills.ScriptableSkills;
using React;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using UnityEngine;

public abstract class BotBehaviour : HeroBehaviour
{
    protected BotsCache commonCache;
    public override void Initialize()
    {
        base.Initialize();
        commonCache = BotManager.instance.Cache;
    }

    protected IEnumerator<NodeResult> GoTo(Func<Entity> entityGetter, float closeEnoughDistance = 1.0f, bool refreshTarget = false, Func<Entity, Vector3> positionModifier = null)
    {
        if (positionModifier == null) positionModifier = e => e.Position;
        var gotoEntity = entityGetter();
        if (gotoEntity == null) { yield return NodeResult.Failure; yield break; }

        var gotoPosition = positionModifier(gotoEntity);
        while (gotoEntity != null && Hero.HasInRange(gotoPosition, closeEnoughDistance) == false)
        {
            Hero.MoveTargetPosition = gotoPosition;
            yield return NodeResult.Continue;

            if (refreshTarget)
            {
                var newGotoEntity = entityGetter();
                if (newGotoEntity != gotoEntity)
                {
                    gotoEntity = newGotoEntity;
                    if (gotoEntity != null) { gotoPosition = positionModifier(gotoEntity); }
                }
            }
        }

        yield return gotoEntity ? NodeResult.Success : NodeResult.Failure;
    }

    protected IEnumerator<NodeResult> GoTo(Func<Vector3> positionGetter, float closeEnoughDistance = 1.0f, bool refreshTarget = false)
    {
        var gotoPosition = positionGetter();
        while (gotoPosition.IsNaN() == false && Hero.HasInRange(gotoPosition, closeEnoughDistance) == false)
        {
            Hero.MoveTargetPosition = gotoPosition;
            yield return NodeResult.Continue;

            if (refreshTarget) { gotoPosition = positionGetter(); }
        }

        yield return gotoPosition.IsNaN() ? NodeResult.Failure : NodeResult.Success;
    }

    protected static Vector3 PositionModifierRandomOffset(Entity e, float maxOffset, float minOffset = 0)
    {
        var pos = e.Position.AddRandomOffsetWithoutLinecast(maxOffset, minOffset);
        return HeightMap.CalcPositionWithHeight(AstarPath.active.GetNearest(pos).clampedPosition);
    }

    public bool IsEasyBot()
    {
        return DifficultyLvl == BotDifficulty.DiffLvl.Easy;
    }

    public bool IsMediumBot()
    {
        return DifficultyLvl == BotDifficulty.DiffLvl.Medium;
    }

    public bool IsHardBot()
    {
        return DifficultyLvl == BotDifficulty.DiffLvl.Hard;
    }

    public IEnumerator<NodeResult> ShortDerp()
    {
        var randomEntity = EntityManager.instance.GetAllEntities().Where(e => e.IsAlive).GetRandom();
        if (randomEntity == null) { yield return NodeResult.Failure; }
        Hero.MoveTargetPosition = randomEntity.Position;
        yield return NodeResult.Success;
    }

    protected BotDifficulty.DiffLvl DifficultyLvl
    {
        get
        {
            var heroController = Hero.Controller as HeroMasterController;
            if (heroController)
            {
                return heroController.heroAI.Difficulty.DifficultyLevel;
            }
            else { throw new InvalidOperationException(); }
        }
    }

    protected Skill GetReadySkill(int skillID)
    {
        var skill = Skill.GetSkillForHero(skillID, Hero);
        if (skill == null || CanCast(skill) == false) return null;
        return skill;
    }

    protected bool CanCast(Skill cleaveSkill)
    {
        return (CanCast() && HasManaFor(cleaveSkill) && cleaveSkill.IsActivable);
    }

    protected bool HasManaFor(Skill skill)
    {
        return Hero.Mana >= skill.ManaCost;
    }

    protected bool CanCast()
    {
        return !Hero.IsStunned && !Hero.IsSilenced && Hero.IsAlive;
    }

    protected Vector3 LineShotEndPosition(Skill shieldStrike, IEntityControllable target)
    {
        return LineShotEndPosition(shieldStrike, target.Position);
    }

    protected Vector3 LineShotEndPosition(Skill skill, Vector3 targetPos)
    {
        var heroPos = Hero.Position;
        var heroToTargetU = (targetPos - heroPos).normalized;
        if (heroToTargetU == Vector3.zero) { heroToTargetU = HeroActions.RandomUnitVector2D().ToVec3xz(); }

        var endPos = heroPos + heroToTargetU * skill.Range;
        return endPos;
    }

    protected void CacheSkillDamage(int skillID, System.Action<float> dmgCacher)
    {
        StartCoroutine(CacheSkillDamageCoroutine(skillID, dmgCacher));
    }

    private struct SkillAndDelegate
    {
        public Skill skill;
        public OnSkillLevelChanged del;
    }

    List<SkillAndDelegate> delegatesToRemoveFromSkills = new List<SkillAndDelegate>();

    private IEnumerator CacheSkillDamageCoroutine(int skillId, System.Action<float> dmgCacher)
    {
        Skill skill = null;
        while ((skill = Hero.GetSkill(skillId)) == null) { yield return null; }
        OnSkillLevelChanged lambda = (before, after, _skill) => 
        { 
            var dmgSkill = _skill.ScriptableSkill as IMakesDamage;
            if (dmgSkill != null) { dmgCacher(dmgSkill.Damage); } 
            else { Debug.LogError("Sciptable skill " + _skill.SkillName + " does not implement IMakesDamage.", this); }
        };
        delegatesToRemoveFromSkills.Add(new SkillAndDelegate { skill = skill, del = lambda });

        skill.onSkillLevelChanged += lambda;
    }

    protected virtual void OnDestroy()
    {
        foreach (var sad in delegatesToRemoveFromSkills)
        {
            if (sad.skill != null) { sad.skill.onSkillLevelChanged -= sad.del; } 
        }
    }

    protected Vector3 ClampTargetToMaxRange(Skill timeBreach, Vector3 targetPosition)
    {
        if (Hero.HasInRange(targetPosition, timeBreach.Range)) { return targetPosition; }
        else
        {
            return Hero.Position + Vector3.ClampMagnitude((targetPosition - Hero.Position), timeBreach.Range);
        }
    }

    protected IEnumerator<NodeResult> EnableTogglebleSkill(int skillID, Func<bool> isSkillEnabledFunc = null, string warningMsg = "[AI] Already enabled")
    {
        return ToggleSkill(skillID, isSkillEnabledFunc, warningMsg, true);
    }

    protected IEnumerator<NodeResult> DisableTogglebleSkill(int skillID, Func<bool> isSkillEnabledFunc = null, string warningMsg = "[AI] Already enabled")
    {
        return ToggleSkill(skillID, isSkillEnabledFunc, warningMsg, false);
    }

    protected IEnumerator<NodeResult> ToggleSkill(int skillID, Func<bool> isSkillEnabledFunc, string warningMsg, bool? enable)
    {
        if (enable != null 
            && isSkillEnabledFunc != null 
            && isSkillEnabledFunc() == enable) 
        {
            Debug.LogWarning(warningMsg, this); yield return NodeResult.Failure; 
        }

        var unrequiredLove = GetReadySkill(skillID);
        if (unrequiredLove == null) { yield return NodeResult.Failure; }

        Hero.UseSkill(unrequiredLove);
        yield return NodeResult.Success;
    }

    protected IEnumerator<NodeResult> CastAuraSkill(int skillId)
    {
        var skill = GetReadySkill(skillId);
        if (skill == null) { yield return NodeResult.Failure; }

        Hero.UseSkill(skill);
        yield return NodeResult.Success;
    }

	protected IEnumerator<NodeResult> Fail()
	{
		yield return NodeResult.Failure;
	}
}

