﻿using React;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;


class SuccubusActionsWithHeroesAndFountain : ActionsWithHeroesAndFountain
{
    const int SeductressKissID = 0; //AreaTarget
    const int UnrequiredLoveID = 1; //Aura - ExplosionRange
    const int BetweenPleasureAndPaintID = 2;

    public IEnumerator<NodeResult> CastSeductressKissTowardsFountain()
    {
        return CastAreaTargetTowardsFountain(SeductressKissID);
    }
}

