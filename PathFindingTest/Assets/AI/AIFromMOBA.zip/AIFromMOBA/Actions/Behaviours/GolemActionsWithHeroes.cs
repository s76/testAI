﻿using React;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;


class GolemActionsWithHeroes : ActionsWithHeroes
{
    const int SummonGargoyleID = 0;
    const int StoneSpireID = 1;
    const int ContraventionID = 2;


    public IEnumerator<NodeResult> CastSummonGargoyle()
    {
        if (Hero.HasAttackTarget && CanCast() && Cast(SummonGargoyleID)) { yield return NodeResult.Success; }
        else { yield return NodeResult.Failure; }
    }

    public IEnumerator<NodeResult> CastStoneSpire()
    {
        if (Hero.HasAttackTarget && CanCast() && Cast(StoneSpireID)) { yield return NodeResult.Success; }
        else { yield return NodeResult.Failure; }
    }

    const float fractionOfLifeToUseDefensively = 0.3f;
    public IEnumerator<NodeResult> CastContravention()
    {
        Skill contravention = Hero.GetSkill(ContraventionID);
        if (contravention == null) { yield return NodeResult.Failure; }

        if (CanCast(contravention) &&
            (
                Hero.Life < Hero.MaxLife * fractionOfLifeToUseDefensively && enemyHeroes.Any(eH => eH.IsTargetableBy(Hero) && Hero.HasInRange(eH, contravention.ExplosionRange))
                || enemyHeroes.Where(eH => eH.IsTargetableBy(Hero) && Hero.HasInRange(eH, contravention.ExplosionRange)).Count() >= 2
            )
            && Cast(contravention))

        {
            yield return NodeResult.Success;
        }
        else { yield return NodeResult.Failure; }
    }
}

