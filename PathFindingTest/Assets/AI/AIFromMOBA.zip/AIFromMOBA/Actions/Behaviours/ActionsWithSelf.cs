﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Assets._AI;
using Assets._Controllable.BasicEntity;
using React;
using UnityEngine;


internal class ActionsWithSelf : BotBehaviour
{
    protected override bool AreRequirementsMet()
    {
        return Hero != null;
    }

    public override bool IsAIReady()
    {
        return _IsAIReady();
    }

    public bool IsAlive()
    {
        return Hero.IsAlive;
    }

    public IEnumerator<NodeResult> WanderAround()
    {
        float wanderingDistance = 2;
        float stayForSomeTime = UnityEngine.Random.Range(0.3f, 6f);

        while (Hero.State != EntityState.Stay) yield return NodeResult.Continue;
        while (Time.time < Hero.LastStateChangeTime + stayForSomeTime) yield return NodeResult.Continue;

        Hero.MoveTargetPosition = Hero.Position.AddRandomOffset(wanderingDistance);

        yield return NodeResult.Success;
    }

    public IEnumerator<NodeResult> DerpContinous()
    {
        var target = EntityManager.instance.GetAllEntities().Where(e => IsAlive()).GetRandom();
        if (target == null) { yield return NodeResult.Failure; }
        while (Hero.HasInRange(target, 0) == false)
        {
            Hero.MoveTargetPosition = target.Position;
            yield return NodeResult.Continue;
        }
        yield return NodeResult.Success;
    }

    private const float minimumHealthPercent = 0.5f;
    public bool IsHurt()
    {
        return Hero.Life / Hero.MaxLife < minimumHealthPercent;
    }
	
    private const float minimumManaPercent = 0.3f;
    public bool IsExhausted()
    {
        return IsHurt() || Hero.Mana / Hero.MaxMana < minimumManaPercent;
    }
}
