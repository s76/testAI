﻿using Assets._Controller.Dispatcher;
using Assets._AI;
using React;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;


class SaskiaActionsWithHeroesAndFountain : ActionsWithHeroesAndFountain
{
    const int ShieldStrikeID = 0;

    public IEnumerator<NodeResult> CastShieldStrikeTowardsFountain()
    {
        return CastLineShotTowardsFountain(ShieldStrikeID);
    }
}

