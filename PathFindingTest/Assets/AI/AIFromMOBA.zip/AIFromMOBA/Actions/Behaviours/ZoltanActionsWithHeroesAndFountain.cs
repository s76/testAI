﻿using React;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;


class ZoltanActionsWithHeroesAndFountain : ActionsWithHeroesAndFountain
{
    const int BullRushID = 0;           //LineShot (Barge and Charge)
    const int WhirlingDwarvishID = 1;   //Aura (Spinning Strike)
    const int WorthItID = 2;            //LineShot (Worth It)

    public IEnumerator<NodeResult> CastBullRushTowordsFountain()
    {
        return CastLineShotTowardsFountain(BullRushID);
    }

    public IEnumerator<NodeResult> CastWorthItTowardsFountain()
    {
        return CastLineShotTowardsFountain(WorthItID);
    }
}


