﻿using React;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Assets._Controllable.BasicEntity;
using Assets._Controller.Dispatcher;


class IorwethActionsWithHeroes : ActionsWithHeroes
{
    const int DrivenByHatredID = 0;
    const int SquirrelsMarkID = 1;
    const int VendettaID = 2;
    private float vendettaDmg;

    public override void Initialize()
    {
        base.Initialize();
        CacheSkillDamage(VendettaID, dmg => vendettaDmg = dmg);
    }

    public IEnumerator<NodeResult> CastDrivenByHatredAtTarget()
    {
        return CastLineShotAtTarget(DrivenByHatredID);
    }

    public IEnumerator<NodeResult> CastSquirrelsMarkAtTarget()
    {
        var target = Hero.AttackTarget;
        if (target == null) { yield return NodeResult.Failure; }

        var squirrelsMark = GetReadySkill(SquirrelsMarkID);
        if (squirrelsMark == null) { yield return NodeResult.Failure; }

        if (target.IsTargetableBy(Hero) && Hero.HasInRangeWithoutBellys(target, squirrelsMark.Range + squirrelsMark.ExplosionRange))
        {
            Hero.UseSkill(squirrelsMark, new SkillParams() { targetPosition = ClampTargetToMaxRange(squirrelsMark, target.Position) });
            yield return NodeResult.Success;
        }
        yield return NodeResult.Failure;
    }

    public IEnumerator<NodeResult> CastVendettaForKill()
    {
        var vendetta = GetReadySkill(VendettaID);
        if (vendetta == null) { yield return NodeResult.Failure; }

        var target = enemyHeroes.FirstOrDefault(eh => eh.IsTargetableBy(Hero) 
            && Hero.HasInRangeWithoutBellys(eh, vendetta.Range + vendetta.ExplosionRange)
            && eh.CalculateHit(vendettaDmg, Hero, vendetta) > eh.Life);
        if (target != null)
        {
            Hero.UseSkill(vendetta, new SkillParams() { targetPosition = ClampTargetToMaxRange(vendetta, target.Position) });
            yield return NodeResult.Success;
        }
        yield return NodeResult.Failure;
    }

    public IEnumerator<NodeResult> CastSquirrelsMarkAtEnemy()
    {
        var squirrelsMark = GetReadySkill(SquirrelsMarkID);
        if (squirrelsMark == null) { yield return NodeResult.Failure; }

        var target = enemyHeroes.FirstOrDefault(eh => eh.IsTargetableBy(Hero) && Hero.HasInRangeWithoutBellys(eh, squirrelsMark.Range + squirrelsMark.ExplosionRange));
        if (target != null)
        {
            Hero.UseSkill(squirrelsMark, new SkillParams() { targetPosition = ClampTargetToMaxRange(squirrelsMark, target.Position) });
            yield return NodeResult.Success;
        }
        yield return NodeResult.Failure;
    }
}

