using ScriptableSkills;
using UnityEngine;
using Assets._Controllable.BasicEntity;
using Assets._AI;
using System.Collections;
using React;
using System.Collections.Generic;
using System;
using System.Linq;
using Assets._Controller.Dispatcher;

class FilippaActionsWithHeroes : ActionsWithHeroes
{
    const int HeartOfTheStormID = 0; //AreaTarget
    const int ChainLightningID = 1; //FrontShot
    const int DomeOfStormsID = 2; //Aura

    public IEnumerator<NodeResult> CastHeartOfTheStorm()
    {
        if (CanCast() && Cast(HeartOfTheStormID)) { yield return NodeResult.Success; }
        else { yield return NodeResult.Failure; }
    }

    public IEnumerator<NodeResult> CastHeartOfTheStormOnTarget()
    {
        var target = Hero.AttackTarget;
        if (target == null) { yield return NodeResult.Failure; }

        var heartOfTheStorm = GetReadySkill(HeartOfTheStormID);
        if (heartOfTheStorm == null) { yield return NodeResult.Failure; }

        var predictPos = target.PredictPosition(EyeOfTheStorm.HitDelayTime);

        if (Hero.HasInRange(predictPos, heartOfTheStorm.Range + EyeOfTheStorm.StunRadius))
        {
            Hero.UseSkill(heartOfTheStorm, new SkillParams() { targetPosition = ClampTargetToMaxRange(heartOfTheStorm, predictPos) });
            yield return NodeResult.Success;
        }
        else
        {
            yield return NodeResult.Failure;
        }
    }

    public IEnumerator<NodeResult> CastChainLightningAtTarget()
    {
        var chainLightning = GetReadySkill(ChainLightningID);
        if (chainLightning == null) { yield return NodeResult.Failure; }

        var target = enemyHeroes.FirstOrDefault(eH => eH.IsTargetableBy(Hero) 
                    && Hero.HasInRangeWithoutBellys(eH, chainLightning.Range));

        if (target != null) {
            Hero.UseSkill(chainLightning, new SkillParams() { startPosition = Hero.Position, endPosition = LineShotEndPosition(chainLightning, target.Position) });
            var time = Time.time;
            const float upTime = 5;
            while (Time.time < time + upTime && enemyHeroes.Any(
                eH => eH.IsTargetableBy(Hero) 
                    && Hero.HasInRangeWithoutBellys(eH, chainLightning.Range)
                    && IsWithin45Angle(eH)))
            {
                yield return NodeResult.Continue;
            }
            yield return NodeResult.Success;
        }
        else { yield return NodeResult.Failure; }
    }

    private bool IsWithin45Angle(Hero eH)
    {
        const float acos45 = 0.707f;
        Vector2 forward = Hero.Trans.forward.ToVec2XZ();
        Vector2 meToOtherU = (eH.Position - Hero.Position).ToVec2XZ().normalized;
        return Vector2.Dot(forward, meToOtherU) > acos45;     
    }

    public IEnumerator<NodeResult> CastDomeOfStorms()
    {
        if (CanCast() && Cast(DomeOfStormsID)) { yield return NodeResult.Success; }
        else { yield return NodeResult.Failure; }
    }

    const float maxSpeedPercent = 0.5f;
    public IEnumerator<NodeResult> CastDomeOfStormsAtSlowedEnemyAndChaseHim()
    {
        var domeOfStorms = GetReadySkill(DomeOfStormsID);
        if (domeOfStorms == null) { yield return NodeResult.Failure; }

        var slowedEnemy = enemyHeroes.FirstOrDefault(
            eh => eh.IsTargetableBy(Hero) 
                && Hero.HasInVisibilityRange(eh) //Hero.HasInRangeWithoutBellys(eh, domeOfStorms.Range)
                && eh.MoveSpeed <= eh.MoveSpeedBaseValue * maxSpeedPercent);

        if (slowedEnemy != null)
        {
            var castTime = Time.time;
            Hero.UseSkill(domeOfStorms);
            yield return NodeResult.Continue;

            while (Time.time < castTime + domeOfStorms.WorkTime)
            {
                Hero.AttackTarget = slowedEnemy;
                yield return NodeResult.Continue;
            }
            yield return NodeResult.Success;
        }
        yield return NodeResult.Failure;
    }

    public IEnumerator<NodeResult> CastDomeOfStormsOnEnemiesInOwlRange()
    {
        var domeOfStorms = GetReadySkill(DomeOfStormsID);
        if (domeOfStorms == null) { yield return NodeResult.Failure; }

        bool shouldCast = enemyHeroes.Where(eh => eh.IsTargetableBy(Hero) && Hero.HasInRangeWithoutBellys(eh, domeOfStorms.ExplosionRange)).Count() > MinTargetsNumber;
        if (shouldCast)
        {
            Hero.UseSkill(domeOfStorms);
            yield return NodeResult.Success;
        }
        yield return NodeResult.Failure;
    }

    public IEnumerator<NodeResult> ChaseBiggestGroupWithOwl()
    {
        var owl = Hero.GetSkill(DomeOfStormsID);
		if (owl && NetworkManager.instance.ServerTimeInSeconds < owl.ActivationTime + owl.WorkTime)
        {
			while (NetworkManager.instance.ServerTimeInSeconds < owl.ActivationTime + owl.WorkTime) 
            {
                var proposedPos = GetLargestGroupOfHeroesCircableByOwl(owl).GetCenter();

                if (proposedPos.IsNaN()) { yield return NodeResult.Failure; }
                yield return NodeResult.Continue;
            }
            yield return NodeResult.Success;
        }
        yield return NodeResult.Failure;
    }

    const int MinTargetsNumber = 3;
    public IEnumerator<NodeResult> CastDomeOfStormsOnGroupOfThreeInVisibilityRange()
    {
        var domeOfStorms = GetReadySkill(DomeOfStormsID);
        if (domeOfStorms == null) { yield return NodeResult.Failure; }

        var targets = GetLargestGroupOfHeroesCircableByOwl(domeOfStorms, 3);

        if (targets != null && targets.Count() > 0)
        {
            Hero.UseSkill(domeOfStorms);
            yield return NodeResult.Success;
        }
        yield return NodeResult.Failure;
    }

    public bool IsDomeOfStormsReady()
    {
        return GetReadySkill(DomeOfStormsID) != null;
    }

    public bool DetectGroupOfAtLeastThreeCircableByOwl()
    {
        var owl = GetOwl();
        if (owl == null) { return false; }
        return GetLargestGroupOfHeroesCircableByOwl(owl, 3).Any();
    }

    public bool DetectGroupOfAtLeastTwoCircableByOwl()
    {
        var owl = GetOwl();
        if (owl == null) { return false; }
        return GetLargestGroupOfHeroesCircableByOwl(owl, 2).Any();
    }


    public IEnumerator<NodeResult> ChaseGroupOfAtLeastThree()
    {
        var owl = GetOwl();
        if (owl == null) { return (new List<NodeResult>() { NodeResult.Failure }).GetEnumerator(); }

        return GoTo(() => GetPositionForOwlToCatchAsManyEnemies(owl, 3),
            refreshTarget: true);
    }

    public IEnumerator<NodeResult> ChaseGroupOfAtLeastTwo()
    {
        var owl = GetOwl();
        if (owl == null) { return (new List<NodeResult>() { NodeResult.Failure }).GetEnumerator(); }

        return GoTo(() => GetPositionForOwlToCatchAsManyEnemies(owl, 2),
            refreshTarget: true);
    }

    public IEnumerator<NodeResult> ChaseEnemyWithLowestHPInVisibilityRange()
    {
        return GoTo(
            () => enemyHeroes.Where(eH => eH.IsTargetableBy(Hero) && Hero.HasInVisibilityRange(eH))
                .Aggregate((Hero)null, (curmin, eH) => (curmin == null || eH.Life < curmin.Life) ? eH : curmin),
            refreshTarget: true);
    }

    public bool HasAtLeastThreeEnemiesInOwlRange()
    {
        return EnemiesInOwlRange().Count() >= 3;
    }

    public bool HasAtLeastTwoEnemiesInOwlRange()
    {
        return EnemiesInOwlRange().Count() >= 2;
    }

    public bool IsDomeOfStormsActive()
    {
        var owl = GetOwl();
        if (owl == null) { return false; }
        return NetworkManager.instance.ServerTimeInSeconds < owl.ActivationTime + owl.WorkTime;
    }

    private IEnumerable<Hero> EnemiesInOwlRange()
    {
        var owl = GetOwl();
        if (owl == null) { return Enumerable.Empty<Hero>(); }
        return enemyHeroes.Where(eH => eH.IsTargetableBy(Hero) && Hero.HasInRangeWithoutBellys(eH, owl.ExplosionRange));
    }

    private IEnumerable<Hero> GetLargestGroupOfHeroesCircableByOwl(Skill owl, int minimumNumberOfEnemies = 1)
    {
        return enemyHeroes.Where(eH => eH.IsTargetableBy(Hero) && Hero.HasInVisibilityRange(eH)).ToList()
            .GetAllSubsets().Where(set => set.Count >= minimumNumberOfEnemies)
            .FirstOrDefault(eHeroes => eHeroes.GetCenter().HasInRange(eHeroes, owl.ExplosionRange)) ?? Enumerable.Empty<Hero>();
    }

    private Vector3 GetPositionForOwlToCatchAsManyEnemies(Skill owl, int minimumNumberOfEnemies)
    {
        return GetLargestGroupOfHeroesCircableByOwl(owl, minimumNumberOfEnemies)
            .GetCenter();
    }

    private Skill GetOwl()
    {
        var owl = Hero.GetSkill(DomeOfStormsID);
        if (owl == null) { Debug.LogWarning("[BotAI] Filippa: Where is my Dome of Storm skill, huh?", this); }
        return owl;
    }

}
