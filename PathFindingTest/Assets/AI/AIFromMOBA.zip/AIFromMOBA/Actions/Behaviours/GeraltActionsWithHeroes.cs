using UnityEngine;
using System.Collections;
using React;
using System.Collections.Generic;
using System;
using Assets._Controllable.BasicEntity;
using Assets._AI;

class GeraltActionsWithHeroes : ActionsWithHeroes 
{
    const int WayOfTheSwordID = 0; //SelfSupport, cd 10, casttime 0.2, range 2.5, secondaryrange 3
    const int WayOfTheSorceryID = 1; //SelfSupport, ExplosionRange 3.5
    const int WayOfAlchemyID = 2; //SelfSupport

    float cachedWayOfTheSwordHitRange = 3;
    float cachedWayOfTheSwordFinalHitRange = 3.75f;

    public override void Initialize()
    {
        base.Initialize();
        CacheWayOfTheSwordRanges();
    }

    private void CacheWayOfTheSwordRanges()
    {
        try
        {
            var wayOfTheSword = Hero.GetSkill(WayOfTheSwordID);
            var wayOfTheSwordScriptableSkill = wayOfTheSword.ScriptableSkill as ScriptableSkills.WayOfSword;
            cachedWayOfTheSwordHitRange = wayOfTheSwordScriptableSkill.GetHitRange();
            cachedWayOfTheSwordFinalHitRange = wayOfTheSwordScriptableSkill.GetFinalHitRange();
        }
        catch (Exception e)
        {
            Debug.LogError("[Geralt AI] I don't know the range of my sword. Huh. \n" + e, this);
        }
    }

    protected float GetWayOfSwordHitRange()
    {
        if (Hero.Stance == 2 || Hero.Stance == 5) { return cachedWayOfTheSwordFinalHitRange; }
        else { return cachedWayOfTheSwordHitRange; }
    }

    public bool IsWayOfTheSwordReady()
    {
        return GetReadySkill(WayOfTheSwordID) != null;
    }

    public IEnumerator<NodeResult> CastSwordOnTarget()
    {
        if (Hero.AttackTarget == null) { yield return NodeResult.Failure; }

        var wayOfTheSword = GetReadySkill(WayOfTheSwordID);
        if (wayOfTheSword == null) { yield return NodeResult.Failure; }

        if (Hero.AttackTarget.IsTargetableBy(Hero) == false) { yield return NodeResult.Failure; }

        var targetPosition = Hero.AttackTarget.PredictPosition(ScriptableSkills.WayOfSword.HitDelay);
        float hitRange = GetWayOfSwordHitRange();

        float rangeBoundingCircle = wayOfTheSword.Range + hitRange;
        if (rangeBoundingCircle * rangeBoundingCircle < Hero.Calc2DSqrDist(targetPosition)) { yield return NodeResult.Failure; }

        var dashEndPoint = GetForwardDashEndPoint(wayOfTheSword.Range);
        var dashPoly = new MathSupport.ThickLine(Hero.QuadTreePosition, dashEndPoint.ToVec2XZ(), wayOfTheSword.SecondaryRange);

        if (MathSupport.IsInPoly(dashPoly, targetPosition.ToVec2XZ()) || dashEndPoint.HasInRange(targetPosition, hitRange))
        {
            Hero.UseSkill(wayOfTheSword);
            yield return NodeResult.Success;
        }

        yield return NodeResult.Failure;
    }

    public IEnumerator<NodeResult> CastAlchemy()
    {
        var wayOfAlchemy = GetReadySkill(WayOfAlchemyID);
        if (wayOfAlchemy == null) { yield return NodeResult.Failure; }

        Hero.UseSkill(wayOfAlchemy);
        yield return NodeResult.Success;
    }


    public bool IsSignReady()
    {
        return GetReadySkill(WayOfTheSorceryID) != null;
    }

    public bool CanTrapTwoEnemiesInSign()
    {
        var sign = Hero.GetSkill(WayOfTheSorceryID);
        if (sign == null) { return false; }
        
        return HasEnemyHeroesInRangeWthoutBellys(2, sign.ExplosionRange, sign.CastTime);
    }

    public bool CanTrapAttackTargetInSign()
    {
        return CanHitAttackTargetWithAura(WayOfTheSorceryID);
    }

    public IEnumerator<NodeResult> CastSign()
    {
        return CastAuraSkill(WayOfTheSorceryID);
    }

    protected Vector3 GetForwardDashEndPoint(float dashLength)
    {
        return Hero.Position + Hero.Trans.forward * dashLength;
    }
}
