﻿using Assets._AI;
using Assets._Client;
using Assets._Controllable.BasicEntity;
using Assets._Controllable.HealingTower;
using Assets._Inventory.New;
using React;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Runtime.CompilerServices;
using UnityEngine;
using Debug = UnityEngine.Debug;

class ActionsAtArena : BotBehaviour
{
    private float lastAttackFireTime;
    private float lastTargetChangedTime;
    private IEntityControllable lastTarget;
    private ActionsWithItems actionsWithItems;

    private List<Hero> allyHeroes { get { return commonCache.Heroes[allyTeam]; } }
    private List<Hero> enemyHeroes { get { return commonCache.Heroes[enemyTeam]; } }

    private HealingTower enemyFountain { get { return commonCache.Fountain[enemyTeam]; } }
    private List<ChestVendor> chestVendors { get { return commonCache.Chests[Team.None]; } }

    public override void Initialize()
    {
        base.Initialize();
        CacheAttackInfo();
    }

    private void CacheAttackInfo()
    {
        var localHero = ((Hero)Hero.LocalEntity);
        localHero.onAttackFired += localHero_onAttackFire;
        localHero.onAttackTargetChanged += localHero_onAttackTargetChanged;
        localHero.onDeath += localHero_onDeath;
    }

    void localHero_onDeath(IEntityControllable obj)
    {
        lastTarget = null;
    }

    void localHero_onAttackTargetChanged(IAttackerControllable attacker, IEntityControllable target)
    {
        if (target != null)
        {
            lastTargetChangedTime = Time.time;
            lastTarget = target;
        }
    }

    void localHero_onAttackFire(IAttackerControllable obj)
    {
        lastAttackFireTime = Time.time;
    }

    protected override bool AreRequirementsMet()
    {
        actionsWithItems = actionsWithItems ?? GetComponent<ActionsWithItems>();
        return commonCache.IsCached(enemyTeam, Assets._AI.BotCache.Fountain)
               && commonCache.IsCached(enemyTeam, Assets._AI.BotCache.Heroes)
               && commonCache.IsCached(allyTeam, Assets._AI.BotCache.Heroes)
               && commonCache.IsCached(Team.None, Assets._AI.BotCache.Chests)
               && actionsWithItems != null;
    }

    public IEnumerator<NodeResult> Engage()
    {
        return ActionsWithHeroes.Engage(Hero, enemyHeroes, allyHeroes,
            Enumerable.Empty<IAttackerControllable>(),
            PossibleTargetsFilter,
            takeValueAsTargetIntoAccount: true,
            requiredAdvantageRatio: .5f);
    }

    public IEnumerator<NodeResult> EngageMedium()
    {
        return ActionsWithHeroes.Engage(Hero, enemyHeroes, allyHeroes,
            Enumerable.Empty<IAttackerControllable>(),
            PossibleTargetsFilter,
            takeValueAsTargetIntoAccount: false,
            requiredAdvantageRatio: .9f);
    }

    bool PossibleTargetsFilter(IEntityControllable e)
    {
        const float keepDistanceFromEnemyBase = 5.0f;
        return enemyFountain.HasInRange(e, keepDistanceFromEnemyBase) == false
                && e.IsCoveredBy(enemyFountain.Position, Hero, keepDistanceFromEnemyBase) == false
                && ((IsChasingThisTargetTooLongByChance(e) == false) || IsFacingTowardsMe(e))                                                                                                                                                                                                                                                       ;
    }

    bool IsChasingThisTargetTooLongByChance(IEntityControllable e)
    {
        if (lastTarget != null && lastTarget.Id == e.Id)
        {
            const float averageChaseTime = 4f;
            float aiTickDuration = ((HeroMasterController)Hero.Controller).heroAI.AIReactor.TickDuration;
            if (UnityEngine.Random.value < aiTickDuration / averageChaseTime)
            {
                return true;
            }
        }
        return false;
    }

    bool IsChasingThisTargetTooLong(IEntityControllable e)
    {
        if (lastTarget != null && lastTarget.Id == e.Id)
        {
            const float tooLongChaseTime = 4f;
            if (Time.time > Mathf.Max(lastTargetChangedTime, lastAttackFireTime) + tooLongChaseTime)
            {
                return true;
            }
        }
        return false;
    }

    bool IsFacingTowardsMe(IEntityControllable e)
    {
        Vector3 himToMe = Hero.Position - e.Position;
        bool ans =  Vector3.Dot(himToMe, e.Rotation * Vector3.forward) > 0;
        return ans;
    }

    public IEnumerator<NodeResult> AttackClosestEntityInVisibilityRange()
    {
        IEnumerator<NodeResult> task;
        var enTities = QuadTreeSystem.instance.QuadTree.Query(new QTree.BoundingRect(Hero.Position, Hero.VisibilityRange));
        task = AttackerActions.AttackClosestEnemyInRange(Hero, enTities, Hero.VisibilityRange, EType.Any,
            PossibleTargetsFilter,
            fast: true);
        while (task.MoveNext()) { yield return task.Current; }
        yield return NodeResult.Success;
    }

    public IEnumerator<NodeResult> AttackClosestEnemyHeroOnArena()
    {
        var closest = enemyHeroes.Where(eh => eh.IsTargetableBy(Hero) && PossibleTargetsFilter(eh)).ClosestTo(Hero);
        if (closest != null)
        {
            Hero.AttackTarget = closest;
            yield return NodeResult.Success;
        }
        yield return NodeResult.Failure;
    }

    private IEnumerator<NodeResult> GoForConsumable(Func<bool> continueConditionFunc)
    {
        var closestChest = chestVendors.ClosestTo(Hero);
        var closestToChestPointOnNavmesh = AstarPath.active.GetNearest(closestChest.Position).clampedPosition;
        while (continueConditionFunc())
        {
            Hero.MoveTargetPosition = closestToChestPointOnNavmesh;
            yield return NodeResult.Continue;
        }
        yield return NodeResult.Success;
    }


    public IEnumerator<NodeResult> GoForBombs()
    {
        return GoForConsumable(actionsWithItems.HasNoBombs);
    }

    public IEnumerator<NodeResult> GoForPotions()
    {
        return GoForConsumable(actionsWithItems.HasNoPotions);
    }

    public IEnumerator<NodeResult> GoForConsumables()
    {
        return GoForConsumable(() => actionsWithItems.HasNoPotions() && actionsWithItems.HasNoBombs());
    }

    private void DebugItemActiveSkill(Item item)
    {
        IEntityControllable entity = null;
        try
        {
            entity = item.ActiveSkill.transform.parent.gameObject.GetComponent<Entity>().IEntity;
        }
        catch (NullReferenceException)
        {
            //oh well
        }
        if (entity != Hero)
        {
            Debug.LogError("Hero " + Hero.CharacterName + " is trying to use " + (entity != null ? entity.EntityName : "null") + "'s skill item.");
        }
    }

    public override bool IsAIReady()
    {
        return _IsAIReady();
    }

    protected override void OnDestroy()
    {
        base.OnDestroy();
        if (Hero != null)
        {
            var localHero = ((Hero)Hero.LocalEntity);
            localHero.onAttackFired -= localHero_onAttackFire;
            localHero.onAttackTargetChanged -= localHero_onAttackTargetChanged;
            localHero.onDeath -= localHero_onDeath;
        }
    }
}


