﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Assets._AI;
using Assets._Client;
using UnityEngine;


class ActionsWithPowerUpsAndCP : BotBehaviour
{
    protected List<Hero> allyHeroes { get { return commonCache.Heroes[allyTeam]; } }
    protected List<ConquestPoint> conquestPoints { get { return commonCache.ConquestPoints[Team.None]; } }
    protected List<Hero> enemyHeroes { get { return commonCache.Heroes[enemyTeam]; } }
    IEnumerable<EntityActivator> AvailablePowerUps { get { return commonCache.PowerUps[Team.None].Where(ea => ea.isActive); } }


    protected override bool AreRequirementsMet()
    {
        return commonCache.IsCached(allyTeam, BotCache.Heroes)
               && commonCache.IsCached(enemyTeam, BotCache.Heroes)
               && commonCache.IsCached(Team.None, BotCache.ConquestPoints)
               && commonCache.IsCached(Team.None, BotCache.PowerUps);
    }

    public bool ShouldGoForPowerUp()
    {
        var nicePowerUp = AvailablePowerUps.ClosestTo(Hero);
        if (nicePowerUp == null || TutorialManager.IsTutorialModeOn) { return false; }
        var sqDistanceToNicePowerUp = (Hero.Position - nicePowerUp.Position).sqrMagnitude;

        var niceCp = conquestPoints.Where(cp => cp.LastCaptureTeam != allyTeam || cp.CapturingTeam == enemyTeam).ClosestTo(Hero);
        float sqDistanceToNiceCp = niceCp ? (Hero.Position - niceCp.Position).sqrMagnitude : Mathf.Infinity;

        return sqDistanceToNicePowerUp*3*3 < sqDistanceToNiceCp*2*2;
    }

    public override bool IsAIReady()
    {
        return _IsAIReady();
    }
}

