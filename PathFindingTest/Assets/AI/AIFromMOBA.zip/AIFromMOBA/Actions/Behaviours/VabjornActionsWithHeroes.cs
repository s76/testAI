﻿using Assets._Controller.Dispatcher;
using Assets._AI;
using React;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using UnityEngine;
using UnityMock;
using ScriptableSkills;


class VabjornActionsWithHeroes : ActionsWithHeroes
{
	const int chargetId = 0;
	const int roarId = 1;
	const int bearFormId = 2;

	//private float entityShiftCashedDmg;

    public override void Initialize()
    {
        base.Initialize();
        //CacheSkillDamage(chargetId, (dmg => entityShiftCashedDmg = dmg));
    }
	
    public IEnumerator<NodeResult> UseCharge()
    {
        Skill skill = Hero.GetSkill(chargetId + Hero.Stance * 4);
        if (skill == null || CanCast(skill) == false) yield return NodeResult.Failure;

        float skillRange = skill.Range - Hero.Radius;
        var enemyHeroesInRange = enemyHeroes.Where(eH => eH.IsTargetableBy(Hero) && Hero.HasInRange(eH, skillRange));
		if(enemyHeroesInRange.Count() == 0)
			 yield return NodeResult.Failure;

		Vector3 midPoint = Hero.Position;
		var target = enemyHeroesInRange.First();
		midPoint = target.Position;
		float myValue = HeroValue(Hero);
		float enemyValue = HeroValue(target);
		float valueFactor = (enemyValue - myValue) / myValue;
		if(target.Life / target.MaxLife > 0.8f && valueFactor > 0.5f)
			yield return NodeResult.Failure;

        Hero.UseSkill(skill, new SkillParams() { targetPosition = midPoint });
        yield return NodeResult.Success;
    }
    
    public IEnumerator<NodeResult> UseRoar()
    {
        Skill skill = Hero.GetSkill(roarId + Hero.Stance * 4);
        if (skill == null || CanCast(skill) == false) yield return NodeResult.Failure;

        float skillRange = skill.ExplosionRange;
		bool found = false;
        foreach(var eH in enemyHeroes)
		{
			if(eH.IsTargetableBy(Hero) && Hero.HasInRange(eH, skillRange))
			{
				found = true;
				break;	
			}
		}
		
		if(found)
		{
			Hero.UseSkill(skill);
			yield return NodeResult.Success;
		}
		else
			yield return NodeResult.Failure;
    }
	
    public IEnumerator<NodeResult> UseForm()
    {
        Skill skill = Hero.GetSkill(bearFormId);
        if (skill == null || CanCast(skill) == false || Hero.Stance != 0) yield return NodeResult.Failure;
		
        float skillRange = skill.ExplosionRange;
		bool found = false;
        foreach(var eH in enemyHeroes)
		{
			if(eH.IsTargetableBy(Hero) && Hero.HasInRange(eH, skillRange))
			{
				found = true;
				break;	
			}
		}
		
		if(found)
		{
			Hero.UseSkill(skill);
			yield return NodeResult.Success;
		}
		else
			yield return NodeResult.Failure;
    }
}