﻿using Assets._Controller.Dispatcher;
using Assets._AI;
using React;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using UnityEngine;
using UnityMock;
using ScriptableSkills;
using Assets._Controllable.BasicEntity;


public class EredinActionsWithHeroes : ActionsWithHeroes
{
	const int firstSkilltId = 0;
	const int secondSkillId = 1;
	const int ultiId = 2;

	//private float entityShiftCashedDmg;

    public override void Initialize()
    {
        base.Initialize();
        //CacheSkillDamage(chargetId, (dmg => entityShiftCashedDmg = dmg));
    }
	
    public IEnumerator<NodeResult> UseCavalry()
    {
        Skill skill = Hero.GetSkill(firstSkilltId);
        if (skill == null || CanCast(skill) == false) yield return NodeResult.Failure;

        float skillRange = Hero.AttackRange * 4f;
        var enemyHeroesInRange = enemyHeroes.Where(eH => eH.IsTargetableBy(Hero) && Hero.HasInRange(eH, skillRange));
		if(enemyHeroesInRange.Count() == 0)
			 yield return NodeResult.Failure;

		Vector3 midPoint = Hero.Position;
		var target = enemyHeroesInRange.First();
		midPoint = target.Position;
		float myValue = HeroValue(Hero);
		float enemyValue = HeroValue(target);
		float valueFactor = (enemyValue - myValue) / myValue;
		if(target.Life / target.MaxLife > 0.8f && valueFactor > 0.5f)
			yield return NodeResult.Failure;

		Hero.MoveTargetPosition = target.Position;
        Hero.UseSkill(skill, new SkillParams(){});
		StartCoroutine(MoveToTargetTillSilenced(target));
        yield return NodeResult.Success;
    }

	private IEnumerator MoveToTargetTillSilenced(Hero target)
	{
        float skillRange = Hero.AttackRange * 4f;
		while(Hero.IsSilenced)
		{
			yield return new WaitForSeconds(1f);
			if(target.State == EntityState.Dead || (target.Position - Hero.Position).sqrMagnitude > skillRange * skillRange)
			{
				var enemyHeroesInRange = enemyHeroes.Where(eH => eH.IsTargetableBy(Hero) && Hero.HasInRange(eH, skillRange));
				if(enemyHeroesInRange.Count() == 0)
					continue;
				float bestSqr = 10000f;
				Hero bestTarget = null;
				foreach(var h in enemyHeroesInRange)
				{
					float sqr = (h.Position - Hero.Position).sqrMagnitude;
					if(sqr < bestSqr)
					{
						bestSqr = sqr;
 						target = bestTarget;
					}
				}
			}
			Hero.MoveTargetPosition = target.Position;
		}
	}
    
    public IEnumerator<NodeResult> UseShield()
    {
        Skill skill = Hero.GetSkill(secondSkillId);
        if (skill == null || CanCast(skill) == false) yield return NodeResult.Failure;
		
		if(Hero.Life / Hero.MaxLife < 0.5f && Hero.State == EntityState.Attack)
		{
			Hero.UseSkill(skill, new SkillParams(){targetPosition = Hero.Position});
			yield return NodeResult.Success;
		}
		else
		{
			float skillRange = skill.Range;
			var allyHeroesInRange = allyHeroes.Where(eH => eH.State != EntityState.Dead && Hero.HasInRange(eH, skillRange));
			if(allyHeroesInRange.Count() == 0)
				 yield return NodeResult.Failure;

			bool found = false;
			foreach(var h in allyHeroesInRange)
			{
				if(h.Life / h.MaxLife < 0.5f && h.State == EntityState.Attack || h.Life / h.MaxLife < 0.2f)
				{
					Hero.UseSkill(skill, new SkillParams(){targetPosition = Hero.Position});
					found = true;
					break;
				}
			}

			if(found)
			{
				yield return NodeResult.Success;
			}
			else
				yield return NodeResult.Failure;
		}		
    }
	
    public IEnumerator<NodeResult> UseUlti()
    {
        Skill skill = Hero.GetSkill(ultiId);
        if (skill == null || CanCast(skill) == false || Hero.Stance != 0) yield return NodeResult.Failure;
		
        float skillRange = skill.ExplosionRange;
		bool found = false;
        var enemyHeroesInRange = enemyHeroes.Where(eH => eH.IsTargetableBy(Hero) && Hero.HasInRange(eH, skillRange));
		if(enemyHeroesInRange.Count() == 0)
			 yield return NodeResult.Failure;
		else if(enemyHeroesInRange.Count() == 1)
		{
			if(enemyHeroesInRange.First().Life < Hero.Life)
				found = true;
		}
		else if(Hero.Life / Hero.MaxLife < 0.3f)
		{
			found = true;
		}
		
		if(found)
		{
			Hero.UseSkill(skill);
			yield return NodeResult.Success;
		}
		else
			yield return NodeResult.Failure;
    }
}