﻿using Assets._Controller.Dispatcher;
using Assets._AI;
using React;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using UnityEngine;
using UnityMock;


class LethoActionsWithHeroes : ActionsWithHeroes
{
    public override void Initialize()
    {
        base.Initialize();
        CacheSkillDamage(cleaveID, (dmg => _cleaveCachedDmg = dmg));
    }

    const int aardID = 0;
    public IEnumerator<NodeResult> UseAard()
    {
        Skill aardSkill = Hero.GetSkill(aardID);
        if (aardSkill == null || CanCast(aardSkill) == false) yield return NodeResult.Failure;

        float aardRange = aardSkill.Range - Hero.Radius;
        var enemyHeroesInRange = enemyHeroes.Where(eH => eH.IsTargetableBy(Hero) && Hero.HasInRange(eH, aardRange));
        float myValue = HeroValue(Hero);
        var strongerEnemyHeroes = enemyHeroesInRange.Where(eH => HeroValue(eH) > myValue);
        Vector3 midPoint = strongerEnemyHeroes.GetCenter();
        if (midPoint.IsNaN()) yield return NodeResult.Failure;

        Hero.UseSkill(aardSkill, new SkillParams() { startPosition = Hero.Position, endPosition = midPoint });
        yield return NodeResult.Success;
    }
    
    const int quenID = 1;
    public IEnumerator<NodeResult> UseQuen()
    {
        Skill quenSkill = Hero.GetSkill(quenID);
        if (quenSkill == null || CanCast(quenSkill) == false) yield return NodeResult.Failure;

        if (Hero.HasBeenHitRecently())
        {
            if(Cast(quenSkill)) yield return NodeResult.Success;
        }

        yield return NodeResult.Failure;
    }


    const int cleaveID = 2;
    private float _cleaveCachedDmg = 0;
    private float CleaveDmg { get { return _cleaveCachedDmg; } }
    const float minDistanceForCleave = 3.0f;
    public IEnumerator<NodeResult> UseCleave()
    {
        Skill cleaveSkill = Hero.GetSkill(cleaveID);
        if (cleaveSkill == null) yield return NodeResult.Failure;

        if (CanCast(cleaveSkill) == false) yield return NodeResult.Failure;

        if ((UseCleaveToRunHidden()))
        {
            yield return NodeResult.Success;
        }

        const float maxHealthOverhead = 1.4f;
        var cleaveSkillDmg = CleaveDmg;
        var silentKillTarget = enemyHeroes.FirstOrDefault(
            eH => eH.IsTargetableBy(Hero)
            && Hero.HasInVisibilityRange(eH)
            && eH.CalculateHit(cleaveSkillDmg * maxHealthOverhead, Hero, cleaveSkill) > eH.Life
            && Hero.HasInRange(eH, minDistanceForCleave) == false);
        if (silentKillTarget == null) yield return NodeResult.Failure;

        if (Cast(cleaveSkill))
        {
            do
            {
                Hero.AttackTarget = silentKillTarget;
                yield return NodeResult.Continue;
            } while (Hero.IsVisible == false && silentKillTarget.IsTargetableBy(Hero));
            yield return NodeResult.Success;
        }
        else
        {
            yield return NodeResult.Failure;
        }
    }

    private bool UseCleaveToRunHidden()
    {
        const float fractionOfLifeToHide = 0.25f;
        if (Hero.AttackTarget == null
            && Hero.Life < Hero.MaxLife * fractionOfLifeToHide
            && enemyHeroes.Any(eH => eH.IsTargetableBy(Hero) && eH.HasInAttackRange(eH, safetyMargin)))
        {
            return Cast(cleaveID);
        }
        else
        {
            return false;
        }
    }
}