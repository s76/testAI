﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Assets._AI;
using Assets._Client;
using Assets._Controllable.BasicEntity;
using React;
using UnityEngine;


class ActionsWithPowerUps : BotBehaviour
{

    IEnumerable<EntityActivator> AvailablePowerUps { get { return commonCache.PowerUps[Team.None].Where(ea => ea.isActive); } }
    protected List<Hero> allyHeroes { get { return commonCache.Heroes[allyTeam]; } }
    protected List<Hero> enemyHeroes { get { return commonCache.Heroes[enemyTeam]; } }

	protected PowerUpsQuest quest;
	public override void Initialize()
	{
		base.Initialize();
		quest = QuestManager.instance.GetQuest<PowerUpsQuest>();
	}

	public bool CanBeFirstToPowerUp()
    {
        var closest = AvailablePowerUps.ClosestTo(Hero);
        if (closest == null) { return false; }
		if (quest != null)
		{
			MinesPlatform p;
			if (quest.activatorToPlatform.TryGetValue(closest, out p))
				if (p.State != MinesPlatform.PlatformState.Active) return false;
		}
		return IsOkToGoForPowerUp(closest);
    }

    private bool IsOkToGoForPowerUp(EntityActivator closest)
    {
        var sqTravelTime = SqTravelTime(closest, Hero);
        Func<Hero, bool> condFunc = h => h.Id != Hero.Id
                                         && h.IsAlive
                                         && SqTravelTime(closest, h) < sqTravelTime
                                         && h.HasInCone45(closest);
        return allyHeroes.Any(condFunc) == false && enemyHeroes.Any(condFunc) == false && !TutorialManager.IsTutorialModeOn;
    }

    private float SqTravelTime(EntityActivator closest, IMoverControllable mover)
    {
        float sqDistance = (closest.Position - mover.Position).sqrMagnitude;
        float sqTravelTime = sqDistance/(mover.MoveSpeed*mover.MoveSpeed);
        return sqTravelTime;
    }

    public IEnumerator<NodeResult> GoForClosestPowerUp()
    {
        var closest = AvailablePowerUps.ClosestTo(Hero);
        return GoTo(
            entityGetter: () => closest.isActive ? closest : null,
            refreshTarget: true
            );
    }

    public IEnumerator<NodeResult> GoForReallyClosePowerUp()
    {
		if(TutorialManager.IsTutorialModeOn)
			return Fail();
		else
		{
			float reallyCloseRange = 3;
			var reallyClosePowerUp = AvailablePowerUps.FirstOrDefault(pu => Hero.HasInRange(pu, reallyCloseRange));
			return GoTo(
				entityGetter: () => (reallyClosePowerUp != null && reallyClosePowerUp.isActive) ? reallyClosePowerUp : null,
				refreshTarget: true);
		}
    } 

    protected override bool AreRequirementsMet()
    {
        return commonCache.IsCached(Team.None, BotCache.PowerUps)
            && commonCache.IsCached(allyTeam, BotCache.Heroes)
            && commonCache.IsCached(enemyTeam, BotCache.Heroes);
    }

    public override bool IsAIReady()
    {
        return _IsAIReady();
    }
}

