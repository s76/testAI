﻿using Assets._Controllable.BasicEntity;
using Assets._Pathfinding;
using React;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using UnityMock;


class SuccubusActionsWithHeroes : ActionsWithHeroes
{
    const int SeductressKissID = 0; //AreaTarget
    const int UnrequiredLoveID = 1; //Aura - ExplosionRange
    const int BetweenPleasureAndPainID = 2; //Aura - ExplosionRange

    private float cachedSeductressKissDmg = 0;

    public override void Initialize()
    {
        base.Initialize();
        CacheSkillDamage(SeductressKissID, dmg => cachedSeductressKissDmg = dmg);
    }

    public IEnumerator<NodeResult> CastSeductressKissForKill()
    {
        var blink = GetReadySkill(SeductressKissID);
        if (blink == null) { yield return NodeResult.Failure; }

        var target = enemyHeroes.FirstOrDefault(eh => eh.IsTargetableBy(Hero)
            && Hero.HasInRangeWithoutBellys(eh, blink.Range + blink.ExplosionRange)
            && Hero.HasInAttackRange(eh) == false
            && eh.Life < eh.CalculateHit(cachedSeductressKissDmg, Hero, blink) + eh.CalculateHit(Hero.Damage, Hero, null));

        if (target != null)
        {
            var targetedPos = target.State == EntityState.Run ?
                target.Position + target.Trans.forward * (Hero.Radius + target.radius)
                : target.Position + Hero.PushAwayVector(target);

            Hero.UseSkill(blink, new Assets._Controller.Dispatcher.SkillParams() { targetPosition = ClampTargetToMaxRange(blink, targetedPos) });
            yield return NodeResult.Success;
        }
        yield return NodeResult.Failure;
    }

    public bool IsUnrequitedLoveReady()
    {
        return GetReadySkill(UnrequiredLoveID) != null;
    }

    public bool IsBetweenPleasureAndPainReady()
    {
        return GetReadySkill(BetweenPleasureAndPainID) != null;
    }

    public bool HasTwoEnemyHeroesInLeechRange()
    {
        var unrequitedLove = Hero.GetSkill(UnrequiredLoveID);
        if (unrequitedLove == null) { return false;}
        return HasEnemyHeroesInRangeWthoutBellys(2, unrequitedLove.ExplosionRange);
    }

    public bool HasTwoEnemyHeroesInUltiRange()
    {
        var ulti = Hero.GetSkill(BetweenPleasureAndPainID);
        if (ulti == null) { return false; }
        return HasEnemyHeroesInRangeWthoutBellys(2, ulti.ExplosionRange);
    }

    public IEnumerator<NodeResult> EnableUnrequiredLove()
    {
        return EnableTogglebleSkill(UnrequiredLoveID, IsLeechEnabled, "[Succubus AI] Hey, I'm already sucking, ok?");   
    }

    public IEnumerator<NodeResult> DisableUnrequiredLove()
    {
        return DisableTogglebleSkill(UnrequiredLoveID, IsLeechEnabled, "[Succubus AI] What? I'm not sucking anymore, babe.");
    }

    public bool IsLeechEnabled()
    {
        return Hero.Stance == 1 || Hero.Stance == 3;
    }

    public bool IsUltiEnabled()
    {
        return Hero.Stance == 2 || Hero.Stance == 3;
    }

    public IEnumerator<NodeResult> EnableBetweenPleasureAndPain()
    {
        return EnableTogglebleSkill(BetweenPleasureAndPainID, IsUltiEnabled, "[Succubus AI] Orgy is on. You cannot have double <3");
    }

    public IEnumerator<NodeResult> DisableBetweenPleasureAndPaint()
    {
        return DisableTogglebleSkill(BetweenPleasureAndPainID, IsUltiEnabled, "[Succubus AI] I cannot stop an orgy that was never there, sweety <3");
    }


    #region Old stuff
    public IEnumerator<NodeResult> SpamNormalSkills()
    {
        if (CanCast() == false) yield return NodeResult.Failure;

        for (int i = 0; i < 2; i++)
        {
            if (Cast(i)) yield return NodeResult.Success;
        }
        yield return NodeResult.Failure;
    }

    public IEnumerator<NodeResult> SpamNormalSkillsAtTargetedHero()
    {
        if (Hero.AttackTarget != null && Hero.AttackTarget.EntityType == EType.Hero)
        {
            var enumerator = SpamNormalSkills();
            while (enumerator.MoveNext())
                yield return NodeResult.Failure; //always fail to not block priority selectors (do in meantime)
        }
        else yield return NodeResult.Failure;
    }
    #endregion
}

