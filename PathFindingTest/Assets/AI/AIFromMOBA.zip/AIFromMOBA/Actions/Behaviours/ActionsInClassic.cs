﻿using Assets.game;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Assets._AI.Actions.Behaviours;
using Assets._AI;

class ActionsInClassic : BotBehaviour {
    private float laningPhaseStartTime = 45;

    public bool IsPreLaningPhase() {
        float endTime = laningPhaseStartTime;
        return GameManager.instance.GameCurrentTime < endTime;
    }

    public bool IsLaningPhase() {
        bool isAfterStart = GameManager.instance.GameCurrentTime > laningPhaseStartTime;
        bool isAfterEnd = Hero.Lvl >= 13;
        return isAfterStart && isAfterEnd == false;
    }

    public bool IsLateGame() {
        return Hero.Lvl >= 13;
    }

    protected override bool AreRequirementsMet() {
        throw new NotImplementedException();
    }

    public override bool IsAIReady() {
        return _IsAIReady();
    }
}

