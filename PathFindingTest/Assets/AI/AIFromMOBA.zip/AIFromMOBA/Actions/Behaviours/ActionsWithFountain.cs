﻿using Assets._AI;
using Assets._AI.Actions.Behaviours;
using Assets._Controllable.BasicEntity;
using Assets._Controllable.HealingTower;
using React;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using UnityEngine;

class ActionsWithFountain : BotBehaviour
{

    HealingTower fountain { get { return commonCache.Fountain[allyTeam]; } }

    protected override bool AreRequirementsMet()
    {
        return commonCache.IsCached(allyTeam, BotCache.Fountain);
    }

    public override bool IsAIReady()
    {
        return _IsAIReady();
    }

    public IEnumerator<NodeResult> RunToFountain()
    {
        return GoTo(() => fountain, positionModifier: (e) => PositionModifierRandomOffset(e, fountainReach));

    }

    const float fountainReach = 2;
    public bool IsAtFountain()
    {
        return ((HealingTowerMasterController)fountain.Controller).HasInHealingRange(Hero);
    }

    public bool IsRunningToFountainProfitable()
    {
        if (fountain == null || Hero == null) 
        {
            Debug.LogError("[Ai] NullReferenceException", this);
            return false;
        }

        var controller = Hero.Controller as HeroMasterController;
        if (controller == null) { Debug.LogError("[AI] Hero.Controller is not HeroMasterController"); return false; }

        float respawnTime = controller.RespawnTime.Interval;
        respawnTime = RespawnTimeDifficultyMiscalculation(controller, respawnTime);

        float timeOfRun = (Vector3.Distance(Hero.Position, fountain.Position) - fountain.AttackRange) / Hero.MoveSpeed;
        float healthPercentThreshhold = Mathf.Clamp01((1 - timeOfRun * (1 / respawnTime)));
        return Hero.Life < healthPercentThreshhold * Hero.MaxLife;
    }

    private static float RespawnTimeDifficultyMiscalculation(HeroMasterController controller, float respawnTime)
    {
        float difficulty = controller.heroAI.Difficulty.Difficulty;
        float easyness = 1 - difficulty;
        respawnTime *= Mathf.Lerp(1, 2, easyness);
        return respawnTime;
    }

	public bool CanTeleportToFountain()
	{
		if(IsAtFountain())
			return false;

		if(Hero.State != EntityState.Run && Hero.State != EntityState.Stay && Hero.State != EntityState.Teleport || !Hero.CanContinueTeleport)
			return false;

		return true;
	}

    public bool IsTeleportToFountainProfitable()
	{
        if (fountain == null || Hero == null) 
        {
            Debug.LogError("[Ai] NullReferenceException", this);
            return false;
        }
		
        float timeOfRun = (Vector3.Distance(Hero.Position, fountain.Position) - fountain.AttackRange) / Hero.MoveSpeed;
		if(Hero.TeleportCastTime > timeOfRun)
			return false;

		return true;
	}

	public IEnumerator<NodeResult> TeleportToFountain()
	{
		float startTeleportDistance = 10f;
		if(!Hero.CanContinueTeleport || !HeroActions.IsNoEnemyInDistance(Hero, startTeleportDistance))
			yield return NodeResult.Failure;
        var controller = Hero.Controller as HeroMasterController;
        if (controller == null) { Debug.LogError("[AI] Hero.Controller is not HeroMasterController"); yield return NodeResult.Failure; }
		if(Hero.State != EntityState.Teleport)
			controller.Teleport();
		
		float breakTeleportDistance = 5f;
        while (Hero.State == EntityState.Teleport)
		{
			if(HeroActions.IsNoEnemyInDistance(Hero, breakTeleportDistance) && Hero.CanContinueTeleport)
				yield return NodeResult.Continue;
			else
				break;
		}
		yield return NodeResult.Success;
	}
}

