﻿using Assets._Controllable.HealingTower;
using Assets._Controllable.BasicEntity;
using Assets._AI;
using React;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Assets._Controller.Dispatcher;


class ActionsWithHeroesAndFountain : BotBehaviour
{
    protected HealingTower fountain { get { return commonCache.Fountain[allyTeam]; } }
    protected HealingTower enemyFountain { get { return commonCache.Fountain[enemyTeam]; } }
    protected List<Hero> enemyHeroes { get { return commonCache.Heroes[enemyTeam]; } }
    protected List<Hero> allyHeroes { get { return commonCache.Heroes[allyTeam]; } }

    protected override bool AreRequirementsMet()
    {
        return commonCache.IsCached(allyTeam, Assets._AI.BotCache.Fountain)
            && commonCache.IsCached(allyTeam, Assets._AI.BotCache.Heroes)
            && commonCache.IsCached(enemyTeam, Assets._AI.BotCache.Heroes);
    }

    protected IEnumerator<NodeResult> CastLineShotTowardsFountain(int skillID)
    {
        var skill = GetReadySkill(skillID);
        if (skill == null) yield return NodeResult.Failure;

        Hero.UseSkill(skill, new SkillParams { startPosition = Hero.Position, endPosition = LineShotEndPosition(skill, fountain) });
        yield return NodeResult.Success;
    }

    protected IEnumerator<NodeResult> CastAreaTargetTowardsFountain(int skillID)
    {
        var vendetta = GetReadySkill(skillID);
        if (vendetta == null) { yield return NodeResult.Failure; }

        Hero.UseSkill(vendetta, new SkillParams() { targetPosition = LineShotEndPosition(vendetta, fountain) });
        yield return NodeResult.Success;
    }

    public override bool IsAIReady()
    {
        return _IsAIReady();
    }
}
