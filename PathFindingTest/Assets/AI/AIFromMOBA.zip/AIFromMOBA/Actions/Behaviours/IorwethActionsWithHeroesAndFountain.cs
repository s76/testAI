﻿using Assets._Controller.Dispatcher;
using Assets._Controllable.BasicEntity;
using React;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;


class IorwethActionsWithHeroesAndFountain : ActionsWithHeroesAndFountain
{
    const int DrivenByHatredID = 0;
    const int SquirrelsMarkID = 1;
    const int VendettaID = 2;

    public IEnumerator<NodeResult> CastVendettaTowardsFountain()
    {
        return CastAreaTargetTowardsFountain(VendettaID);
    }
}

