﻿using React;
using Assets._Controllable.BasicEntity;
using Assets._AI;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Assets._Controller.Dispatcher;
using UnityEngine;


class EithneActionsWithHeroes : ActionsWithHeroes
{
    const int ThornedDaggerID = 0; //LineShot
    const int PathOfThornesID = 1; //Drawed
    const int PiercingArrowID = 2; //LineShot

    float thornedDaggerCachedDamage = 0;
    float piercingArrowCachedDamage = 0;

    public override void Initialize()
    {
        base.Initialize();
        CacheSkillDamage(ThornedDaggerID, (dmg => thornedDaggerCachedDamage = dmg));
        CacheSkillDamage(PiercingArrowID, (dmg => piercingArrowCachedDamage = dmg));
    }

    public IEnumerator<NodeResult> CastThornedDaggerAtTarget()
    {
        return CastLineShotAtTarget(ThornedDaggerID);
    }

    public IEnumerator<NodeResult> CastThornedDaggerForKill()
    {
        var thornedDagger = GetReadySkill(ThornedDaggerID);
        if (thornedDagger == null) { yield return NodeResult.Failure; }

        var almostDeadEnemyInRange = enemyHeroes.FirstOrDefault(eH =>
            eH.IsTargetableBy(Hero)
            && Hero.HasInRangeWithoutBellys(eH, thornedDagger.Range)
            && eH.Life < eH.CalculateHit(thornedDaggerCachedDamage, Hero, thornedDagger));

        if (almostDeadEnemyInRange != null)
        {
            Hero.UseSkill(thornedDagger, new SkillParams { startPosition = Hero.Position, endPosition = LineShotEndPosition(thornedDagger, almostDeadEnemyInRange) });
            yield return NodeResult.Success;
        }

        yield return NodeResult.Failure;
    }

    public IEnumerator<NodeResult> CastPiercingArrowForKill()
    {
        return CastPiercingArrowForKill(null);
    }

    public IEnumerator<NodeResult> CastPiercingArrowForKillEasy()
    {
        return CastPiercingArrowForKill(v => v.AddRandomOffset(3));
    }

    public IEnumerator<NodeResult> CastPiercingArrowForKillMedium()
    {
        return CastPiercingArrowForKill(v => v.AddRandomOffset(1));
    }

    protected IEnumerator<NodeResult> CastPiercingArrowForKill(Func<Vector3, Vector3> offsetFunc)
    {
        var piercingArrow = GetReadySkill(PiercingArrowID);
        if (piercingArrow == null) { yield return NodeResult.Failure; }

        var target = enemyHeroes.FirstOrDefault(eH =>
            eH.IsTargetableBy(Hero)
            && Hero.HasInRangeWithoutBellys(eH, piercingArrow.Range)
            && Hero.HasInAttackRange(eH) == false
            && eH.Life < eH.CalculateHit(piercingArrowCachedDamage, Hero, piercingArrow));

        if (target != null)
        {
            var targetPos = target.PredictPosition(piercingArrow.CastTime);
            if (offsetFunc != null) { targetPos = offsetFunc(targetPos); }
            Hero.UseSkill(piercingArrow, new SkillParams { startPosition = Hero.Position, endPosition = LineShotEndPosition(piercingArrow, targetPos)});
            yield return NodeResult.Success;
        }
        yield return NodeResult.Failure;
    }

    const float thornRange = 3;
    public IEnumerator<NodeResult> CastPathOfThornsAtTarget()
    {
        var target = Hero.AttackTarget;

        var pathOfThorns = GetReadySkill(PathOfThornesID);
        if (pathOfThorns == null || target == null) { yield return NodeResult.Failure; }

        if (Hero.HasInRangeWithoutBellys(target, pathOfThorns.Range))
        {
            List<Vector3> line = new List<Vector3>(5);
            var maxDistanceFromHero = pathOfThorns.Range;
            var minDistanceBetween = pathOfThorns.ExplosionRange;
            line.Add(target.Position);
            AddFragment(line, line[line.Count - 1], minDistanceBetween, maxDistanceFromHero);
            AddFragment(line, line[line.Count - 1], minDistanceBetween, maxDistanceFromHero);
            AddFragment(line, line[0], minDistanceBetween, maxDistanceFromHero);
            AddFragment(line, line[line.Count - 1], minDistanceBetween, maxDistanceFromHero);

            Hero.UseSkill(pathOfThorns, new SkillParams { points = line.ToArray() });
            yield return NodeResult.Success;
        }
        yield return NodeResult.Failure;
    }


    const int maxAddFragmentIterations = 5;
    private void AddFragment(List<Vector3> line, Vector3 addNearThis, float minDistanceBetween, float maxDistanceFromHero)
    {
        for (int i = 0; i < maxAddFragmentIterations; ++i)
        {
            Vector3 newFragment = addNearThis + RandomDirectionVersor() * minDistanceBetween;
            if (IsAcceptable(newFragment, line, minDistanceBetween) && Hero.HasInRangeWithoutBellys(newFragment, maxDistanceFromHero)) { line.Add(newFragment); break; }
        }
        //Debug.LogWarning("[Eithne Cast] Max iterations reached in building line in PathOfThorns", this);
    }

    private bool IsAcceptable(Vector3 newFragment, List<Vector3> line, float minDistanceBetween)
    {
        return line.Any(v => v.HasInRange(newFragment, minDistanceBetween)) == false;
    }

    private Vector3 RandomDirectionVersor()
    {
        var randomVector2 = UnityEngine.Random.insideUnitCircle;
        randomVector2.Normalize();
        return new Vector3(randomVector2.x, 0, randomVector2.y);
    }
}




