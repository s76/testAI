﻿using Assets._Controllable.BasicEntity;
using Assets._Controller.Dispatcher;
using React;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using UnityEngine;
class SaskiaActionsWithHeroes : ActionsWithHeroes
{
    const int ShieldStrikeID = 0; // SkillType.LineShot, TargetType.Line, (target)
    const int ByTheSwordAndFireID = 1; //SkillType.LineShot, TargetType.Line, (target)
    const int DragonSoulID = 2; //SkillType.Area, TargetType.None, ()

    public IEnumerator<NodeResult> CastShieldStrikeAtTarget()
    {
        return CastLineShotAtTarget(ShieldStrikeID);
    }

    public IEnumerator<NodeResult> CastByTheSwordAndFireAtTarget()
    {
        return CastLineShotAtTarget(ByTheSwordAndFireID);
    }

    public IEnumerator<NodeResult> CastDragonSoul()
    {
        const int minimumNearbyHeroToCast = 2;
        const float marginPercent = 0.2f;

        var dragonSoul = GetReadySkill(DragonSoulID);
        if (dragonSoul == null) { yield return NodeResult.Failure; }

        if (HasEnemyHeroesInRangeWthoutBellys(minimumNearbyHeroToCast, dragonSoul.ExplosionRange * (1-marginPercent), dragonSoul.CastTime))
        {
            Hero.UseSkill(dragonSoul);
            yield return NodeResult.Success;
        }
        yield return NodeResult.Failure;
    }
}
