﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Assets._AI;
using Assets._Controllable.BasicEntity;
using Assets._Controller.Dispatcher;
using React;
using ScriptableSkills;
using UnityEngine;

class TrissActionsWithHeroes : ActionsWithHeroes
{
    private const int ReflectionInIceId = 0; //AreaTarget, Range 7, Exp range 3.5
    private const int AlzursThunderId = 1; //AreaTarget, Range 6, exp range 2.5, secondary range 3.5
    private const int MirrorsEdgeId = 2; //SelfSupport, Exp range 12

    public IEnumerator<NodeResult> CastReflectionInTheIceOnTarget()
    {
        if (Hero.AttackTarget == null) { yield return NodeResult.Failure; }

        var skill = GetReadySkill(ReflectionInIceId);
        if (skill == null) { yield return NodeResult.Failure; }

        Vector3 targetPos = Hero.AttackTarget.PredictPosition(skill.CastTime);

        var skillFullRange = skill.Range + skill.ExplosionRange;
        if (!Hero.HasInRange(targetPos, skillFullRange)) { yield return NodeResult.Failure; }

        targetPos =
            enemyHeroes.Where(eH => eH.IsTargetableBy(Hero) && targetPos.HasInRange(eH.PredictPosition(skill.CastTime), skill.ExplosionRange*2))
                .GetCenter();
        targetPos = ClampTargetToMaxRange(skill, targetPos);
		if(targetPos.IsNaN())
			yield return NodeResult.Failure;
        Hero.UseSkill(skill, new SkillParams {targetPosition = targetPos});

        yield return NodeResult.Success;
    }

    public IEnumerator<NodeResult> CastAlzursThunderAtTarget()
    {
        if (Hero.AttackTarget == null) { yield return NodeResult.Failure; }

        var skill = GetReadySkill(AlzursThunderId);
        if (skill == null) { yield return NodeResult.Failure; }

        Vector3 targetPosition = Hero.AttackTarget.PredictPosition(skill.CastTime);

        var skillFullRange = skill.Range + skill.ExplosionRange;
        if (!Hero.HasInRange(targetPosition, skillFullRange)) { yield return NodeResult.Failure; }

        var reflectionInIce = Hero.GetSkill(ReflectionInIceId).ScriptableSkill as ReflectionInIce;
        var reflections = reflectionInIce.Reflections;

        if (reflections == null) { yield return NodeResult.Failure; }

        targetPosition = reflections.Where(t => t != null).Select(t => t.position).Where(pos => targetPosition.HasInRange(pos, skill.ExplosionRange)).Concat(new[] {targetPosition}).GetCenter();
        targetPosition = ClampTargetToMaxRange(skill, targetPosition);
        Hero.UseSkill(skill, new SkillParams {targetPosition = targetPosition});

        yield return NodeResult.Success;
    }

    public bool IsMirrorsEdgeReady()
    {
        return GetReadySkill(MirrorsEdgeId) != null;
    }

    public bool CanHitTwoTargetsWithMirrorsEdge()
    {
        var skill = Hero.GetSkill(MirrorsEdgeId);
        if (skill == null) { return false; }

        return HasEnemyHeroesInRangeWthoutBellys(2, skill.ExplosionRange, skill.CastTime);
    }

    public IEnumerator<NodeResult> CastMirrorsEdge()
    {
        return CastAuraSkill(MirrorsEdgeId);
    }

    public IEnumerator<NodeResult> CastReflectionInIceDefensively()
    {
        var skill = GetReadySkill(ReflectionInIceId);
        if (skill == null) { yield return NodeResult.Failure; }

        float skillFullRange = skill.Range + skill.ExplosionRange;

        Vector3? targetPosition =
            enemyHeroes.Where(eh => eh.IsTargetableBy(Hero)).Select(eh => eh.PredictPosition(skill.CastTime)).Where(ePos => Hero.HasInRangeWithoutBellys(ePos, skillFullRange))
                 .ClosestVecTo(Hero);

        if (targetPosition == null) { yield return NodeResult.Failure; }

        var targetPos = ClampTargetToMaxRange(skill, targetPosition.Value);

        Hero.UseSkill(skill, new SkillParams {targetPosition = targetPos});

        yield return NodeResult.Success;
    }
}

