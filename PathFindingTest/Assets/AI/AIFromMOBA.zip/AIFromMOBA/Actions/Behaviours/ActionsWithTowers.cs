﻿using UnityEngine;
using System.Collections;
using Assets._AI.Actions.Behaviours;
using Assets._Client;
using Assets._AI;
using System.Collections.Generic;
using System.Linq;
using Assets._Controllable.Tower;
using React;
using Assets._Controllable.BasicEntity;
using System;

public class ActionsWithTowers : BotBehaviour {

    private List<Tower> allyTowers { get { return commonCache.Towers[allyTeam]; } }
    private List<Tower> enemyTowers { get { return commonCache.Towers[enemyTeam]; } }
    private List<Hero> allyHeroes { get { return commonCache.Heroes[allyTeam]; } }
    private List<Hero> enemyHeroes { get { return commonCache.Heroes[enemyTeam]; } }
    private LinkedList<Vector3> laneWayPoints { get { return commonCache.LaneWaypoints[allyTeam]; } }
    private Commander allyCommander { get { return commonCache.Commander[allyTeam]; } }
    private Commander enemyCommander { get { return commonCache.Commander[enemyTeam]; } }

    private const float safetyMargin = HeroActions.safetyMargin;

    protected override bool AreRequirementsMet() {
        return commonCache.IsCached(Team.None, BotCache.Towers)
            && commonCache.IsCached(allyTeam, BotCache.Heroes)
            && commonCache.IsCached(enemyTeam, BotCache.Heroes)
            && commonCache.IsCached(allyTeam, BotCache.LaneWayPoints)
            && commonCache.IsCached(allyTeam, BotCache.Commander)
            && commonCache.IsCached(enemyTeam, BotCache.Commander);
    }

    public IEnumerator<NodeResult> LastHitMinion() {
        Tower closestEnemyTower = enemyTowers.ClosestTo(Hero, Alive); //(Tower)Closest(enemyTowers);
        float maximumMinionHP = Hero.Damage * 0.9f;
        var minions = QuadTreeSystem.instance.QuadTree.Query(
            new QTree.BoundingRect(Hero.Position, Hero.VisibilityRange),
            e => e.EntityType == EType.Minion
                && e.IsTargetableBy(Hero)
                && e.IsEnemy(Hero)
                && e.IsCoveredBy(closestEnemyTower, Hero, safetyMargin) == false);
        var lowHPMinion = minions.FirstOrDefault(e => e.Life < maximumMinionHP);
        
        if (lowHPMinion == null) yield return NodeResult.Failure;

        Hero.AttackTarget = lowHPMinion;
        while (lowHPMinion.IsAlive) yield return NodeResult.Continue;
        yield return NodeResult.Success;
    }

    public IEnumerator<NodeResult> AttackLowestHPUncoveredMinion() {
        var minions = QuadTreeSystem.instance.QuadTree.Query(
            new QTree.BoundingRect(Hero.Position, Hero.VisibilityRange),
            e => e.EntityType == EType.Minion
                && e.IsTargetableBy(Hero)
                && e.IsEnemy(Hero)
                && e.IsCoveredBy(enemyHeroes, Hero, safetyMargin) == false
                && e.IsCoveredBy(enemyTowers, Hero, safetyMargin) == false);
        var minHPminion = minions.Aggregate((Entity)null, (e_min, e) => (e_min == null || e.Life < e_min.Life) ? e : e_min);
        //var lowHPMinion = minions.FirstOrDefault(e => e.Life < maximumMinionHP);
        //Debug.Log(Hero.EntityName + " " + Hero.CharacterName + " tries to target minion with hp " + (minHPminion ? minHPminion.Life.ToString() : "[no minion]"), minHPminion);

        if (minHPminion == null) yield return NodeResult.Failure;

        Hero.AttackTarget = minHPminion;
        while (minHPminion.IsAlive && minHPminion.IsCoveredBy(enemyHeroes, Hero, safetyMargin) == false)
            yield return NodeResult.Continue;
        yield return NodeResult.Success;
    }

    public IEnumerator<NodeResult> Push() {
        Entity referenceEntity = FurthestAllyTower();
        Func<IEntityControllable, float> sqrDist = (e1) => (e1.Position - referenceEntity.Position).sqrMagnitude;
        var closestTarget = GetFrontEnemyWave().Concat(enemyTowers.Where(e => e.IsTargetableBy(Hero)).Cast<Entity>())
            .Aggregate(null as Entity, (closest, e) => (closest == null || sqrDist(e) < sqrDist(closest) ? e : closest));

        if (closestTarget) {
            Hero.AttackTarget = closestTarget;
            yield return NodeResult.Success;
        } else
            yield return NodeResult.Failure;
    }

    public IEnumerator<NodeResult> StayAwayFromEnemyTowurs() {
        float singleRunDistance = 2;

        var closeEnemyTowur = enemyTowers.FirstOrDefault(enemyTowur => enemyTowur.HasInAttackRange(Hero, safetyMargin) && enemyTowur.IsAlive);
        while (closeEnemyTowur != null && closeEnemyTowur.HasInAttackRange(Hero)) {
            Hero.MoveTargetPosition = Hero.Position + (Hero.Position - closeEnemyTowur.Position).normalized * singleRunDistance;
            yield return NodeResult.Continue;
        }
        yield return NodeResult.Failure; // -- no enemyTowur to avoid anymore
    }

    public bool IsFriendlyHeroNearEnemyTowur() {
        Tower tower = (Tower)enemyTowers.ClosestTo(Hero, Alive);
        if (tower == null) return false; //Null fix when all towurs are down by Zbyszek
        foreach (var h in allyHeroes)
            if (h != Hero && h.IsAlive && tower.HasInAttackRange(h, safetyMargin))
                return true;
        return false;
    }

    public bool IsUnderEnemyTower() {
        Tower tower = enemyTowers.ClosestTo(Hero, Alive);
        if (tower == null) return false;
        return tower.HasInAttackRange(Hero);
    }

    public bool IsTowerTargetingMinion() {
        Tower tower = enemyTowers.ClosestTo(Hero, Alive);
        if (tower == null) return false;
        return tower.AttackTarget != null && tower.AttackTarget.EntityType == EType.Minion;
    }

    public bool IsEnemyTowerFocusingMinions() {
        Tower tower = enemyTowers.ClosestTo(Hero, Alive);
        if (tower == null) return false;
        if (tower.AttackTarget != null && tower.AttackTarget.EntityType == EType.Hero) return false;
        Func<Entity, bool> filter = delegate(Entity e) { return e.EntityType == EType.Minion && e.IsAlive && e.IsEnemy(tower) && tower.HasInAttackRange(e); };
        var minions = QuadTreeSystem.instance.QuadTree.Query(new QTree.BoundingRect(tower.Position, tower.AttackRange + tower.Radius), filter);
        if (minions.Count == 0) return false;
        else return true;
    }

    public IEnumerator<NodeResult> FindMacroTarget() {
        Entity closestEntity = null;
        closestEntity = enemyHeroes.Cast<Entity>().Concat(enemyTowers.Cast<Entity>()).ClosestTo(Hero, Alive);
        var macroTarget = closestEntity;
        if (macroTarget != null) yield return NodeResult.Success;
        else {
            Debug.LogWarning(Hero.ToString() + " brainfarted.", Hero.LocalEntity);
            yield return NodeResult.Failure;
        }
    }

    public IEnumerator<NodeResult> AttackClosestMacroTarget() {
        Entity target = null;
        target = enemyHeroes.Cast<Entity>().Concat(enemyTowers.Cast<Entity>()).ClosestTo(Hero, Alive);
        if (target == null) {
            Debug.LogWarning(Hero.ToString() + " brainfarted.", Hero.LocalEntity);
            yield return NodeResult.Failure;
        }
        if (Hero.CanTargetEnemy(target))
            Hero.AttackTarget = target;
        else {
            Debug.LogWarning(Hero.ToString() + " can't target MacroTarget.", Hero.LocalEntity);
            yield return NodeResult.Failure;
        }
        while (Hero.CanTargetEnemy(target)) {
            yield return NodeResult.Continue;
        }
        yield return NodeResult.Failure;
    }

    public IEnumerator<NodeResult> GoToFurthestTower() {
        float maxOffset = 5;

        Hero.MoveTargetPosition = AddRandomOffsetWithoutLinecast(FurthestAllyTower().Position, maxOffset);

        while (Hero.HasInRange(Hero.MoveTargetPosition, 3f) == false) yield return NodeResult.Continue;
        yield return NodeResult.Success;
    }

    #region Tools

    private Entity FurthestAllyTower() { return FurthestTower(allyCommander); }
    private Entity FurthestEnemyTower() { return FurthestTower(enemyCommander); }

    private Entity FurthestTower(Commander c) {
        ITowerChainable furthest = c;
        while (furthest.PreviousTower.Length != 0 && furthest.PreviousTower[0].IsAlive)
            furthest = (ITowerChainable)furthest.PreviousTower[0];
        return (Entity)furthest;
    }

    private List<Entity> GetFrontAllyWave() {
        return GetFrontWave(Hero.EntityTeam);
    }

    private List<Entity> GetFrontEnemyWave() {
        return GetFrontWave(Hero.TeamOfEnemy);
    }

    private List<Entity> GetFrontWave(Team team) {
        float minSearchAreaHeightOrWidth = 5f;

        bool doReversed = Hero.EntityTeam != team;

        LinkedListNode<Vector3> wp = doReversed ? laneWayPoints.First : laneWayPoints.Last;
        List<Entity> frontWave = null;
        while ((frontWave == null || frontWave.Count == 0) && (doReversed ? wp.Next : wp.Previous) != null) {
            Vector3 p = wp.Value;
            wp = doReversed ? wp.Next : wp.Previous;
            Vector3 _p = wp.Value;
            Vector3 center = (p + _p) / 2;
            float width = Math.Max(Mathf.Abs(p.x - _p.x), minSearchAreaHeightOrWidth);
            float height = Math.Max(Mathf.Abs(p.z - _p.z), minSearchAreaHeightOrWidth);

            frontWave = QuadTreeSystem.instance.QuadTree.Query(
                QTree.BoundingRect.FromCenter(center.x, center.z, width, height),
                e => e.EntityType == EType.Minion && e.IsTargetable && e.IsVisible && e.EntityTeam == team);
        }
        return frontWave;
    }

    private static Vector3 AddRandomOffsetWithoutLinecast(Vector3 position, float maxOffset) {
        Vector2 proposedPos = UnityEngine.Random.insideUnitCircle * maxOffset;
        Vector3 proposedPos3D = new Vector3(proposedPos.x, 0, proposedPos.y);
        proposedPos3D += position;
        return proposedPos3D;
    }

    #endregion

    private bool Alive(Entity e) {
        return e.IsAlive;
    }

    public override bool IsAIReady() {
        return _IsAIReady();
    }
}
