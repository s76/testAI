﻿using UnityEngine;
using System.Collections;
using Assets._AI.Actions.Behaviours;
using Assets._Controllable.BasicEntity;
using System.Collections.Generic;

public abstract class Behaviour : MonoBehaviour, IBehaviour {

    protected IEntityControllable Entity;

    public virtual void Initialize() {
		var component = GetEntityComponent<Entity>();
		if (component == null) Debug.LogError("[Behaviour] Couldn't find entity.");
		else Entity = component.IEntity;
    }

    protected bool _AreRequirementsMet = false;
    protected abstract bool AreRequirementsMet();

    /// <summary>
    /// Just use base._IsAIReady() for method to properly show in Reactor editor
    /// </summary>
    /// <returns></returns>
    public abstract bool IsAIReady();

    protected bool _IsAIReady() {
        if (_AreRequirementsMet) return true;
        else return _AreRequirementsMet = AreRequirementsMet();
    }

	public T GetEntityComponent<T>() where T : Component
	{
		T comp = gameObject.GetComponent<T>();
		if (comp == null && transform.parent != null && transform.parent.gameObject != null)
		{
			comp = transform.parent.gameObject.GetComponent<T>();
		}
		return comp;
	}

    public bool Success()
    {
        return true;
    }
}
