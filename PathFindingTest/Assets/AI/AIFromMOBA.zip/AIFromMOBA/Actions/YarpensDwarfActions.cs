﻿using UnityEngine;
using System.Collections;
using Assets._AI.Actions;
using Assets._Controllable.BasicEntity;
using System;
using System.Collections.Generic;
using QTree;
using React;

namespace Assets._AI.Actions {
    class YarpensDwarfActions : MovingSpawnActions {
        private Vector3 offset;
        private Vector3 offsetDir;
        private IHeroControllable Yarpen {get;set;}
        private YarpensDwarf Dwarf {get;set;}

        public override void Initialize(IEntityControllable entity) {
            base.Initialize(entity);
            offset = MovingSpawn.Position - Owner.Position;

            Dwarf = (YarpensDwarf)entity.LocalEntity;
            Yarpen = (IHeroControllable)Owner;
            ((Hero)Owner.LocalEntity).onMoveTargetPositionChanged += YarpensDwarfActions_MoveTargetPositionChanged;

            float radius = 1.5f;
            offset.Normalize();
            offsetDir = offset * radius;
        }

        private void YarpensDwarfActions_MoveTargetPositionChanged(IMoverControllable mover, Vector3 targetPosition) {
            if (Time.time < Dwarf.TakeDownUntilTime) return;
            if (MovingSpawn.State == EntityState.Run || MovingSpawn.State == EntityState.Stay)
                MovingSpawn.MoveTargetPosition = targetPosition + offset;
        }

        public IEnumerator<NodeResult> GoToYarpen() {
            MovingSpawn.MoveTargetPosition = Owner.Position + offset;
            yield return NodeResult.Success;
        }

        public IEnumerator<NodeResult> GoToYarpensRallyPoint() {
            MovingSpawn.MoveTargetPosition = Yarpen.MoveTargetPosition + offset;
            yield return NodeResult.Success;
        }

        public bool IsTakeDownUsed() {
            return Time.time < Dwarf.TakeDownUntilTime;
        }

        public IEnumerator<NodeResult> GoForTakeDown() {
            Vector3 takeDownOffset = offsetDir * Dwarf.TakeDownTarget.Radius;
            MovingSpawn.MoveTargetPosition = Dwarf.TakeDownTarget.Position + takeDownOffset;
            MovingSpawn.State = EntityState.Run; //is that necessary? probably...
            while (Time.time < Dwarf.TakeDownUntilTime && Dwarf.State == EntityState.Run) yield return NodeResult.Continue;
            if (Dwarf.HasInAttackRange(Dwarf.TakeDownTarget)) yield return NodeResult.Success;
            else {
                Debug.LogWarning("Yarpen's Dwarf failed GoForTakeDown", Dwarf);
                yield return NodeResult.Failure;
            }
        }


        private void SetKeepDownTime(YarpensDwarf d) {
            if (Time.time > d.KeepDownUntilTime)
                d.KeepDownUntilTime = Time.time + Dwarf.LastCaptureTime;
        }

        public IEnumerator<NodeResult> TakeDown() {
            ForEveryDwarf(SetKeepDownTime);
            MovingSpawn.Rotation = Quaternion.LookRotation(Dwarf.TakeDownTarget.Position - Dwarf.Position);
            while (Time.time < Dwarf.KeepDownUntilTime) {               
                Dwarf.TakeDown(Dwarf.TakeDownTarget);
                yield return NodeResult.Continue;
            }
            yield return NodeResult.Success;
        }

        public bool IsTooFarFromYarpen() {
            float maxDistanceFromYarpen = 3.0f;
            return (MovingSpawn.Position - Owner.Position).sqrMagnitude > maxDistanceFromYarpen * maxDistanceFromYarpen;
        }

        public void OnDisable() {
			try
			{
            	((Hero)Owner.LocalEntity).onMoveTargetPositionChanged -= YarpensDwarfActions_MoveTargetPositionChanged;
			}catch{}
        }

        [Obsolete("This method should have never been written, but no simple workaround is possible at this time (and it's not my job)")]
        private void ForEveryDwarf(Action<YarpensDwarf> DwarfMethod) { //this method is bullshit
            List<Entity> objects = QuadTreeFinder.FindRect(Dwarf.Position.x - 4f, Dwarf.Position.z - 4f, 8f, 8f);
            foreach (Entity e in objects) {
                if (e.EntityTeam == Dwarf.EntityTeam && e.EntityType == EType.Spawn) {
                    ISpawnControllable spawn = (ISpawnControllable)e;
                    if (spawn.SpawnOwner.Id == Owner.Id && spawn.EntityName.Contains("Yarpen") && spawn.State != EntityState.Dead) {
                        YarpensDwarf dwarf = spawn as YarpensDwarf;
                        if (dwarf) DwarfMethod(dwarf);
                        else Debug.Log("Bad cast from spawn to YarpensDwarf", spawn.LocalEntity);
                    }
                }
            }
        }
    }
}
