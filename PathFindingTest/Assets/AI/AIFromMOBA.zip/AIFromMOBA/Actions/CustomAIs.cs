﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using UnityEngine;

class CustomAIs {
    public CustomReact customReactAndActions;
}

[System.Serializable]
public class CustomReact {
    public string name;
    public Reactable reactGraph;
}

[System.Serializable]
public class CustomReactsInMode {
    public GameMode gameMode;
    public CustomReact[] customReacts;
    public Reactable defaultReact;
}
