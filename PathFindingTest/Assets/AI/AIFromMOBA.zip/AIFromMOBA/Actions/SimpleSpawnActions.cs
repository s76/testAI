﻿using Assets._Controllable.BasicEntity;
using React;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using UnityEngine;

class SimpleSpawnActions : EntityActions {

    public float minLifeTime;

    protected ISpawnControllable Spawn { get; set; }
    protected IEntityControllable Owner { get { return Spawn.SpawnOwner; } }

    public override void Initialize(IEntityControllable entity) {
        Spawn = (ISpawnControllable)entity;
        base.Initialize(entity);

    }

    public bool IsMinLifeTimeExpired() {
        return Entity.LocalEntity.InitTime + minLifeTime < Time.time;
    }

    public bool IsExpired() {
        return Spawn.LifeTimeLeft <= 0f && !Mathf.Approximately(Spawn.LifeTime, 0f);
    }

    public IEnumerator KillThyselfAfterSecond() {
        yield return new WaitForSeconds(1f);
        Spawn.State = EntityState.Dead;
    }

    public virtual IEnumerator<NodeResult> KillThyself() {
        Spawn.State = EntityState.Dead;
        yield return NodeResult.Success;
    }
}
