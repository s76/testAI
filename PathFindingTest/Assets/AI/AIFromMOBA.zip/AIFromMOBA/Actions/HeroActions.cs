using Assets._AI;
using Assets._AI.Actions;
using Assets._Client;
using Assets._Controllable._Initializer;
using Assets._Controllable.BasicEntity;
using Assets._Controllable.Tower;
using Assets._Pathfinding;
using Assets.game;
using Pathfinding;
using QTree;
using React;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using UnityEngine;


public class HeroActions : MoverActions {

    protected IHeroControllable Hero { get; set; }
    protected HeroMasterController HeroMasterController { get { return (HeroMasterController)Hero.Controller; } }
    private Entity macroTarget;
    private bool inMicroManagement = false;
    private IEnumerable<Hero> enemyHeroes { get { return BotManager.instance.Cache.Heroes[Hero.TeamOfEnemy]; } }
    private IEnumerable<Hero> allyHeroes { get { return BotManager.instance.Cache.Heroes[Hero.EntityTeam]; } } 
    private IEnumerable<Tower> enemyTowers { get { return BotManager.instance.Cache.Towers[Hero.TeamOfEnemy]; } }
    private IEnumerable<Tower> allyTowers { get { return BotManager.instance.Cache.Towers[Hero.EntityTeam]; } }
    private Commander enemyCommander { get { return BotManager.instance.Cache.Commander[Hero.TeamOfEnemy]; } }
    private Commander allyCommander { get { return BotManager.instance.Cache.Commander[Hero.EntityTeam]; } }
    private Entity fountain { get { return BotManager.instance.Cache.Fountain[Hero.EntityTeam]; } }
    private IEnumerable<ConquestPoint> conquestPoints { get { return BotManager.instance.Cache.ConquestPoints[Team.None]; } }
    private IEnumerable<VendorEntity> enemyIntelVendors { get { throw new NotImplementedException(); } }
    public LinkedList<Vector3> laneWayPoints { get { return BotManager.instance.Cache.LaneWaypoints[Hero.EntityTeam]; } }
    private bool isGameStarted = false;

    public const float safetyMargin = 1f;

    public override void Initialize(IEntityControllable entity) {
        Hero = (IHeroControllable)entity;
        //((Hero)Hero.LocalEntity).NewAttackTargetCallback += HeroOnAttackTargetChanged;
        base.Initialize(entity);
        GameManager.instance.onGameStartEvent += instance_OnGameStart;
    }

    protected void OnDestroy()
    {
        if (GameManager.instance)
            GameManager.instance.onGameStartEvent -= instance_OnGameStart;
    }

    public bool InitAIPrerequirements() {
        return AIRequirementsMet;
    }

    void instance_OnGameStart() {
        isGameStarted = true;
    }

    private bool InitMacroTargets() {
        return AIRequirementsMet;
    }

    // ===================================== MACRO MANAGEMENT =====================================//

    public bool IsInMicroManagement() {
        return inMicroManagement;
    }



    /// <summary>
    /// SimpleAI. Finds closest hero or tower on the map.
    /// </summary>
    /// <returns></returns>
    public IEnumerator<NodeResult> FindMacroTarget() {
        Entity closestEntity = null;
        closestEntity = Closest(enemyHeroes, closestEntity);
        closestEntity = Closest(enemyTowers, closestEntity);
        macroTarget = closestEntity;
        if (macroTarget != null) yield return NodeResult.Success;
        else {
            Debug.LogWarning(Hero.ToString() + " brainfarted.", Hero.LocalEntity);
            yield return NodeResult.Failure;
        }
    }

    public IEnumerator<NodeResult> AttackMacroTarget() {
        if (Hero.CanTargetEnemy(macroTarget)) {
            Hero.AttackTarget = macroTarget;
            yield return NodeResult.Success;
        } else {
            yield return NodeResult.Failure;
        }
    }

    public IEnumerator<NodeResult> AttackClosestMacroTarget() {
        Entity target = null;
        target = Closest(enemyHeroes, target);
        target = Closest(enemyTowers, target);
        if (target == null) {
            Debug.LogWarning(Hero.ToString() + " brainfarted.", Hero.LocalEntity);
            yield return NodeResult.Failure;
        }
        if (Hero.CanTargetEnemy(target))
            Hero.AttackTarget = target;
        else {
            Debug.LogWarning(Hero.ToString() + " can't target MacroTarget.", Hero.LocalEntity);
            yield return NodeResult.Failure;
        }
        while (Hero.CanTargetEnemy(target)) {
            yield return NodeResult.Continue;
        }
        yield return NodeResult.Failure;
    }

    public IEnumerator<NodeResult> TakeOverConquestPoint() {
        float distanceToDecideToTakeOver = 35;
        float distanceToStayNear = 2;

        foreach (var conquestPoint in conquestPoints) {
            if (conquestPoint == null || conquestPoint.IsLocked || conquestPoint.CurrentTeamColor == Hero.EntityTeam) continue;

            if (Hero.HasInRange(conquestPoint, distanceToDecideToTakeOver)) {
                Hero.MoveTargetPosition = conquestPoint.Position;
                while (!Hero.HasInRange(conquestPoint, distanceToStayNear)) yield return NodeResult.Continue;
                Hero.MoveTargetPosition = Hero.Position;
                while (conquestPoint.CaptureProgress < 1f) yield return NodeResult.Continue;
                yield return NodeResult.Success;
            } else continue;
        }
        yield return NodeResult.Failure;
    }

    public IEnumerator<NodeResult> AttackIntelVendor() {
        float distanceToDecideToAttack = 30;

        throw new NotImplementedException();

        foreach (var vendor in enemyIntelVendors) {
            if (Hero.CanTargetEnemy(vendor) && Hero.HasInRange(vendor, distanceToDecideToAttack)) {
                Hero.AttackTarget = vendor;
                while (vendor.IsAlive) yield return NodeResult.Continue;
                yield return NodeResult.Success;
            } else continue;
        }
        yield return NodeResult.Failure;
    }

    //public IEnumerable RunWithIntel() {
    //    if (Hero.ThiefMode
    //}

    public IEnumerator<NodeResult> RunWithIntel() {
        if (!Hero.ThiefMode) yield return NodeResult.Failure;

        float distanceToStay = 1;

        Hero.MoveTargetPosition = fountain.Position;
        while (!Hero.HasInRange(fountain, distanceToStay)) yield return NodeResult.Continue;
        yield return NodeResult.Success;
    }

    // ===================================== PRE-LANING PHASE =====================================//

    public bool IsPreLaningPhase() {
        float endTime = laningPhaseStartTime;
        return GameManager.instance.GameCurrentTime < endTime;
    }

    public IEnumerator<NodeResult> WanderAround() {
        float wanderingDistance = 2;
        float stayForSomeTime = UnityEngine.Random.Range(0.3f, 6f);

        while (Hero.State != EntityState.Stay) yield return NodeResult.Continue;
        while (Time.time < Hero.LastStateChangeTime + stayForSomeTime) yield return NodeResult.Continue;

        Hero.MoveTargetPosition = AddRandomOffset(Hero.Position, wanderingDistance);

        yield return NodeResult.Success;
    }

    public IEnumerator<NodeResult> GoToFurthestTower() {
        float maxOffset = 5;

        Hero.MoveTargetPosition = AddRandomOffsetWithoutLinecast(FurthestAllyTower().Position, maxOffset);

        while (Hero.HasInRange(Hero.MoveTargetPosition, 3f) == false) yield return NodeResult.Continue;
        yield return NodeResult.Success;
    }

    // ===================================== LANING PHASE PHASE =====================================//

    private float laningPhaseStartTime = 45;

    public bool IsLaningPhase() {
        bool isAfterStart = GameManager.instance.GameCurrentTime > laningPhaseStartTime;
        bool isAfterEnd = Hero.Lvl >= 13;
        return isAfterStart && isAfterEnd == false;
    }

    public IEnumerator<NodeResult> PositionYourselfInWave() {  // assumes only one lane
        float distanceFromWave = 2.5f + Hero.AttackRange / 2;
        float maxOffset = 2 + Hero.AttackRange / 2;

        Vector3? proposedPositionOrNull = proposedPositionFromCenterOfWave(distanceFromWave);

        if (proposedPositionOrNull == null) yield return NodeResult.Failure;
        Vector3 proposedPosition = (Vector3)proposedPositionOrNull;

        var radomOffset = GetRandomOffset(proposedPosition, maxOffset);
        Hero.MoveTargetPosition = proposedPosition + radomOffset;

        while (Hero.HasInRange(Hero.MoveTargetPosition, 1f) == false) {
            //if (Hero.MoveTargetPosition.IsCoveredBy(enemyHeroes, Hero)) yield return NodeResult.Failure;
            yield return NodeResult.Continue;

            proposedPositionOrNull = proposedPositionFromCenterOfWave(distanceFromWave);

            if (proposedPositionOrNull == null) yield return NodeResult.Failure;
            proposedPosition = (Vector3)proposedPositionOrNull;

            Hero.MoveTargetPosition = proposedPosition + radomOffset;
        }
        yield return NodeResult.Success;
    }

    private Vector3? proposedPositionFromCenterOfWave(float distanceFromWave) {
        var frontAllyWave = GetFrontAllyWave();
        if (frontAllyWave.Count == 0) return null;

        var centerOfWave = GetCenter(frontAllyWave);
        var offsetTowardsTower = Vector3.ClampMagnitude((FurthestAllyTower().Position - centerOfWave), distanceFromWave);
        var proposedPosition = centerOfWave + offsetTowardsTower;
        return proposedPosition;
    }

    public IEnumerator<NodeResult> LastHitMinion() {
        Tower closestEnemyTower = (Tower)Closest(enemyTowers);
        float maximumMinionHP = Hero.Damage * 0.9f;
        var minions = QuadTreeSystem.instance.QuadTree.Query(
            new QTree.BoundingRect(Hero.Position, Hero.VisibilityRange),
            e => e.EntityType == EType.Minion
                && e.IsTargetableBy(Hero)
                && e.IsEnemy(Hero)
                && e.IsCoveredBy(closestEnemyTower, Hero, safetyMargin) == false);
        //var minHPminion = minions.Aggregate((Entity)null, (e_min, e) => (e_min == null || e.Life < e_min.Life) ? e : e_min);
        var lowHPMinion = minions.FirstOrDefault(e => e.Life < maximumMinionHP);
        //Debug.Log(Hero.EntityName + " " + Hero.CharacterName + " tries to target minion with hp " + (minHPminion ? minHPminion.Life.ToString() : "[no minion]"), minHPminion);

        if (lowHPMinion == null) yield return NodeResult.Failure;

        Hero.AttackTarget = lowHPMinion;
        while (lowHPMinion.IsAlive) yield return NodeResult.Continue;
        yield return NodeResult.Success;
    }

    public IEnumerator<NodeResult> AttackLowestHPUncoveredMinion() {
        var minions = QuadTreeSystem.instance.QuadTree.Query(
            new QTree.BoundingRect(Hero.Position, Hero.VisibilityRange),
            e => e.EntityType == EType.Minion
                && e.IsTargetableBy(Hero)
                && e.IsEnemy(Hero)
                && e.IsCoveredBy(enemyHeroes, Hero, safetyMargin) == false
                && e.IsCoveredBy(enemyTowers, Hero, safetyMargin) == false);
        var minHPminion = minions.Aggregate((Entity)null, (e_min, e) => (e_min == null || e.Life < e_min.Life) ? e : e_min);
        //var lowHPMinion = minions.FirstOrDefault(e => e.Life < maximumMinionHP);
        //Debug.Log(Hero.EntityName + " " + Hero.CharacterName + " tries to target minion with hp " + (minHPminion ? minHPminion.Life.ToString() : "[no minion]"), minHPminion);

        if (minHPminion == null) yield return NodeResult.Failure;

        Hero.AttackTarget = minHPminion;
        while (minHPminion.IsAlive && minHPminion.IsCoveredBy(enemyHeroes, Hero, safetyMargin) == false)
            yield return NodeResult.Continue;
        yield return NodeResult.Success;
    }
    
    public IEnumerator<NodeResult> StayAwayFromEnemyHeroes() {
        float singleRunDistance = 2;

        var closeEnemyHeroes = enemyHeroes.Where(enemyHero => enemyHero.HasInAttackRange(Hero, safetyMargin));
        while (!closeEnemyHeroes.IsEmptyOrNull()) {
            var center = GetCenter(closeEnemyHeroes.Select(h => (Entity)h));
            Hero.MoveTargetPosition = Hero.Position + (Hero.Position - center).normalized * singleRunDistance;
            yield return NodeResult.Continue;
        }
        yield return NodeResult.Failure; // -- no enemyHeroes to avoid anymore
    }

    public IEnumerator<NodeResult> CarefulEngage() {
        float requiredAdvantageRatio = 2f;

        Hero lHero = (Hero)Hero.LocalEntity;
        float heroDPS = lHero.Damage * lHero.AttackSpeed;

        ////float combinedEnemyDPS = 0;
        //foreach (var enemyHero in enemyHeroes) {
        //    if (enemyHero.IsAlive && enemyHero.HasInAttackRange(Hero, safetyMargin))
        //        combinedEnemyDPS += enemyHero.Damage * enemyHero.AttackSpeed;
        //}
        //Tower tower = (Tower)Closest(enemyTowers, null);
        //if (tower != null)
        //    if (tower.HasInAttackRange(Hero, safetyMargin))
        //        combinedEnemyDPS += tower.Damage * tower.AttackSpeed;

        Hero target = null;
        float bestAdvantageRatio = 0;
        foreach (var enemyHero in enemyHeroes) {
            if (enemyHero.IsAlive && Hero.HasInVisibilityRange(enemyHero) && Hero.HasInLineOfSight(enemyHero)) {
                float combinedEnemyDPS = 0;
                foreach (var coverHero in enemyHeroes.Where(eh => enemyHero.IsCoveredBy(eh, Hero, safetyMargin)))
                    combinedEnemyDPS += coverHero.Damage * coverHero.AttackSpeed;
                foreach (var coverTower in enemyTowers.Where(et => enemyHero.IsCoveredBy(et, Hero, safetyMargin)))
                    combinedEnemyDPS += coverTower.Damage * coverTower.AttackSpeed;
                float heroAliveTime = lHero.Life / combinedEnemyDPS;
                float enemyAliveTime = enemyHero.Life / heroDPS;
                if (Hero.HasInAttackRange(enemyHero) == false) {
                    if (enemyHero.State == EntityState.Run) {
                        if (enemyHero.MoveSpeed > Hero.MoveSpeed)
                            enemyAliveTime = Mathf.Infinity;
                        else {
                            enemyAliveTime += TimeToGetInRange(Hero, enemyHero, Hero.AttackRange);
                            float relativeSpeed = RelativeSpeed(Hero, enemyHero);
                            if (relativeSpeed > 0)
                                enemyAliveTime += Mathf.Ceil(enemyHero.Life / Hero.Damage) * ((1 / Hero.AttackSpeed) / relativeSpeed);
                        }
                    }
                }
                float advantageRatio = heroAliveTime / enemyAliveTime;
                if (advantageRatio > bestAdvantageRatio) {
                    bestAdvantageRatio = advantageRatio;
                    target = enemyHero;
                }
            }
        }
        if (bestAdvantageRatio > requiredAdvantageRatio) {
            Hero.AttackTarget = target;
            yield return NodeResult.Success;
        } else
            yield return NodeResult.Failure;
    }

    public bool IsEnemyCommanderInVisibilityRange() {
        if (enemyCommander != null && enemyCommander.IsTargetableBy(Hero))
            return Hero.HasInVisibilityRange(enemyCommander);
        else return false;
    }

    public IEnumerator<NodeResult> TryAttackEnemyCommander() {
        if (enemyCommander != null && enemyCommander.IsTargetableBy(Hero)) {
            Hero.AttackTarget = enemyCommander;
            yield return NodeResult.Success;
        } else {
            yield return NodeResult.Failure;
        }
    }

    //public IEnumerable ChangePathToAvoidEnemyHeroesAndTowers() {
    //    throw new NotImplementedException();
    //    Vector3 targetPosition = Hero.MoveTargetPosition;
    //    var enemyCovers = Hero.AttackTarget != null
    //        ? enemyHeroes.Where(eH => Hero.AttackTarget.IsCoveredBy(eH, Hero))
    //        : enemyHeroes.Where(eH => Hero.MoveTargetPosition.IsCoveredBy(eH, Hero));

    //    foreach (var enemy in enemyCovers) { };
    //    yield return NodeResult.Success;
    //}

    //public bool IsTargetCoveredbyHeroOrTower() {
    //    if (Hero.AttackTarget != null)
    //        return Hero.AttackTarget.IsCoveredBy(enemyHeroes, Hero) || Hero.AttackTarget.IsCoveredBy(enemyTowers, Hero);
    //    else
    //        return Hero.MoveTargetPosition.IsCoveredBy(enemyHeroes, Hero) || Hero.MoveTargetPosition.IsCoveredBy(enemyTowers, Hero);
    //}

    /**/
    //======================================== LATE GAME =========================================//

    public bool IsLateGame() {
        return Hero.Lvl >= 13;
    }

    public IEnumerator<NodeResult> Push() {
        Entity referenceEntity = FurthestAllyTower();
        Func<IEntityControllable, float> sqrDist = (e1) => (e1.Position - referenceEntity.Position).sqrMagnitude;
        var closestTarget = GetFrontEnemyWave().Concat(enemyTowers.Where(e => e.IsTargetableBy(Hero)).Cast<Entity>())
            .Aggregate(null as Entity, (closest, e) => (closest == null || sqrDist(e) < sqrDist(closest) ? e : closest));

        if (closestTarget) {
            Hero.AttackTarget = closestTarget;
            yield return NodeResult.Success;
        } else
            yield return NodeResult.Failure;

        //if (closestTarget) {
        //    while (closestTarget.IsTargetableBy(Hero)) {
        //        Hero.AttackTarget = closestTarget;
        //        yield return NodeResult.Continue;
        //    }
        //}
    }

    public IEnumerator<NodeResult> StayAwayFromEnemyTowurs() {
        float singleRunDistance = 2;

        var closeEnemyTowur = enemyTowers.FirstOrDefault(enemyTowur => enemyTowur.HasInAttackRange(Hero, safetyMargin) && enemyTowur.IsAlive);
        while (closeEnemyTowur != null && closeEnemyTowur.HasInAttackRange(Hero)) {
            Hero.MoveTargetPosition = Hero.Position + (Hero.Position - closeEnemyTowur.Position).normalized * singleRunDistance;
            yield return NodeResult.Continue;
        }
        yield return NodeResult.Failure; // -- no enemyTowur to avoid anymore
    }

    public bool IsFriendlyHeroNearEnemyTowur() {
        Tower tower = (Tower)Closest(enemyTowers);
        if (tower == null) return false; //Null fix when all towurs are down by Zbyszek
        foreach (var h in allyHeroes)
            if (h != Hero && h.IsAlive && tower.HasInAttackRange(h, safetyMargin))
                return true;
        return false;
    }

    public IEnumerator<NodeResult> AttackClosestUncoveredMinion() {
        Attacker tower = (Attacker)FurthestEnemyTower();

        var enemyMinions = QuadTreeSystem.instance.QuadTree.Query(
            new QTree.BoundingRect(Hero.Position, Hero.VisibilityRange + Hero.Radius),
                e => e.EntityType == EType.Minion && e.IsTargetableBy(Hero) && e.IsVisible && e.IsEnemy(Hero) && !e.IsCoveredBy(tower, Hero, safetyMargin));

        Entity closestMinion = Closest(enemyMinions);
        if (closestMinion) {
            Hero.AttackTarget = closestMinion;
            yield return NodeResult.Success;
        } else
            yield return NodeResult.Failure;
    }

    public IEnumerator<NodeResult> AttackEnemyCommander() {
        Hero.AttackTarget = enemyCommander;
        while (enemyCommander.IsAlive)
            yield return NodeResult.Continue;
        yield return NodeResult.Success;
    }


    //===================================== MICRO MANAGEMENT =====================================//
    private float minimumHealthPercent = 0.5f;
    public bool IsHurt() {
        return Hero.Life / Hero.MaxLife < minimumHealthPercent;
    }

    public bool IsHealthy() {
        return Mathf.Approximately(Hero.Life, Hero.MaxLife);
    }

    public bool IsAbove80PHealth() {
        return Hero.Life > Hero.MaxLife * 0.8f;
    }

    public IEnumerator<NodeResult> RunToFountain() {
        float distance = 2;
        while (Hero.HasInRange(fountain, distance) == false) {
            Mover.MoveTargetPosition = fountain.Position;
            yield return NodeResult.Continue;
        }
        yield return NodeResult.Success;
    }

    public bool IsAtFountain() {
        float fountainReach = 2;
        float fountainReachSqr = fountainReach * fountainReach;
        float distanceToFountainSqr = (Hero.Position - fountain.Position).sqrMagnitude;
        return distanceToFountainSqr < fountainReachSqr;
    }

    public bool ShouldTeleport() {
        float teleportCastTime = Hero.TeleportCastTime;
        float distanceToFountain = (Hero.Position - fountain.Position).sqrMagnitude; //squared distance
        float distanceFromTeleportToFountain = (fountain.Position - Hero.SpawnPoint).sqrMagnitude;
        float speed = Hero.MoveSpeed * Hero.MoveSpeed;
        float teleportTimeSqr = teleportCastTime * teleportCastTime;
        float timeOnFeet = distanceToFountain / speed;
        float timeWithTeleport = teleportTimeSqr + distanceFromTeleportToFountain / speed; //not mathematically correct but faster
        return timeWithTeleport < timeOnFeet;
    }

    public IEnumerator<NodeResult> Teleport() {
        if (Hero.IsAlive) //should be checked before changing state
            {
            if (Hero.State != EntityState.Teleport) HeroMasterController.Teleport();
            while (Hero.State == EntityState.Teleport && ShouldContinueTeleport())
                yield return NodeResult.Continue;
            yield return NodeResult.Success;
        }
        yield return NodeResult.Failure;
    }

    public bool ShouldContinueTeleport() {
        float breakTeleportDistance = 5;
        return IsNoEnemyInDistance(breakTeleportDistance) && Hero.CanTeleport;
    }

    //public bool IsTeleporting() {
    //    return Hero.State == EntityState.Teleport;
    //}

    public bool IsItSafe() {
        float paranoyaDistance = 8;
        return IsNoEnemyInDistance(paranoyaDistance);
    }

    public IEnumerator<NodeResult> Stay() {
        Hero.MoveTargetPosition = Hero.Position;
        if (Hero.State == EntityState.Run) Hero.StateSync = EntityState.Stay;
        yield return NodeResult.Success;
    }

    [System.Obsolete("Deprecated, use version from ActionsWithHeroes.", true)]
    public IEnumerator<NodeResult> SpamSkills() {

        for (int i = 0; i < 3; i++) {
            Skill skill = Hero.GetSkill(i);
            if (skill == null) { Debug.LogWarning("[BotAI] Problem with SkillEffect (not initialized skill?)", Hero.LocalEntity); continue; }
            if (skill.IsActivable) {
                if (Cast(skill) == false) continue;
                yield return NodeResult.Success;
            }
        }
        yield return NodeResult.Failure;
    }

    public bool IsNearEnemyTower() {
        Tower tower = (Tower)Closest(enemyTowers);
        if (tower == null) return false;
        return tower.HasInAttackRange(Hero, safetyMargin);
    }

    public bool IsUnderEnemyTower() {
        Tower tower = (Tower)Closest(enemyTowers);
        if (tower == null) return false;
        return tower.HasInAttackRange(Hero);
    }

    public bool IsTowerTargetingMinion() {
        Tower tower = (Tower)Closest(enemyTowers, null);
        if (tower == null) return false;
        return tower.AttackTarget != null && tower.AttackTarget.EntityType == EType.Minion;
    }

    public bool IsEnemyTowerFocusingMinions() {
        Tower tower = (Tower)Closest(enemyTowers, null);
        if (tower == null) return false;
        if (tower.AttackTarget != null && tower.AttackTarget.EntityType == EType.Hero) return false;
        Func<Entity, bool> filter = delegate(Entity e) { return e.EntityType == EType.Minion && e.IsAlive && e.IsEnemy(tower) && tower.HasInAttackRange(e); };
        var minions = QuadTreeSystem.instance.QuadTree.Query(new QTree.BoundingRect(tower.Position, tower.AttackRange + tower.Radius), filter);
        if (minions.Count == 0) return false;
        else return true;
    }

    public bool IsUnderAttackQQ() { //not reliable but cheap
        //float runningTime = 1f;
        IAttackerControllable attacker = Hero.LastHitter;
        return attacker != null && attacker.AttackTarget == Hero && attacker.HasInAttackRange(Hero, safetyMargin); //Time.time - Hero.LastHitTime < runningTime;
    }

    public bool IsUnderHeroAttackQQ() { //not reliable but cheap
        IAttackerControllable attacker = Hero.LastHitter;
        return attacker != null && attacker.EntityType == EType.Hero && attacker.AttackTarget == Hero && attacker.HasInAttackRange(Hero, safetyMargin);
    }

    public IEnumerator<NodeResult> Engage() {
        float requiredAdvantageRatio = 1.2f;

        Hero bestTarget;
        do {
            bestTarget = null;
            float bestAdvantageRatio = 0;

            foreach (var enemyHero in enemyHeroes.Where(eh => eh.IsTargetableBy(Hero) && Hero.HasInVisibilityRange(eh))) {
                if (enemyHero.IsCoveredBy(enemyTowers, Hero, safetyMargin)) continue; //never attack hero under tower == cheap
                float enemyTeamValue = 0;
                float allyTeamValue = 0;
                foreach (var eh in enemyHeroes.Where(eh => eh.IsAlive && eh.IsVisible && eh.HasInVisibilityRange(Hero)))
                    enemyTeamValue += HeroValue(eh);
                foreach (var ah in allyHeroes.Where(ah => ah.IsAlive && ah.HasInVisibilityRange(enemyHero)))
                    allyTeamValue += HeroValue(ah);
                float advantageRatio = allyTeamValue / enemyTeamValue;

                if (advantageRatio > bestAdvantageRatio) {
                    bestAdvantageRatio = advantageRatio;
                    bestTarget = enemyHero;
                }
            }

            if (bestAdvantageRatio > requiredAdvantageRatio)
                Hero.AttackTarget = bestTarget;
            else
                yield return NodeResult.Failure;

            yield return NodeResult.Continue;
        } while (bestTarget);

        yield return NodeResult.Failure;
    }

    //public IEnumerable ChooseBestEnemyHero() {
    //    float bestKillChance = 0;
    //    IHeroControllable target = null;
    //    foreach (var enemyHero in enemyHeroes) {
    //        if (enemyHero.IsAlive && Hero.HasInVisibilityRange(enemyHero)) {
    //            float killChance = 1 / enemyHero.Life;
    //            if (Hero.HasInAttackRange(enemyHero) == false) {
    //                if (enemyHero.State == EntityState.Run && enemyHero.MoveSpeed > Hero.MoveSpeed)
    //                    killChance = 0;
    //                else {
    //                    killChance /= TimeToGetInRange(Hero, enemyHero, Hero.AttackRange);
    //                }
    //            }
    //            if (killChance > bestKillChance) {
    //                bestKillChance = killChance;
    //                target = enemyHero;
    //            }
    //        }
    //    }
    //    if (target != null) {
    //        Hero.AttackTarget = target;
    //        yield return NodeResult.Success;
    //    } else yield return NodeResult.Failure;
    //}

    public IEnumerator<NodeResult> RunToClosestSafePoint() {
        Entity safePoint = FurthestAllyTower();
        float saveVincity = 2;
        while (Hero.HasInRange(safePoint, saveVincity) == false) {
            Hero.MoveTargetPosition = safePoint.Position;
            yield return NodeResult.Continue;
        }
        yield return NodeResult.Success;
    }

    public bool IsInAttackRangeOfHero() {
        foreach (var h in enemyHeroes)
            if (h.HasInAttackRange(Hero, safetyMargin)) return true;
        return false;
    }

    [System.Obsolete("Deprecated, use version from ActionsWithHeroes.", true)]
    public IEnumerator<NodeResult> SpamSkillsAtTargetedHero() {
        if (Hero.AttackTarget != null && Hero.AttackTarget.EntityType == EType.Hero) {
            var enumerator = SpamSkills();
            while (enumerator.MoveNext())
                yield return NodeResult.Failure; //always fail to not block priority selectors (do in meantime)
        } else yield return NodeResult.Failure;
    }


    //===================================== MISCELLANEOUS =====================================//

    public new IEnumerator<NodeResult> TryRespawn() {
        if (Hero.TimeLeftToRespawn < 0) {
            Mover.Controller.Respawn(Mover.SpawnPoint);
            HeroMasterController.RespawnTime.IncreaseTime();
            yield return NodeResult.Success;
        }
        yield return NodeResult.Failure;
    }

    public bool IsGameStarted() {
        return isGameStarted;
    }

    public bool AreAllyMinionsOnMap() {
        return EntityManager.instance.GetEntitiesOfType(Hero.EntityTeam, EType.Minion).Any(m => m.IsTargetable);
    }

    public bool IsAIReady() {
        return AIRequirementsMet;
    }


    //===================================== TOOLS =====================================//

    private bool IsNoEnemyInDistance(float paranoyaDistance) 
	{
        return IsNoEnemyInDistance(Hero, paranoyaDistance);
    }
	
    public static bool IsNoEnemyInDistance(IHeroControllable hero, float paranoyaDistance) 
	{
        var entities = QuadTreeSystem.instance.QuadTree.Query(
            new BoundingRect(hero.Position, paranoyaDistance), e => e.IsAlive && e.IsEnemy(hero) && e.IsVisible && hero.EntityTeam != Team.Jungle);
        if (entities.Any()) return false;
        else return true;
    }

    [System.Obsolete("Deprecated, use version from ActionsWithHeroes.", true)]
    protected bool Cast(Skill skill) {
        try {
            switch (skill.Type) {
                case SkillType.LineShot:
			case SkillType.LineShotCutTarget:
                    if (Hero.AttackTarget == null) { Debug.LogError("[BotAI] No attack target to cast skill of type " + skill.Type, Hero.LocalEntity); return false; }
                    skill.Activate(Hero.Position, Hero.AttackTarget.Position); return true;

                case SkillType.TargetShot:
                    if (Hero.AttackTarget == null) { Debug.LogError("[BotAI] No attack target to cast skill of type " + skill.Type, Hero.LocalEntity); return false; }
                    skill.Activate(Hero.AttackTarget); return true;

                case SkillType.Area:
                case SkillType.Aura:
                    skill.Activate(); return true;

                case SkillType.AreaTarget:
                    if (Hero.AttackTarget == null) { Debug.LogError("[BotAI] No attack target to cast skill of type " + skill.Type, Hero.LocalEntity); return false; }
                    skill.Activate(Hero.AttackTarget.Position); return true;

                default:
                    //Debug.LogWarning("[BotAI] Can't cast skill of type " + skill.Type + " (targeting: " + skill.TargetingType + ") yet.", Hero.LocalEntity);
                    return false;
            }
        } catch (NullReferenceException e) {
            Debug.LogError("Error in skill effect:\n" + e.Message +e.StackTrace, Hero.LocalEntity);
            return false;
        }
    }

    private Entity Closest<T>(IEnumerable<T> enTities, Entity closestEntity = null) where T : Entity {
        float closestDistance = Mathf.Infinity; // all distances used are squared!
        if (closestEntity) closestDistance = (Hero.Position - closestEntity.Position).sqrMagnitude;
        foreach (var entity in enTities) {
            if (!Hero.CanTargetEnemy(entity)) continue;
            float distanceFrom = (Hero.Position - entity.Position).sqrMagnitude;
            if (distanceFrom < closestDistance) {
                closestDistance = distanceFrom;
                closestEntity = entity;
            }
        }
        return closestEntity;
    }

    private float TimeToGetInRange(IMoverControllable attacker, IMoverControllable victim, float range) {
        float relativeSpeed = RelativeSpeed(attacker, victim);
        float distanceToVictim = (victim.Position - attacker.Position).magnitude;
        float distanceToGo = distanceToVictim - range - attacker.Radius - victim.Radius;
        float time = distanceToGo / relativeSpeed;
        return time;
    }

    private static float RelativeSpeed(IMoverControllable attacker, IMoverControllable victim) {
        float victimAwaySpeed = (victim.State == EntityState.Run)
            ? Quaternion.Dot(Quaternion.LookRotation(victim.Position - attacker.Position), victim.Rotation) * victim.MoveSpeed
            : 0;
        float relativeSpeed = attacker.MoveSpeed - victimAwaySpeed;
        return relativeSpeed;
    }

    private float HeroValue(Hero h) {
        float DPS_Coeff = 4f;
        float HP_Coeff = 4f;
        float rangeCoeff = 1f;

        float dps = h.AttackSpeed * h.Damage;
        float hp = h.Life;
        float range = h.AttackRange;

        return Mathf.Pow(dps, DPS_Coeff) * Mathf.Pow(hp, HP_Coeff) * Mathf.Pow(range, rangeCoeff);
    }

    private Entity FurthestAllyTower() { return FurthestTower(allyCommander); }
    private Entity FurthestEnemyTower() { return FurthestTower(enemyCommander); }

    /// <summary>
    /// Returns furthest tower, assumes only one lane on map.
    /// </summary>
    ///
    private Entity FurthestTower(Commander c) {
        ITowerChainable furthest = allyCommander;
        while (furthest.PreviousTower.Length != 0 && furthest.PreviousTower[0].IsAlive)
            furthest = (ITowerChainable)furthest.PreviousTower[0];
        return (Entity)furthest;
    }

    private List<Entity> GetFrontAllyWave() {
        return GetFrontWave(Hero.EntityTeam);
    }

    private List<Entity> GetFrontEnemyWave() {
        return GetFrontWave(Hero.TeamOfEnemy);
    }

    private List<Entity> GetFrontWave(Team team) {
        float minSearchAreaHeightOrWidth = 5f;

        bool doReversed = Hero.EntityTeam != team;

        LinkedListNode<Vector3> wp = doReversed ? laneWayPoints.First : laneWayPoints.Last;
        List<Entity> frontWave = null;
        while ((frontWave == null || frontWave.Count == 0) && (doReversed ? wp.Next : wp.Previous) != null) {
            Vector3 p = wp.Value;
            wp = doReversed ? wp.Next : wp.Previous;
            Vector3 _p = wp.Value;
            Vector3 center = (p + _p) / 2;
            float width = Math.Max(Mathf.Abs(p.x - _p.x), minSearchAreaHeightOrWidth);
            float height = Math.Max(Mathf.Abs(p.z - _p.z), minSearchAreaHeightOrWidth);

            frontWave = QuadTreeSystem.instance.QuadTree.Query(
                QTree.BoundingRect.FromCenter(center.x, center.z, width, height),
                e => e.EntityType == EType.Minion && e.IsTargetable && e.IsVisible && e.EntityTeam == team);
        }
        return frontWave;
    }

    private Vector3 GetCenter(IEnumerable<Entity> entities) {
        Vector3 posSum = Vector3.zero;
        int count = 0;
        foreach (var e in entities) {
            posSum += e.Position;
            count++;
        }
        return posSum / count;
    }

    static public Vector3 AddRandomOffset(Vector3 position, float maxOffset, float minOffset = 0f) {
        Vector3 proposedPos3D = AddRandomOffsetWithoutLinecast(position, maxOffset, minOffset);

        var navGraph = AstarPath.active.graphs[0] as IRaycastableGraph;
        if (navGraph != null) {
            GraphHitInfo hit;
            if (navGraph.Linecast(position, proposedPos3D, AstarPath.active.GetNearest(position, NNConstraint.Walkable).node, out hit)) {
                return hit.point;
            } else
                return proposedPos3D;
        }
        Debug.LogWarning("[BotAI] No navmesh found for position offset operation");
        return proposedPos3D;
    }

    public static Vector3 AddRandomOffsetWithoutLinecast(Vector3 position, float maxOffset, float minOffset = 0f ) {
        Vector2 proposedPos = Random2DVector(minOffset, maxOffset);
        Vector3 proposedPos3D = new Vector3(proposedPos.x, 0, proposedPos.y);
        proposedPos3D += position;
        return proposedPos3D;
    }

    public static Vector2 Random2DVector(float minRadius, float maxRadius)
    {
        if (minRadius > maxRadius) { Debug.LogWarning("[Random2DVector] minRadius is bigger than maxRadius"); }
        float radius = UnityEngine.Random.Range(minRadius, maxRadius);
        Vector2 unitVector = RandomUnitVector2D();
        return unitVector * radius;
    }

    public static Vector2 RandomUnitVector2D()
    {
        float angle = UnityEngine.Random.Range(-Mathf.PI, Mathf.PI);
        Vector2 unitVector = new Vector2(Mathf.Cos(angle), Mathf.Sin(angle));
        return unitVector;
    }

    private Vector3 GetRandomOffset(Vector3 position, float maxOffset) {
        return (AddRandomOffset(position, maxOffset) - position);
    }

    private bool IsCoveredByEnemyHero(IEntityControllable target) {
        return target.IsCoveredBy(enemyHeroes, Hero, safetyMargin);
    }


    public virtual void OnDrawGizmosSelected() {
        if (isInitialized == false || AIRequirementsMet == false) return;
        Color c = Gizmos.color;
        Gizmos.color = Color.cyan;

        Gizmos.DrawSphere(Hero.MoveTargetPosition + Vector3.up, 0.2f);

        var frontWave = GetFrontAllyWave();
        if (frontWave != null && frontWave.Count != 0) {
            foreach (var e in frontWave)
                Gizmos.DrawWireSphere(e.Position, e.radius);
            Gizmos.DrawWireSphere(Vector3.ClampMagnitude((FurthestAllyTower().Position - GetCenter(frontWave)), 4) + GetCenter(frontWave), 4f);
        }

        //float minSearchAreaHeightOrWidth = 5f; //drawing saech for frontwave

        //var wp = laneWayPoints.Last;  
        //frontWave = null;
        //while ((frontWave == null || frontWave.Count == 0) && wp.Previous != null) {
        //    Vector3 p = wp.Value;
        //    wp = wp.Previous;
        //    Vector3 _p = wp.Value;
        //    Vector3 center = (p + _p) / 2;
        //    float width = Math.Max(Mathf.Abs(p.x - _p.x), minSearchAreaHeightOrWidth);
        //    float height = Math.Max(Mathf.Abs(p.z - _p.z), minSearchAreaHeightOrWidth);
        //    Gizmos.DrawWireCube(center, new Vector3(width, 3, height));
        //    frontWave = QuadTreeSystem.instance.QuadTree.Query(
        //        QTree.BoundingRect.FromCenter(center.x, center.z, width, height),
        //        e => e.EntityType == EType.Minion && e.IsTargetable && e.IsVisible && e.EntityTeam == Hero.EntityTeam);
        //}
        Gizmos.color = c;
    }

    bool _AIRequirementsMet = false;
    public bool AIRequirementsMet {
        get {
            //return
            //    enemyHeroes != null && enemyHeroes.Count() != 0
            //    && enemyTowers != null && enemyTowers.Count() != 0
            //    && fountain != null
            //    && allyCommander != null
            //    && enemyCommander != null
            //    && laneWayPoints != null;
            if (_AIRequirementsMet) return true;
            var cache = BotManager.instance.Cache;
            var ally = Hero.EntityTeam;
            var enemy = Hero.TeamOfEnemy;
            
            return _AIRequirementsMet =
                cache.IsCached(ally, BotCache.Heroes)
                && cache.IsCached(enemy, BotCache.Heroes)
                && cache.IsCached(ally, BotCache.Towers)
                && cache.IsCached(enemy, BotCache.Towers)
                && cache.IsCached(ally, BotCache.Fountain)
                && cache.IsCached(ally, BotCache.Commander)
                && cache.IsCached(enemy, BotCache.Commander)
                && cache.IsCached(Team.None, BotCache.ConquestPoints)
                && cache.IsCached(ally, BotCache.LaneWayPoints);
        }
    }
}

