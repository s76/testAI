﻿using Assets._Controllable.BasicEntity;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;

class ActivatorActions : AttackerActions {
    protected EntityActivator Activator { get; set; }

    override public void Initialize(IEntityControllable entity) {
        Activator = entity as EntityActivator;
        base.Initialize(entity);
    }
}