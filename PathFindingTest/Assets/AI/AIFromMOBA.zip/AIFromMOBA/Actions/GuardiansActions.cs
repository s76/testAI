﻿using UnityEngine;
using System.Collections;
using Assets._AI.Actions;
using Assets._Controllable.BasicEntity;
using System;
using System.Collections.Generic;
using QTree;
using React;

class GuardiansActions : MovingSpawnActions {
    private Vector3 offset;
    private Vector3 offsetDir;

    public float maxDistanceFromOwner = 5f;

    public override void Initialize(IEntityControllable entity) {
        base.Initialize(entity);
        offset = MovingSpawn.Position - Owner.Position;

        ((Hero)Owner.LocalEntity).onMoveTargetPositionChanged += OnMoveTargetPositionChanged;

        float radius = Mathf.Max((MovingSpawn.Radius + Owner.Radius) * 1.1f, 1.5f);
        offset.Normalize();
        offsetDir = offset * radius;
    }

    protected void OnMoveTargetPositionChanged(IMoverControllable mover, Vector3 targetPosition) {
        if (MovingSpawn.State == EntityState.Run || MovingSpawn.State == EntityState.Stay)
            MovingSpawn.MoveTargetPosition = targetPosition + offsetDir;
    }

    public override IEnumerator<NodeResult> GoToOwner() {
        MovingSpawn.MoveTargetPosition = Owner.Position + offsetDir;
        yield return NodeResult.Success;
    }

    public IEnumerator<NodeResult> GoToOwnerRallyPoint() {
        if (Owner.IsMover) {
            MovingSpawn.MoveTargetPosition = ((IMoverControllable)Owner).MoveTargetPosition + offsetDir;
        } else {
            MovingSpawn.MoveTargetPosition = Owner.Position + offset;
        }
        yield return NodeResult.Success;
    }

    public bool IsTooFarFromOwner() {
        //float maxDistanceFromOwner = MovingSpawn.VisibilityRange;
        return (MovingSpawn.Position - Owner.Position).sqrMagnitude > maxDistanceFromOwner * maxDistanceFromOwner;
    }

    public void OnDisable() {
        if (Owner != null)
            ((Hero)Owner.LocalEntity).onMoveTargetPositionChanged -= OnMoveTargetPositionChanged;
    }    
}
