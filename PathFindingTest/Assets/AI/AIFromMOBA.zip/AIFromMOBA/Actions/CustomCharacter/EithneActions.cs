using React;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using UnityMock;

class EithneActions : HeroActions { //TODO: Dont put everything in HeroActions... - PanDenat

    public override void Initialize(Assets._Controllable.BasicEntity.IEntityControllable entity) {
        base.Initialize(entity);
        Debug.Log("[BotAI] Eithne of Brokilon Actions initialized!", this);
    }

    //[System.Obsolete("Deprecated, use version from ActionsWithHeroes.", true)]
    //public IEnumerable SpamSkills() {
    //    for (int i = 0; i < 3; i++) {
    //        Skill skill = Hero.GetSkill(i);
    //        if (skill == null) { Debug.LogWarning("[BotAI] Problem with SkillEffect (not initialized skill?)", Hero.LocalEntity); continue; }
    //        if (skill.IsActivable) {
    //            if (Cast(skill) == false) continue;
    //            yield return NodeResult.Success;
    //        }
    //    }
    //    yield return NodeResult.Failure;
    //}

    public IEnumerable SayHello() {
        Debug.Log("Hi! Eithne's here! - " + Hero.EntityName, this);
        yield return NodeResult.Success;
    }
}

