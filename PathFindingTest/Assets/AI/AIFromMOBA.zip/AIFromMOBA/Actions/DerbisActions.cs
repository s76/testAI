﻿using UnityEngine;
using System.Collections;
using Assets._AI.Actions;
using Assets._Controllable.BasicEntity;
using System;
using System.Collections.Generic;
using QTree;

class DerbisActions : SimpleSpawnActions {
    IHeroControllable heroOwner;

    public override void Initialize(IEntityControllable entity) {
        base.Initialize(entity);

        heroOwner = ((ISpawnControllable)entity).SpawnOwner as IHeroControllable;
    }

    public bool IsHeroInPickupRange() {
        return (heroOwner.Position - Entity.Position).sqrMagnitude < heroOwner.AttackRange * heroOwner.AttackRange;
    }
}
