﻿using Assets._Client;
using Assets._Controllable.BasicEntity;
using Assets._Controllable.HealingTower;
using Assets._Controllable.Tower;
using Assets._Pathfinding;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using UnityEngine;

namespace Assets._AI {
    
    public class BotsCache : MonoBehaviour {
        public bool RefreshCache = true;

        
        public DictionaryTeam< List<Hero>> Heroes { get; private set; }
        public DictionaryTeam< List<Tower>> Towers { get; private set; }
        public DictionaryTeam< Commander> Commander { get; private set; }
        public DictionaryTeam< HealingTower> Fountain { get; private set; }
        public DictionaryTeam< List<ConquestPoint>> ConquestPoints { get; private set; }
        public DictionaryTeam< List<VendorEntity>> IntelVendors { get; private set; }
        public DictionaryTeam< LinkedList<Vector3>> LaneWaypoints { get; private set; }
        public DictionaryTeam< List<ChestVendor>> Chests { get; private set; }
        public DictionaryTeam< List<VendorEntity>> Vendors { get; private set; }
        public DictionaryTeam<EntityActivator[]> PowerUps { get; private set; } 

        private List<CacheRow> tableOfCachingMethods = new List<CacheRow>();

        bool isInited;
        public BotsCache Initialize() {
            if (isInited == true) Debug.LogError("[BotsCache] Initialized twice?", this);
            GameStateManager.instance.onStateChanged += GameStateManager_onStateChanged;
            Reinitialize();
            isInited = true;
            return this;
        }

        protected void OnDestroy()
        {
            if (GameStateManager.instance)
                GameStateManager.instance.onStateChanged -= GameStateManager_onStateChanged;
        }

        void GameStateManager_onStateChanged(GameStateType newState) {
            if (newState == GameStateType.LoadingGame)
                Reinitialize();
        }

        private void Reinitialize() {
            CleanTableOfCachingMethods();
            CleanPropertiesReferences();
            InitTableOfCachingMethods();
        }

        private void InitTableOfCachingMethods() {
            tableOfCachingMethods.Add(new CacheRow(Team.None, BotCache.Heroes,
                (team => CacheList<Hero>(team, BotCache.Heroes, EType.Hero, Heroes))));
            tableOfCachingMethods.Add(new CacheRow(Team.None, BotCache.Towers,
                (team => CacheList<Tower>(team, BotCache.Towers, EType.Tower, Towers))));
            tableOfCachingMethods.Add(new CacheRow(Team.None, BotCache.ConquestPoints,
                (team => CacheList<ConquestPoint>(team, BotCache.ConquestPoints, EType.ConquestPoint, ConquestPoints))));
            tableOfCachingMethods.Add(new CacheRow(Team.None, BotCache.IntelVendors,
                (team => CacheList<VendorEntity>(team, BotCache.IntelVendors, EType.Vendor, IntelVendors))));
            tableOfCachingMethods.Add(new CacheRow(Team.None, BotCache.Commander,
                (team => CacheEntity<Commander>(team, BotCache.Commander, EType.Commander, Commander))));
            tableOfCachingMethods.Add(new CacheRow(Team.None, BotCache.Fountain,
                (team => CacheEntity<HealingTower>(team, BotCache.Fountain, EType.HealingTower, Fountain))));
            tableOfCachingMethods.Add(new CacheRow(Team.None, BotCache.LaneWayPoints,
                (team => CacheWaypoints(team, BotCache.LaneWayPoints, EType.None, LaneWaypoints))));
            tableOfCachingMethods.Add(new CacheRow(Team.None, BotCache.Chests,
                (team => CacheList<ChestVendor>(team, BotCache.Chests, EType.ChestVendor, Chests))));
            tableOfCachingMethods.Add(new CacheRow(Team.None, BotCache.Vendors,
                (team => CacheList<VendorEntity>(team, BotCache.Vendors, EType.Vendor, Vendors))));
            tableOfCachingMethods.Add(new CacheRow(Team.None, BotCache.PowerUps,
                (team => CachePowerUps(team, BotCache.PowerUps, PowerUps))));
        }

        void Reset() {
            CleanPropertiesReferences();
            CleanTableOfCachingMethods();
        }

        private void CleanTableOfCachingMethods() {
            Heroes = new DictionaryTeam< List<Hero>>();
            Towers = new DictionaryTeam< List<Tower>>();
            Commander = new DictionaryTeam< Commander>();
            Fountain = new DictionaryTeam< HealingTower>();
            ConquestPoints = new DictionaryTeam< List<ConquestPoint>>();
            IntelVendors = new DictionaryTeam< List<VendorEntity>>();
            LaneWaypoints = new DictionaryTeam< LinkedList<Vector3>>();
            Chests = new DictionaryTeam< List<ChestVendor>>();
            Vendors = new DictionaryTeam< List<VendorEntity>>();
            PowerUps = new DictionaryTeam<EntityActivator[]>();
        }

        private void CleanPropertiesReferences() {
            tableOfCachingMethods = new List<CacheRow>();
        }

        public bool IsCached(Team team, BotCache cache) {
            //Heroes.SelectMany(kvp => kvp.Value);
            var matchedBotCache = tableOfCachingMethods.Where(c => c.botCacheType == cache);
            if (!matchedBotCache.Any()) throw new ArgumentException("[BotsCache] Doesn't know how to cache " + cache);

            var row = matchedBotCache.FirstOrDefault(c => c.team == team);
            if (row == null) {
                row = new CacheRow(team, cache, matchedBotCache.First().cachingMethod);
                tableOfCachingMethods.Add(row);
            }

            if (row.isNeaded == false) {
                row.isNeaded = true;
                return row.isCached = row.cachingMethod(team);
            } else {
                return row.isCached;
            }
        }

        bool CacheList<T>(Team team, BotCache botCache, EType eType, DictionaryTeam< List<T>> dList) where T : Entity {
            return CacheFunc(team, botCache, dList, () => EntityManager.instance.GetEntitiesOfType(team, eType).Select(e=> (T)e).ToList());
        }

        private bool CachePowerUps(Team team, BotCache botCache, DictionaryTeam<EntityActivator[]> dictionaryTeam)
        {
            return CacheFunc(team, botCache, dictionaryTeam, () => QuestManager.instance.GetQuest<PowerUpsQuest>().activatorsToRandomEnable);
        }

        bool CacheEntity<T>(Team team, BotCache botCache, EType eType, DictionaryTeam< T> dictOfEnTities) where T : Entity
        {
            return CacheFunc(team, botCache, dictOfEnTities, () => EntityManager.instance.GetEntitiesOfType(team, eType).FirstOrDefault() as T);
        }

        bool CacheWaypoints(Team team, BotCache botCache, EType eType, DictionaryTeam< LinkedList<Vector3>> dWaypoints)
        {
            return CacheFunc(team, botCache, dWaypoints, () => GetWaypointsFromScene(team));
        }

        bool CacheFunc<T>(Team team, BotCache botCache, DictionaryTeam<T> dContainer, Func<T> getterFunc) where T : class
        {
            dContainer[team] = getterFunc();
            if (dContainer[team] == null)
            {
                StartCoroutine(CacheFuncCoroutine(team, botCache, dContainer, getterFunc));
                return false;
            }
            else return true;
        }

        private IEnumerator CacheFuncCoroutine<T>(Team team, BotCache botCache, DictionaryTeam<T> dContainer, Func<T> getterFunc) where T : class
        {
            const float warningIntervalTime = 10;
            float lastWarningTime = Time.time;
            float startTime = Time.time;

            while (dContainer[team] == null)
            {
                yield return null;
                dContainer[team] = getterFunc();
                if (Time.time > lastWarningTime + warningIntervalTime)
                {
                    lastWarningTime = Time.time;
#if UNITY_EDITOR
                    Debug.LogWarning(
                        "[BotCache] Can't obtain " + typeof (T) + " of team " + team + " for " + TimeSpan.FromSeconds(Time.time - startTime), this);
#endif
                }
            }

            tableOfCachingMethods.First(row => row.team == team && row.botCacheType == botCache).isCached = true;

            if (RefreshCache == false) yield break;

            const float refreshIntervalTime = 10;
            float lastRefreshTime = Time.time;

            while (true)
            {
                yield return new WaitForSeconds(refreshIntervalTime);
                try
                {
                    dContainer[team] = getterFunc();
                }
                catch (Exception e)
                {
                    Debug.Log("[BotsCache] " + e);
                }
            }
        }

        LinkedList<Vector3> GetWaypointsFromScene(Team team) {
            Waypoints wp = FindObjectOfType(typeof(Waypoints)) as Waypoints;
            if (wp != null)
                return new LinkedList<Vector3>(team == Team.East ? wp.points.Reverse() : wp.points);
            else return null;
        }

        class CacheRow {
            public Team team;
            public BotCache botCacheType;
            public bool isNeaded = false;
            public bool isCached = false;
            public Func<Team, bool> cachingMethod;
            public CacheRow(Team team, BotCache botCacheType, Func<Team, bool> cachingMethod) {
                this.team = team;
                this.botCacheType = botCacheType;
                this.cachingMethod = cachingMethod;
            }
        }
    }

    public enum BotCache { Heroes, Towers, Commander, Fountain, ConquestPoints, IntelVendors, LaneWayPoints, Chests, Vendors,
        PowerUps
    }
}

